"""Unified demo-first command line interface for OpenMolSpec benchmarks.

This module deliberately keeps data preparation and model training separate:
the current, still-growing dataset can be sampled reproducibly for pipeline
development, while the same commands can later target the frozen release.

Examples::

    python -m benchmarks check
    python -m benchmarks prepare-demo --sample-size 10000
    python -m benchmarks run \
        --config benchmarks/configs/structure2property/dipole.yaml --debug
"""

import argparse
import json

from benchmarks.models.registry import (
    TASKS,
    dependency_report,
    formats_for_tasks,
)


def build_parser() -> argparse.ArgumentParser:
    """Build the public benchmark CLI with YAML as its sole training entry."""

    parser = argparse.ArgumentParser(description="OpenMolSpec Application benchmarks")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("check", help="Check Python and pinned model dependencies")

    run_parser = subparsers.add_parser("run", help="Run one YAML experiment")
    run_parser.add_argument("--config", required=True)
    run_parser.add_argument(
        "--run-id", default=None,
        help="Optional override; defaults to a timestamp plus 6 random hex characters",
    )
    run_parser.add_argument("--dry-run", action="store_true")
    run_parser.add_argument(
        "--debug",
        action="store_true",
        help="Run one epoch on fixed small subsets without a model checkpoint",
    )

    prepare_parser = subparsers.add_parser("prepare-demo", help="Prepare a stable pre-QC demo subset")
    prepare_parser.add_argument("--tasks", nargs="+", choices=TASKS, default=list(TASKS))
    prepare_parser.add_argument("--sample-size", type=int, default=10_000)
    prepare_parser.add_argument(
        "--pickle", default="artifacts/processed/openspec.pickle"
    )
    prepare_parser.add_argument("--manifest", default="datasets/openspec_manifest.parquet")
    prepare_parser.add_argument("--output", default="benchmark_data/demo_10k")
    prepare_parser.add_argument("--seed", type=int, default=2025)
    prepare_parser.add_argument("--workers", type=int, default=32)
    prepare_parser.add_argument("--overwrite", action="store_true")

    return parser


def main() -> None:
    parser = build_parser()

    args = parser.parse_args()
    if args.command == "run":
        from benchmarks.trainers.experiment import run_experiment

        summary = run_experiment(
            args.config, dry_run=args.dry_run, run_id=args.run_id,
            debug=args.debug,
        )
        print(json.dumps(summary, indent=2, default=str))
        return
    if args.command == "check":
        report = dependency_report()
        print(json.dumps(report, indent=2))
        return

    if args.command == "prepare-demo":
        from benchmarks.data import prepare

        summary = prepare.run(
            pickle_path=args.pickle,
            manifest_path=args.manifest,
            record_qc_path=None,
            split_path=None,
            output=args.output,
            seed=args.seed,
            workers=args.workers,
            sample_size=args.sample_size,
            formats=formats_for_tasks(args.tasks),
            demo_mode=True,
            overwrite=args.overwrite,
        )
        print(json.dumps(summary, indent=2, default=str))
        return


if __name__ == "__main__":
    main()
