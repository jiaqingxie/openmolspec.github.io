"""Metrics and result helpers used by benchmark engines and trainers."""

import json
from pathlib import Path
from typing import Dict, Sequence

import numpy as np
import pandas as pd

METRICS = (
    "MAE",
    "RMSE",
    "R2",
    "cosine",
    "pearson_r",
    "recall@1",
    "recall@3",
    "recall@5",
    "recall@10",
)


def mae(prediction: np.ndarray, target: np.ndarray) -> float:
    """Mean absolute error between two finite arrays."""

    prediction = np.asarray(prediction, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    mask = np.isfinite(prediction) & np.isfinite(target)
    if not mask.any():
        return float("nan")
    return float(np.mean(np.abs(prediction[mask] - target[mask])))


def rmse(prediction: np.ndarray, target: np.ndarray) -> float:
    """Root mean squared error between two finite arrays."""

    prediction = np.asarray(prediction, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    mask = np.isfinite(prediction) & np.isfinite(target)
    if not mask.any():
        return float("nan")
    return float(np.sqrt(np.mean((prediction[mask] - target[mask]) ** 2)))


def r2(prediction: np.ndarray, target: np.ndarray) -> float:
    """Coefficient of determination."""

    prediction = np.asarray(prediction, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    mask = np.isfinite(prediction) & np.isfinite(target)
    prediction = prediction[mask]
    target = target[mask]
    if target.size < 2:
        return float("nan")
    residual = float(np.sum((target - prediction) ** 2))
    total = float(np.sum((target - np.mean(target)) ** 2))
    if total == 0:
        return float("nan")
    return float(1.0 - residual / total)


def cosine_similarity(prediction: np.ndarray, target: np.ndarray) -> float:
    """Cosine similarity of two vectors (1.0 = identical)."""

    prediction = np.asarray(prediction, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    mask = np.isfinite(prediction) & np.isfinite(target)
    prediction = prediction[mask]
    target = target[mask]
    if prediction.size == 0:
        return float("nan")
    norm_prediction = np.linalg.norm(prediction)
    norm_target = np.linalg.norm(target)
    if norm_prediction == 0 or norm_target == 0:
        return float("nan")
    return float(np.dot(prediction, target) / (norm_prediction * norm_target))


def pearson_r(prediction: np.ndarray, target: np.ndarray) -> float:
    """Pearson correlation coefficient."""

    prediction = np.asarray(prediction, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    mask = np.isfinite(prediction) & np.isfinite(target)
    prediction = prediction[mask]
    target = target[mask]
    if prediction.size < 2 or np.std(prediction) == 0 or np.std(target) == 0:
        return float("nan")
    return float(np.corrcoef(prediction, target)[0, 1])


def save_results(path: str, rows: Sequence[Dict[str, object]]) -> None:
    """Write benchmark results as CSV plus a JSON mirror."""

    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(output.with_suffix(".csv"), index=False)
    with open(output.with_suffix(".json"), "w", encoding="utf-8") as handle:
        json.dump(rows, handle, indent=2, ensure_ascii=False, default=str)
