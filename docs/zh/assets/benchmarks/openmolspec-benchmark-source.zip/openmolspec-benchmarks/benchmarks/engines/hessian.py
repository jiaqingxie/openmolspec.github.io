"""Cartesian Hessian block loss and streaming metrics."""

import torch
from benchmarks.engines.base import BaseEngine, EpochStats


class HessianEngine(BaseEngine):
    name = "EquiformerV3 Hessian-direct"

    def __init__(self, *, targets, **kwargs):
        super().__init__(**kwargs)
        self.targets = tuple(targets)

    def move_batch(self, batch):
        return batch.to(self.device, non_blocking=True)

    def compute_loss(self, batch):
        outputs = self.model(batch)
        # Harmony supports Cartesian SmoothL1, averaged over block components.
        losses = []
        for t in self.targets:
            loss = torch.nn.functional.smooth_l1_loss(outputs[t], batch[t], reduction="sum")
            count = torch.tensor(batch[t].numel(), device=self.device, dtype=torch.float64)
            world = 1
            if torch.distributed.is_initialized():
                world = torch.distributed.get_world_size()
                torch.distributed.all_reduce(count)
            # DDP averages gradients over ranks, whereas blocks per rank vary.
            losses.append(loss * (world / count.clamp_min(1)).to(loss.dtype))
        return sum(losses)

    def forward(self, batch):
        # Evaluation partitions need not have equal numbers of batches.
        # Bypass DDP forward collectives (and its mutable SO(3) buffers).
        model = self.model.module if isinstance(self.model, torch.nn.parallel.DistributedDataParallel) else self.model
        return model(batch)

    def train_epoch(self, epoch, total_epochs):
        stats = super().train_epoch(epoch, total_epochs)
        if not torch.distributed.is_initialized():
            return stats
        loss = torch.tensor(stats.loss, device=self.device, dtype=torch.float64)
        torch.distributed.all_reduce(loss)
        return EpochStats(loss.item() / torch.distributed.get_world_size(),
                          stats.batches, stats.elapsed_seconds)

    def new_collection(self):
        return {t: [0., 0., 0] for t in self.targets}

    def collect_batch(self, collection, batch, outputs):
        for t in self.targets:
            error = (outputs[t] - batch[t]).detach().double()
            collection[t][0] += error.abs().sum().item()
            collection[t][1] += error.square().sum().item()
            collection[t][2] += error.numel()

    def compute_metrics(self, collection):
        result = {}
        for t, (absolute, squared, count) in collection.items():
            if torch.distributed.is_initialized():
                totals = torch.tensor([absolute, squared, count], device=self.device, dtype=torch.float64)
                torch.distributed.all_reduce(totals)
                absolute, squared, count = totals.tolist()
            result[f"MAE_{t}"] = absolute / count
            result[f"RMSE_{t}"] = (squared / count)**0.5
        return result
