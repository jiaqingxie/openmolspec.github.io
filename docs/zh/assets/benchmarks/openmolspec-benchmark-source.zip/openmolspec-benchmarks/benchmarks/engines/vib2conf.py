"""Engine for Vib2Conf spectrum-to-property regression."""

from __future__ import annotations

from typing import Dict, Sequence

import numpy as np
import torch
import torch.nn as nn

from benchmarks.engines import metrics as metrics_module
from benchmarks.engines.base import BaseEngine


def property_tensor(batch: object, name: str) -> torch.Tensor:
    return batch["props"][name]  # type: ignore[index]


class Vib2ConfPropertyEngine(BaseEngine):
    """Batch execution for Vib2Conf property heads."""

    name = "Vib2Conf"

    def __init__(self, *, targets: Sequence[str], loss_beta: float = 1.0, **kwargs):
        super().__init__(**kwargs)
        self.targets = tuple(targets)
        if not np.isfinite(loss_beta) or loss_beta <= 0:
            raise ValueError('SmoothL1 beta must be finite and positive')
        self.loss_beta = float(loss_beta)

    def move_batch(self, batch: object) -> object:
        for key, value in batch.items():
            if isinstance(value, torch.Tensor):
                batch[key] = value.to(self.device)
        for name in self.targets:
            batch["props"][name] = batch["props"][name].to(self.device)  # type: ignore[index]
        return batch

    def compute_loss(self, batch: object) -> torch.Tensor:
        normalizer = self.require_normalizer()
        outputs = self.model(batch)
        total = torch.zeros((), device=self.device)
        for name in self.targets:
            target = normalizer.normalize(property_tensor(batch, name), name)
            total = total + nn.functional.smooth_l1_loss(
                outputs[name], target, beta=self.loss_beta)
        return total

    def new_collection(self) -> object:
        return {
            name: {"pred": [], "target": []} for name in self.targets
        }

    def collect_batch(self, collection: object, batch: object, outputs: object) -> None:
        normalizer = self.require_normalizer()
        values = collection  # type: ignore[assignment]
        for name in self.targets:
            prediction = normalizer.denormalize(outputs[name], name)
            values[name]["pred"].append(prediction.cpu().numpy())
            values[name]["target"].append(
                property_tensor(batch, name).cpu().numpy()
            )

    def compute_metrics(self, collection: object) -> Dict[str, float]:
        values = collection  # type: ignore[assignment]
        metrics: Dict[str, float] = {}
        for name in self.targets:
            pred = np.concatenate(values[name]["pred"])
            target = np.concatenate(values[name]["target"])
            metrics[f"MAE_{name}"] = metrics_module.mae(pred, target)
            metrics[f"RMSE_{name}"] = metrics_module.rmse(pred, target)
            metrics[f"R2_{name}"] = metrics_module.r2(pred, target)
        return metrics
