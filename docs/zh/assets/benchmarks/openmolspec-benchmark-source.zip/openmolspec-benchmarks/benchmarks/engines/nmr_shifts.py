"""Per-nucleus normalization, globally atom-weighted loss and ppm metrics."""
import math
import torch
from benchmarks.engines.hessian import HessianEngine


class NMRShiftEngine(HessianEngine):
    name = 'EquiformerV3 atom NMR'

    def compute_loss(self, batch):
        predictions = self.model(batch)
        losses = []
        active = 0
        for t in self.targets:
            mask = batch[f'nmr_{t.lower()}_mask']
            truth = self.normalizer.normalize(batch.nmr_shift[mask], t)
            # An empty mask gives a connected zero loss: never skip backward
            # independently on a rank that has no H/C atoms in this batch.
            loss = torch.nn.functional.smooth_l1_loss(predictions[t][mask], truth, reduction='sum')
            count = torch.tensor(truth.numel(), device=self.device, dtype=torch.float64)
            world = 1
            if torch.distributed.is_initialized():
                world = torch.distributed.get_world_size()
                torch.distributed.all_reduce(count)
            active += int(count.item() > 0)
            losses.append(loss * (world / count.clamp_min(1)).to(loss.dtype))
        return sum(losses) / max(active, 1)

    def collect_batch(self, collection, batch, outputs):
        for t in self.targets:
            mask = batch[f'nmr_{t.lower()}_mask']
            pred = self.normalizer.denormalize(outputs[t][mask], t)
            error = (pred.double() - batch.nmr_shift[mask].double()).detach()
            collection[t][0] += error.abs().sum().item()
            collection[t][1] += error.square().sum().item()
            collection[t][2] += error.numel()

    def compute_metrics(self, collection):
        result = {}
        for t, values in collection.items():
            totals = torch.tensor(values, device=self.device, dtype=torch.float64)
            if torch.distributed.is_initialized():
                torch.distributed.all_reduce(totals)
            absolute, squared, count = totals.tolist()
            result[f'MAE_{t}'] = absolute / count if count else math.nan
            result[f'RMSE_{t}'] = math.sqrt(squared / count) if count else math.nan
            result[f'count_{t}'] = int(count)
        return result
