"""Engine for structure-to-property and structure-to-spectrum tasks."""

from __future__ import annotations

from typing import Dict, List

import numpy as np
import torch
import torch.nn as nn

from benchmarks.engines import metrics as metrics_module
from benchmarks.engines.base import BaseEngine


def target_tensor(batch: object, name: str) -> torch.Tensor:
    values = getattr(batch, name)
    if not isinstance(values, torch.Tensor):
        values = torch.as_tensor(values, dtype=torch.float32)
    return values.float()


def spectrum_loss(prediction: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    mse = nn.functional.mse_loss(prediction, target)
    cosine = 1.0 - nn.functional.cosine_similarity(
        prediction, target, dim=-1
    ).mean()
    return mse + 0.5 * cosine


class EquiformerEngine(BaseEngine):
    """Batch execution for all EquiformerV3 observable heads."""

    name = "EquiformerV3"

    def __init__(self, *, property_targets: List[str], spectrum_targets: List[str], **kwargs):
        super().__init__(**kwargs)
        self.property_targets = property_targets
        self.spectrum_targets = spectrum_targets

    def move_batch(self, batch: object) -> object:
        return batch.to(self.device)  # type: ignore[attr-defined]

    def compute_loss(self, batch: object) -> torch.Tensor:
        normalizer = self.require_normalizer()
        outputs = self.model(batch)
        total = torch.zeros((), device=self.device)
        for name in self.property_targets:
            target = normalizer.normalize(target_tensor(batch, name), name)
            total = total + nn.functional.mse_loss(outputs[name], target)
        for name in self.spectrum_targets:
            target = normalizer.normalize(target_tensor(batch, name), name)
            total = total + spectrum_loss(outputs[name], target)
        return total

    def new_collection(self) -> object:
        return {
            "property": {
                name: {"pred": [], "target": []}
                for name in self.property_targets
            },
            "spectrum": {
                name: {"pred": [], "target": []}
                for name in self.spectrum_targets
            },
        }

    def collect_batch(self, collection: object, batch: object, outputs: object) -> None:
        normalizer = self.require_normalizer()
        values = collection  # type: ignore[assignment]
        for name in self.property_targets:
            prediction = normalizer.denormalize(outputs[name], name).cpu().numpy()
            target = target_tensor(batch, name).cpu().numpy()
            values["property"][name]["pred"].append(prediction)
            values["property"][name]["target"].append(target)
        for name in self.spectrum_targets:
            prediction = normalizer.denormalize(outputs[name], name).cpu().numpy()
            target = target_tensor(batch, name).cpu().numpy()
            values["spectrum"][name]["pred"].append(prediction)
            values["spectrum"][name]["target"].append(target)

    def compute_metrics(self, collection: object) -> Dict[str, float]:
        values = collection  # type: ignore[assignment]
        metrics: Dict[str, float] = {}
        for name in self.property_targets:
            pred = np.concatenate(values["property"][name]["pred"])
            target = np.concatenate(values["property"][name]["target"])
            metrics[f"MAE_{name}"] = metrics_module.mae(pred, target)
            metrics[f"RMSE_{name}"] = metrics_module.rmse(pred, target)
            metrics[f"R2_{name}"] = metrics_module.r2(pred, target)
        for name in self.spectrum_targets:
            pred = np.concatenate(values["spectrum"][name]["pred"])
            target = np.concatenate(values["spectrum"][name]["target"])
            metrics[f"MAE_{name}"] = metrics_module.mae(pred, target)
            cosine = [
                metrics_module.cosine_similarity(p, t)
                for p, t in zip(pred, target)
            ]
            finite = [value for value in cosine if np.isfinite(value)]
            metrics[f"cosine_{name}"] = (
                float(np.mean(finite)) if finite else float("nan")
            )
        return metrics
