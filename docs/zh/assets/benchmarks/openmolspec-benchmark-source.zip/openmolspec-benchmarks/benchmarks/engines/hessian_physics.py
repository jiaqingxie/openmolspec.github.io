"""Float64 physical diagnostics inspired by Harmony physical_validation.

No empirical frequency scale; remove rigid motions geometrically, never by
discarding the lowest eigenvalues. Rotation nullity assumes a stationary point.
"""
import numpy as np
from scipy.constants import elementary_charge, atomic_mass, c


def assemble(hi, hij, edges):
    n = len(hi)
    h = np.zeros((n, 3, n, 3), dtype=np.float64)
    src, dst = edges
    h[dst, :, src, :] = hij
    h[np.arange(n), :, np.arange(n), :] = hi
    return h.reshape(3*n, 3*n)


def physics(h, pos, masses, imaginary_threshold=20.):
    h, pos, masses = [np.asarray(x, dtype=np.float64) for x in (h, pos, masses)]
    if not all(np.isfinite(x).all() for x in (h, pos, masses)) or np.any(masses <= 0):
        raise ValueError('Nonfinite inputs or nonpositive masses')
    norm = max(np.linalg.norm(h), 1e-30)
    symmetric = (h+h.T)/2
    xyz = pos - np.average(pos, axis=0, weights=masses)
    translations = np.tile(np.eye(3), (len(pos), 1)) / np.sqrt(len(pos))
    rotations = np.stack([np.cross(np.broadcast_to(axis, xyz.shape), xyz).ravel()
                          for axis in np.eye(3)], axis=1)
    u, s, _ = np.linalg.svd(rotations, full_matrices=False)
    rotation_basis = u[:, s > max(s.max()*1e-7, 1e-14)]
    sqrt_m = np.repeat(np.sqrt(masses), 3)
    candidate = np.concatenate((translations, rotation_basis), axis=1)*sqrt_m[:, None]
    u, s, _ = np.linalg.svd(candidate, full_matrices=True)
    rank = int(np.sum(s > s.max()*1e-7))
    internal = u[:, rank:]
    weighted = symmetric / sqrt_m[:, None] / sqrt_m[None, :]
    projected = internal.T @ weighted @ internal
    values = np.linalg.eigvalsh((projected+projected.T)/2)
    freq = np.sign(values)*np.sqrt(np.abs(values)*elementary_charge/(atomic_mass*1e-20))/(2*np.pi*c*100)
    metrics = dict(symmetry_relative=float(np.linalg.norm(h-h.T)/norm),
                   translation_relative=float(np.linalg.norm(h@translations)/norm),
                   rotation_relative=float(np.linalg.norm(h@rotation_basis)/norm),
                   rigid_mass_weighted_relative=float(np.linalg.norm(weighted@u[:, :rank])/max(np.linalg.norm(weighted),1e-30)),
                   rigid_rank=rank, imaginary_count=int(np.sum(freq < -imaginary_threshold)),
                   minimum_frequency_cm1=float(freq.min()) if len(freq) else None)
    return metrics, freq


def matrix_errors(pred, reference):
    error = pred-reference
    return dict(mae=float(np.abs(error).mean()), rmse=float(np.sqrt(np.square(error).mean())),
                relative_frobenius=float(np.linalg.norm(error)/max(np.linalg.norm(reference),1e-30)))
