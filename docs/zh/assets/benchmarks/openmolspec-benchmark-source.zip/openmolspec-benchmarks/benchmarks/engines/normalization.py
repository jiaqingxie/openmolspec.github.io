"""Target normalization shared by training and evaluation engines."""

from __future__ import annotations

import fcntl
import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, Sequence

import numpy as np
import torch
from tqdm import tqdm


BatchValues = Callable[[object, str], torch.Tensor]
CACHE_SCHEMA_VERSION = 1


@dataclass
class TargetNormalizer:
    """Mean/std normalization fitted only on the training split."""

    mean: Dict[str, float]
    std: Dict[str, float]

    @classmethod
    def fit(
        cls,
        loader: Iterable[object],
        targets: Sequence[str],
        values_from_batch: BatchValues,
        *,
        progress_mode: str = "log",
        description: str = "Fit target normalizer",
    ) -> "TargetNormalizer":
        sums = {name: 0.0 for name in targets}
        sums_sq = {name: 0.0 for name in targets}
        counts = {name: 0 for name in targets}
        batches = tqdm(
            loader,
            desc=description,
            leave=True,
            disable=progress_mode != "tqdm",
            dynamic_ncols=True,
        )
        for batch in batches:
            for name in targets:
                values = values_from_batch(batch, name).float()
                finite = torch.isfinite(values)
                if finite.any():
                    selected = values[finite]
                    sums[name] += selected.sum().item()
                    sums_sq[name] += (selected**2).sum().item()
                    counts[name] += int(finite.sum())

        missing = [name for name, count in counts.items() if count == 0]
        if missing:
            raise ValueError(
                "Cannot fit target normalizer; no finite training values for: "
                + ", ".join(missing)
            )
        mean = {name: sums[name] / counts[name] for name in targets}
        std = {
            name: float(
                np.sqrt(
                    max(sums_sq[name] / counts[name] - mean[name] ** 2, 1e-8)
                )
            )
            for name in targets
        }
        return cls(mean=mean, std=std)

    def normalize(self, values: torch.Tensor, name: str) -> torch.Tensor:
        return (values - self.mean[name]) / self.std[name]

    def denormalize(self, values: torch.Tensor, name: str) -> torch.Tensor:
        return values * self.std[name] + self.mean[name]

    def state_dict(self) -> Dict[str, Dict[str, float]]:
        return {"mean": dict(self.mean), "std": dict(self.std)}

    @classmethod
    def from_state_dict(
        cls, state: Dict[str, Dict[str, float]]
    ) -> "TargetNormalizer":
        return cls(mean=dict(state["mean"]), std=dict(state["std"]))


def _source_identity(path: Path) -> Dict[str, object]:
    """Return cheap fields that invalidate a cache when an LMDB is replaced."""

    stat = path.stat()
    return {
        "path": str(path.expanduser().resolve()),
        "size": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
    }


def _cache_path(source_path: Path, targets: Sequence[str]) -> Path:
    canonical_targets = sorted(set(targets))
    digest = hashlib.sha256(
        json.dumps(canonical_targets, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:12]
    readable = "-".join(canonical_targets)
    if len(readable) > 80:
        readable = readable[:80].rstrip("-")
    return (
        source_path.parent
        / ".cache"
        / "target_normalizers"
        / f"{readable}-{digest}.json"
    )


def _load_cached_normalizer(
    cache_path: Path,
    source: Dict[str, object],
    targets: Sequence[str],
) -> TargetNormalizer | None:
    canonical_targets = sorted(set(targets))
    try:
        with open(cache_path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if payload.get("schema_version") != CACHE_SCHEMA_VERSION:
            return None
        if payload.get("source") != source:
            return None
        if payload.get("targets") != canonical_targets:
            return None
        normalizer = TargetNormalizer.from_state_dict(payload["normalizer"])
        if set(normalizer.mean) != set(targets):
            return None
        if set(normalizer.std) != set(targets):
            return None
        if not all(
            np.isfinite(normalizer.mean[name])
            and np.isfinite(normalizer.std[name])
            and normalizer.std[name] > 0
            for name in targets
        ):
            return None
        return normalizer
    except (OSError, KeyError, TypeError, ValueError):
        return None


def _write_normalizer_cache(
    cache_path: Path,
    source: Dict[str, object],
    targets: Sequence[str],
    normalizer: TargetNormalizer,
) -> None:
    payload = {
        "schema_version": CACHE_SCHEMA_VERSION,
        "source": source,
        "targets": sorted(set(targets)),
        "normalizer": normalizer.state_dict(),
    }
    temporary_path = cache_path.with_name(
        f".{cache_path.name}.{os.getpid()}.tmp"
    )
    try:
        with open(temporary_path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(temporary_path, cache_path)
    finally:
        try:
            temporary_path.unlink()
        except FileNotFoundError:
            pass


def fit_or_load_normalizer(
    loader: Iterable[object],
    targets: Sequence[str],
    values_from_batch: BatchValues,
    *,
    source_path: str | Path,
    progress_mode: str = "log",
    description: str = "Fit target normalizer",
    cache_enabled: bool = True,
    cache_tag: str | None = None,
) -> TargetNormalizer:
    """Fit once per LMDB/target combination and reuse the result safely.

    The cache lives beside the prepared LMDB. Its source identity includes the
    resolved path, byte size and nanosecond modification time, so replacing a
    prepared training set invalidates the old statistics automatically.
    """

    source_path = Path(source_path)
    targets = tuple(targets)
    if not cache_enabled:
        return TargetNormalizer.fit(
            loader,
            targets,
            values_from_batch,
            progress_mode=progress_mode,
            description=description,
        )

    lock = None
    try:
        source = _source_identity(source_path)
        if cache_tag is not None:
            source['preprocessing'] = cache_tag
        cache_path = _cache_path(source_path, targets)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        lock_path = cache_path.with_suffix(cache_path.suffix + ".lock")
        lock = open(lock_path, "a", encoding="utf-8")
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
    except OSError as error:
        if lock is not None:
            lock.close()
        print(
            f"[OpenMolSpec] Target normalizer cache unavailable ({error}); "
            "fitting without cache.",
            flush=True,
        )
        return TargetNormalizer.fit(
            loader,
            targets,
            values_from_batch,
            progress_mode=progress_mode,
            description=description,
        )

    with lock:
        cached = _load_cached_normalizer(cache_path, source, targets)
        if cached is not None:
            print(
                f"[OpenMolSpec] Target normalizer cache hit: {cache_path}",
                flush=True,
            )
            return cached

        normalizer = TargetNormalizer.fit(
            loader,
            targets,
            values_from_batch,
            progress_mode=progress_mode,
            description=description,
        )
        source_recheck_failed = False
        try:
            source_unchanged = _source_identity(source_path) == source
        except OSError as error:
            source_unchanged = False
            source_recheck_failed = True
            print(
                "[OpenMolSpec] Could not recheck the training LMDB after "
                f"fitting ({error}); cache was not written.",
                flush=True,
            )
        if source_unchanged:
            try:
                _write_normalizer_cache(
                    cache_path, source, targets, normalizer
                )
                print(
                    f"[OpenMolSpec] Saved target normalizer cache: "
                    f"{cache_path}",
                    flush=True,
                )
            except OSError as error:
                print(
                    "[OpenMolSpec] Could not write target normalizer cache "
                    f"({error}); training will continue.",
                    flush=True,
                )
        elif not source_recheck_failed:
            print(
                "[OpenMolSpec] Training LMDB changed while fitting the "
                "target normalizer; cache was not written.",
                flush=True,
            )
        return normalizer
