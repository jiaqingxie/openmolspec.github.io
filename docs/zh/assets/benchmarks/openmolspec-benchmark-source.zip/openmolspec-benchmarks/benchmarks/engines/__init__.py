"""Batch-level training and evaluation engines.

Concrete engines are lazy imports so utility metrics remain lightweight.
"""

__all__ = [
    "BaseEngine",
    "EpochStats",
    "EquiformerEngine",
    "Vib2ConfPropertyEngine",
    "resolve_progress_mode",
]


def __getattr__(name: str):
    if name in {"BaseEngine", "EpochStats", "resolve_progress_mode"}:
        from .base import BaseEngine, EpochStats, resolve_progress_mode

        return {
            "BaseEngine": BaseEngine,
            "EpochStats": EpochStats,
            "resolve_progress_mode": resolve_progress_mode,
        }[name]
    if name == "EquiformerEngine":
        from .equiformer import EquiformerEngine

        return EquiformerEngine
    if name == "Vib2ConfPropertyEngine":
        from .vib2conf import Vib2ConfPropertyEngine

        return Vib2ConfPropertyEngine
    raise AttributeError(name)
