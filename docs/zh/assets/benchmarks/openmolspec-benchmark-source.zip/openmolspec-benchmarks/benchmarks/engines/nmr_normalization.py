"""Train-only, per-nucleus median/IQR scaling for chemical-shift tokens."""

import fcntl
import hashlib
import json
import os
from pathlib import Path
import pickle

import lmdb
import numpy as np
from tqdm import tqdm

POLICY = {"version": 1, "method": "median_iqr", "quantiles": [25, 50, 75],
          "weighting": "each_nucleus", "clip": False, "empty_or_zero_iqr_scale": 1.0}


def read_nmr_arrays(record):
    if record.get("nmr_shift_unit") != "ppm" or not record.get("nmr_reference_id"):
        raise ValueError("Missing referenced ppm NMR labels; use the H/C rebuilt dataset")
    result = {}
    for label in ("h", "c"):
        field = f"nmr_{label}_shifts_ppm"
        if field not in record:
            raise ValueError(f"Missing {field}; do not silently treat missing labels as no nuclei")
        x = np.asarray(record[field], dtype=np.float32)
        if x.ndim != 1 or not np.isfinite(x).all():
            raise ValueError(f"Invalid {field}")
        if record.get(f"nmr_{label}_present") != bool(len(x)):
            raise ValueError(f"Inconsistent {label} presence flag")
        result[label] = x
    return result


def _fingerprint(path):
    stat = path.stat()
    reference = path.parent.parent / "nmr_reference.json"
    return {"path": str(path.resolve()), "size": stat.st_size, "mtime_ns": stat.st_mtime_ns,
            "reference_sha256": hashlib.sha256(reference.read_bytes()).hexdigest() if reference.exists() else None}


def _fit(path, max_records, progress):
    chunks, pending = {x: [] for x in ("h", "c")}, {x: [] for x in ("h", "c")}
    reference_id = None
    records = 0
    with lmdb.open(str(path), readonly=True, subdir=False, lock=False, readahead=True) as env:
        with env.begin() as txn:
            total = txn.stat()["entries"]
            if max_records is not None:
                total = min(total, max_records)
            with tqdm(total=total, desc="Fit H/C median/IQR (train)", unit="record",
                      disable=progress != "tqdm", mininterval=5) as bar:
                for _, value in txn.cursor():
                    if records == total:
                        break
                    record = pickle.loads(value)
                    values = read_nmr_arrays(record)
                    if reference_id is None:
                        reference_id = record["nmr_reference_id"]
                    if reference_id != record["nmr_reference_id"]:
                        raise ValueError("Mixed NMR reference versions in training data")
                    for label in chunks:
                        pending[label].append(values[label])
                    records += 1
                    if records % 4096 == 0:
                        for label in chunks:
                            chunks[label].append(np.concatenate(pending[label]))
                            pending[label].clear()
                    bar.update()
    if not records:
        raise ValueError("Cannot fit NMR normalization on an empty training set")
    statistics = {}
    for label in chunks:
        if pending[label]:
            chunks[label].append(np.concatenate(pending[label]))
            pending[label].clear()
        values = np.concatenate(chunks[label])
        chunks[label].clear()
        if len(values):
            q25, median, q75 = (float(x) for x in np.percentile(values, [25, 50, 75]))
        else:
            q25 = median = q75 = 0.0
        iqr = q75 - q25
        statistics[label] = {"count": int(len(values)), "q25": q25, "median": median,
                             "q75": q75, "scale": iqr if iqr > 1e-8 else 1.0,
                             "fallback": not len(values) or iqr <= 1e-8}
    return {"policy": POLICY, "reference_id": reference_id, "train_records": records,
            "statistics": statistics}


def fit_or_load_nmr_normalizer(source_path, *, cache_enabled=True, max_records=None, progress="log"):
    path = Path(source_path)
    if path.name not in ("train.lmdb", "openspec_train.lmdb"):
        raise ValueError("NMR normalization may only be fitted on train.lmdb")
    if max_records is not None and max_records < 1:
        raise ValueError("max_records must be positive")
    summary_path = path.parent.parent / 'summary.json'
    if summary_path.exists():
        summary = json.loads(summary_path.read_text())
        if summary.get('version') in ('hc-nmr-v1', 'vib2mol-hc-v1') and summary.get('state') != 'completed':
            raise ValueError('Multimodal dataset build is incomplete')
    if not cache_enabled:
        return _fit(path, max_records, progress)
    if max_records is not None:
        raise ValueError("Never cache subset/debug statistics as full-training statistics")
    source = _fingerprint(path)
    cache = path.parent / ".cache" / "nmr_median_iqr.json"
    cache.parent.mkdir(parents=True, exist_ok=True)
    with cache.with_suffix(".lock").open("a") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            result = json.loads(cache.read_text())
            st = result["statistics"]
            valid = all(np.isfinite(st[x]["median"]) and np.isfinite(st[x]["scale"])
                        and st[x]["scale"] > 0 for x in ("h", "c"))
            if valid and result.get("source") == source and result.get("policy") == POLICY:
                print(f"[NMR] Loaded train median/IQR cache: {cache}", flush=True)
                return result
        except (OSError, ValueError, KeyError, TypeError):
            pass
        result = _fit(path, None, progress)
        if _fingerprint(path) != source:
            raise ValueError("Training source changed while fitting NMR statistics")
        result["source"] = source
        partial = cache.with_name(f".{cache.name}.{os.getpid()}.partial")
        try:
            partial.write_text(json.dumps(result, indent=2) + "\n")
            partial.replace(cache)
        finally:
            partial.unlink(missing_ok=True)
        return result
