"""Reusable batch-level engine inspired by Harmony's ``BaseEngine``."""

from __future__ import annotations

import sys
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Iterable, Optional

import torch
import torch.nn as nn
from tqdm import tqdm

from benchmarks.engines.normalization import TargetNormalizer

PROGRESS_MODES = ("auto", "tqdm", "log")


def resolve_progress_mode(mode: str, is_tty: Optional[bool] = None) -> str:
    """Choose interactive tqdm or stable interval logs."""

    if mode not in PROGRESS_MODES:
        raise ValueError(f"Unknown progress mode: {mode}")
    if mode != "auto":
        return mode
    terminal = sys.stderr.isatty() if is_tty is None else is_tty
    return "tqdm" if terminal else "log"


def _format_duration(seconds: float) -> str:
    seconds = max(int(round(seconds)), 0)
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours:
        return f"{hours}h {minutes:02d}m {seconds:02d}s"
    if minutes:
        return f"{minutes}m {seconds:02d}s"
    return f"{seconds}s"


@dataclass(frozen=True)
class EpochStats:
    """Compact result returned by one training epoch."""

    loss: float
    batches: int
    elapsed_seconds: float


class BaseEngine(ABC):
    """Own forward/loss/metrics behavior at batch granularity.

    Trainers own epochs, scheduling and checkpoints. Model-specific engines
    only implement batch transfer, objective construction and metric
    collection.
    """

    name = "Benchmark"

    def __init__(
        self,
        *,
        model: nn.Module,
        train_loader: Iterable[object],
        eval_loader: Iterable[object],
        test_loader: Iterable[object],
        normalizer: Optional[TargetNormalizer],
        optimizer: Optional[torch.optim.Optimizer],
        device: str,
        progress_mode: str,
        progress_interval_seconds: float = 30.0,
    ) -> None:
        self.model = model
        self.train_loader = train_loader
        self.eval_loader = eval_loader
        self.test_loader = test_loader
        self.normalizer = normalizer
        self.optimizer = optimizer
        self.device = device
        self.progress_mode = resolve_progress_mode(progress_mode)
        self.progress_interval_seconds = progress_interval_seconds
        self.is_primary = not torch.distributed.is_initialized() or torch.distributed.get_rank() == 0

    def require_normalizer(self) -> TargetNormalizer:
        if self.normalizer is None:
            raise RuntimeError("Target normalizer has not been initialized")
        return self.normalizer

    @abstractmethod
    def move_batch(self, batch: object) -> object:
        """Move model inputs and targets to the engine device."""

    @abstractmethod
    def compute_loss(self, batch: object) -> torch.Tensor:
        """Return the scalar training objective for one batch."""

    def forward(self, batch: object) -> object:
        """Run model inference; override when a batch is not one model input."""

        return self.model(batch)

    @abstractmethod
    def new_collection(self) -> object:
        """Create evaluation accumulators."""

    @abstractmethod
    def collect_batch(
        self, collection: object, batch: object, outputs: object
    ) -> None:
        """Append one evaluation batch to the accumulators."""

    @abstractmethod
    def compute_metrics(self, collection: object) -> Dict[str, float]:
        """Reduce evaluation accumulators into publication-scale metrics."""

    def train_epoch(self, epoch: int, total_epochs: int) -> EpochStats:
        if self.optimizer is None:
            raise RuntimeError("Training requires an optimizer")
        self.model.train()
        sampler = getattr(self.train_loader, "sampler", None)
        if hasattr(sampler, "set_epoch"):
            sampler.set_epoch(epoch)
        started = time.monotonic()
        last_log = started
        running_loss = 0.0
        batch_count = 0
        total_batches = len(self.train_loader)  # type: ignore[arg-type]
        progress = tqdm(
            self.train_loader,
            desc=f"Epoch{epoch:4d} [Train]",
            total=total_batches,
            leave=True,
            disable=self.progress_mode != "tqdm" or not self.is_primary,
            dynamic_ncols=True,
        )

        for batch in progress:
            batch = self.move_batch(batch)
            self.optimizer.zero_grad()
            loss = self.compute_loss(batch)
            loss.backward()
            self.optimizer.step()
            running_loss += float(loss.detach().item())
            batch_count += 1
            mean_loss = running_loss / batch_count
            if self.progress_mode == "tqdm" and self.is_primary:
                progress.set_description(
                    f"Epoch{epoch:4d} [Train] loss:{mean_loss:.6f}"
                )
            now = time.monotonic()
            if (
                self.progress_mode == "log"
                and self.is_primary
                and now - last_log >= self.progress_interval_seconds
            ):
                rate = batch_count / max(now - started, 1e-8)
                remaining = max(total_batches - batch_count, 0)
                percent = 100.0 * batch_count / max(total_batches, 1)
                print(
                    f"[{self.name}] epoch {epoch}/{total_epochs} | "
                    f"batch {batch_count:,}/{total_batches:,} ({percent:.1f}%) | "
                    f"train_loss={mean_loss:.6g} | {rate:.2f} batch/s | "
                    f"ETA {_format_duration(remaining / max(rate, 1e-8))}",
                    flush=True,
                )
                last_log = now
        return EpochStats(
            loss=running_loss / max(batch_count, 1),
            batches=batch_count,
            elapsed_seconds=time.monotonic() - started,
        )

    def evaluate(
        self, loader: Iterable[object], *, description: str
    ) -> Dict[str, float]:
        self.model.eval()
        collection = self.new_collection()
        progress = tqdm(
            loader,
            desc=description,
            leave=True,
            disable=self.progress_mode != "tqdm" or not self.is_primary,
            dynamic_ncols=True,
        )
        with torch.no_grad():
            for batch in progress:
                batch = self.move_batch(batch)
                outputs = self.forward(batch)
                self.collect_batch(collection, batch, outputs)
        return self.compute_metrics(collection)

    def evaluate_validation(self, description: str = "Validation") -> Dict[str, float]:
        return self.evaluate(self.eval_loader, description=description)

    def evaluate_test(self, description: str = "Test") -> Dict[str, float]:
        return self.evaluate(self.test_loader, description=description)
