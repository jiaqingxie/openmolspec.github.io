"""Joint Hi/Hij test evaluation against full release Hessians and cutoff baseline."""
import argparse
import json
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import torch
import yaml
from ase.data import atomic_masses
from torch_geometric.data import Batch
from tqdm import tqdm

from benchmarks.data.prepare_hessian import read_array
from benchmarks.engines.hessian_physics import assemble, physics, matrix_errors
from benchmarks.models.equiformer_v3.dataset import OpenSpecLmdbDataset
from benchmarks.models.equiformer_v3.hessian import DirectHessianModel
from benchmarks.trainers.base import load_checkpoint
from openmolspec.core.constants import HESSIAN_AU_TO_EV_ANGSTROM2


def load_run(directory, target, device, cutoff):
    directory = Path(directory)
    cfg = yaml.safe_load((directory/'resolved_config.yaml').read_text())
    if cfg['task']['targets'] != [target]:
        raise ValueError(f'{directory}: expected standalone {target} model')
    params = cfg['model'].get('parameters', {})
    if params.get('max_radius', 5.) != cutoff:
        raise ValueError('Checkpoint/data cutoff mismatch')
    model = DirectHessianModel([target], params).to(device)
    checkpoint = directory/'artifacts/equiformer_v3_structure2hessian_best.pt'
    model.load_state_dict(load_checkpoint(checkpoint, device)['state_dict'])
    return model.eval(), str(checkpoint.resolve())


def run(args):
    root = Path(args.data_dir)
    meta = json.loads((root/'summary.json').read_text())
    if meta['hessian_unit'] != 'eV/Angstrom^2' or meta.get('mass_weighted', False):
        raise ValueError('Expected unweighted eV/Angstrom^2 data')
    if args.limit is not None and args.limit < 1:
        raise ValueError('limit must be positive')
    if args.imaginary_threshold <= 0:
        raise ValueError('imaginary-threshold must be positive')
    output = Path(args.output)
    if output.exists():
        raise FileExistsError('Choose a new output directory to preserve previous evaluations')
    hi, hi_path = load_run(args.hi_run, 'Hi', args.device, meta['cutoff_angstrom'])
    hij, hij_path = load_run(args.hij_run, 'Hij', args.device, meta['cutoff_angstrom'])
    dataset = OpenSpecLmdbDataset(root/'equiformer_v3/test.lmdb')
    table = pd.read_parquet(root/'benchmark_split.parquet')
    table = table[table['split'] == 'test'].set_index('sample_id', verify_integrity=True)
    if set(dataset._keys) != {str(x).encode() for x in table.index}:
        raise ValueError('Test split and LMDB keys disagree')
    payload = Path(args.payload or meta['payload'])
    # Validate the source index, not just a row number in another release.
    index = pd.read_parquet(payload/'index.parquet').set_index('sample_id', verify_integrity=True)
    for field in ('shard', 'row_in_shard'):
        if not (table[field] == index.loc[table.index, field]).all():
            raise ValueError('Payload index differs from prepared data')
    key_index = {key.decode(): i for i, key in enumerate(dataset._keys)}
    selected = table.sort_index().head(args.limit) if args.limit else table.sort_index()
    records, frequencies = [], []
    with torch.inference_mode(), tqdm(total=len(selected), desc='Joint Hessian test') as bar:
        for shard, rows in selected.groupby('shard', sort=True):
            with h5py.File(payload/f'{shard}.h5', 'r') as source:
                for sample_id, row in rows.iterrows():
                    data = dataset[key_index[str(sample_id)]]
                    idx = int(row.row_in_shard)
                    z = read_array(source, 'atomic_numbers', idx).reshape(-1).astype(int)
                    pos = read_array(source, 'coordinates', idx).reshape(-1, 3)
                    reference = read_array(source, 'hessian', idx)*HESSIAN_AU_TO_EV_ANGSTROM2
                    if not np.array_equal(z, data.atomic_numbers.numpy()) or not np.allclose(pos, data.pos.numpy(), atol=2e-6):
                        raise ValueError(f'{sample_id}: source geometry mismatch')
                    edges = data.edge_index.numpy()
                    truncated = assemble(data.Hi.numpy(), data.Hij.numpy(), edges)
                    blocks = reference.reshape(len(z),3,len(z),3)
                    if not np.allclose(data.Hi.numpy(), blocks[np.arange(len(z)),:,np.arange(len(z)),:], atol=1e-5, rtol=1e-5) or not np.allclose(data.Hij.numpy(), blocks[edges[1],:,edges[0],:], atol=1e-5, rtol=1e-5):
                        raise ValueError(f'{sample_id}: source Hessian mismatch')
                    batch = Batch.from_data_list([data]).to(args.device)
                    pred = assemble(hi(batch)['Hi'].cpu().numpy(), hij(batch)['Hij'].cpu().numpy(), edges)
                    matrices = {'reference': reference, 'cutoff_reference': truncated, 'prediction': pred}
                    record = {'sample_id': sample_id, 'source_dataset': row.source_dataset,
                              'natoms': len(z), 'edge_count': edges.shape[1]}
                    fs = {}
                    for name, matrix in matrices.items():
                        metrics, fs[name] = physics(matrix, pos, atomic_masses[z], args.imaginary_threshold)
                        record.update({f'{name}_{k}': v for k,v in metrics.items()})
                    for name in ('prediction', 'cutoff_reference'):
                        # Keep raw and symmetrized errors separate; no PSD correction.
                        for kind, matrix in [('raw', matrices[name]), ('symmetric', (matrices[name]+matrices[name].T)/2)]:
                            record.update({f'{name}_{kind}_{k}': v for k,v in matrix_errors(matrix, reference).items()})
                        delta = fs[name]-fs['reference']
                        record[f'{name}_frequency_mae_cm1'] = float(np.abs(delta).mean()) if len(delta) else None
                        record[f'{name}_frequency_rmse_cm1'] = float(np.sqrt(np.square(delta).mean())) if len(delta) else None
                        record[f'{name}_excess_imaginary_count'] = max(0, record[f'{name}_imaginary_count']-record['reference_imaginary_count'])
                    records.append(record)
                    frequencies.append({'sample_id': sample_id, **{k:v.tolist() for k,v in fs.items()}})
                    bar.update()
    output.mkdir(parents=True)
    frame = pd.DataFrame(records)
    frame.to_parquet(output/'per_molecule.parquet', index=False)
    pd.DataFrame(frequencies).to_parquet(output/'frequencies.parquet', index=False)
    summary = {'records': len(frame), 'split': 'test', 'partial': args.limit is not None,
               'hi_checkpoint': hi_path, 'hij_checkpoint': hij_path,
               'cutoff_angstrom': meta['cutoff_angstrom'], 'hessian_unit': 'eV/Angstrom^2',
               'frequency_scale': 1., 'imaginary_threshold_cm1': args.imaginary_threshold,
               'mass_convention': 'ASE standard atomic masses; isotope-specific masses unavailable',
               'aggregation': 'molecule-macro means, not component-weighted training metrics',
               'means': frame.select_dtypes(include='number').mean().to_dict()}
    (output/'summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False)+'\n')
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hi-run', required=True)
    parser.add_argument('--hij-run', required=True)
    parser.add_argument('--data-dir', required=True)
    parser.add_argument('--payload', help='Override full frequency payload location')
    parser.add_argument('--output', required=True)
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--limit', type=int, help='Smoke test only; omit for full test set')
    parser.add_argument('--imaginary-threshold', type=float, default=20.)
    print(json.dumps(run(parser.parse_args()), indent=2))


if __name__ == '__main__':
    main()
