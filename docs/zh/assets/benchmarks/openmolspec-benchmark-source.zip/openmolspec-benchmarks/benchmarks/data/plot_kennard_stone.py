"""Preview nested fingerprint-based Kennard--Stone training selections.

The command deliberately does not persist molecule IDs or split files. It
computes a deterministic, stratified approximate Kennard--Stone curriculum in
memory and writes only a diagnostic matplotlib figure.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd
from tqdm import tqdm


DESCRIPTOR_NAMES = (
    "molecular_weight",
    "heavy_atoms",
    "hetero_atoms",
    "rings",
    "rotatable_bonds",
    "formal_charge",
    "fraction_csp3",
    "tpsa",
)
DEFAULT_SIZES = (200_000, 400_000, 600_000, 800_000)

_MORGAN_GENERATOR = None
_PROJECTION = None


def _stable_u64(value: str, seed: int) -> np.uint64:
    payload = f"{seed}:{value}".encode("utf-8")
    return np.uint64(int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), "big"))


def _stable_hashes(values: Iterable[object], seed: int) -> np.ndarray:
    cache: dict[str, np.uint64] = {}
    output = []
    for value in values:
        text = str(value)
        hashed = cache.get(text)
        if hashed is None:
            hashed = _stable_u64(text, seed)
            cache[text] = hashed
        output.append(hashed)
    return np.asarray(output, dtype=np.uint64)


def _init_featurizer(seed: int, fingerprint_bits: int, projection_dims: int) -> None:
    global _MORGAN_GENERATOR, _PROJECTION

    from rdkit import RDLogger
    from rdkit.Chem import rdFingerprintGenerator

    RDLogger.DisableLog("rdApp.*")
    _MORGAN_GENERATOR = rdFingerprintGenerator.GetMorganGenerator(
        radius=2, fpSize=fingerprint_bits
    )
    rng = np.random.default_rng(seed)
    _PROJECTION = rng.choice(
        np.asarray([-1.0, 1.0], dtype=np.float32),
        size=(fingerprint_bits, projection_dims),
    ) / np.sqrt(float(fingerprint_bits))


def _molecule_features(smiles: str) -> tuple[np.ndarray, bool]:
    from rdkit import Chem, DataStructs
    from rdkit.Chem import Descriptors, rdMolDescriptors

    feature_count = len(DESCRIPTOR_NAMES) + int(_PROJECTION.shape[1])
    try:
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            return np.full(feature_count, np.nan, dtype=np.float32), False
        descriptors = np.asarray(
            [
                Descriptors.MolWt(molecule),
                molecule.GetNumHeavyAtoms(),
                rdMolDescriptors.CalcNumHeteroatoms(molecule),
                rdMolDescriptors.CalcNumRings(molecule),
                rdMolDescriptors.CalcNumRotatableBonds(molecule),
                Chem.GetFormalCharge(molecule),
                rdMolDescriptors.CalcFractionCSP3(molecule),
                rdMolDescriptors.CalcTPSA(molecule),
            ],
            dtype=np.float32,
        )
        fingerprint = _MORGAN_GENERATOR.GetFingerprint(molecule)
        bits = np.zeros(_PROJECTION.shape[0], dtype=np.float32)
        DataStructs.ConvertToNumpyArray(fingerprint, bits)
        projected = bits @ _PROJECTION
        return np.concatenate((descriptors, projected)).astype(np.float32), True
    except Exception:
        return np.full(feature_count, np.nan, dtype=np.float32), False


def featurize_smiles(
    smiles: Sequence[str],
    *,
    workers: int,
    seed: int,
    fingerprint_bits: int,
    projection_dims: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return molecular descriptors plus a signed Morgan projection."""

    matrix = np.empty(
        (len(smiles), len(DESCRIPTOR_NAMES) + projection_dims), dtype=np.float32
    )
    valid = np.empty(len(smiles), dtype=bool)
    if workers <= 1:
        _init_featurizer(seed, fingerprint_bits, projection_dims)
        iterator = map(_molecule_features, smiles)
        for index, (features, success) in enumerate(
            tqdm(iterator, total=len(smiles), desc="Morgan fingerprints")
        ):
            matrix[index] = features
            valid[index] = success
        return matrix, valid

    context = mp.get_context("fork")
    with context.Pool(
        processes=workers,
        initializer=_init_featurizer,
        initargs=(seed, fingerprint_bits, projection_dims),
    ) as pool:
        iterator = pool.imap(_molecule_features, smiles, chunksize=512)
        for index, (features, success) in enumerate(
            tqdm(iterator, total=len(smiles), desc="Morgan fingerprints")
        ):
            matrix[index] = features
            valid[index] = success
    return matrix, valid


def robust_standardize(features: np.ndarray) -> np.ndarray:
    """Median/IQR scale features while keeping malformed molecules finite."""

    median = np.nanmedian(features, axis=0)
    q25, q75 = np.nanpercentile(features, (25, 75), axis=0)
    scale = q75 - q25
    standard_deviation = np.nanstd(features, axis=0)
    scale = np.where(scale > 1e-8, scale, np.where(standard_deviation > 1e-8, standard_deviation, 1.0))
    filled = np.where(np.isfinite(features), features, median)
    return np.clip((filled - median) / scale, -8.0, 8.0).astype(np.float32)


def kennard_stone_order(features: np.ndarray, tie_breaker: np.ndarray) -> np.ndarray:
    """Return a deterministic maximin order using a two-sweep KS start."""

    count = len(features)
    if count <= 1:
        return np.arange(count, dtype=np.int64)
    centroid = features.mean(axis=0)
    first_distances = np.sum((features - centroid) ** 2, axis=1)
    first_candidates = np.flatnonzero(first_distances == first_distances.max())
    first = first_candidates[np.argmin(tie_breaker[first_candidates])]

    selected = np.zeros(count, dtype=bool)
    selected[first] = True
    order = np.empty(count, dtype=np.int64)
    order[0] = first
    minimum_distance = np.sum((features - features[first]) ** 2, axis=1)
    minimum_distance[first] = -np.inf
    for position in range(1, count):
        maximum = minimum_distance.max()
        candidates = np.flatnonzero(minimum_distance == maximum)
        choice = candidates[np.argmin(tie_breaker[candidates])]
        order[position] = choice
        selected[choice] = True
        distances = np.sum((features - features[choice]) ** 2, axis=1)
        minimum_distance = np.minimum(minimum_distance, distances)
        minimum_distance[selected] = -np.inf
    return order


def _bin(values: np.ndarray, boundaries: Sequence[float]) -> np.ndarray:
    return np.digitize(values, np.asarray(boundaries), right=False).astype(np.int16)


def _parent_strata(frame: pd.DataFrame, raw_features: np.ndarray) -> np.ndarray:
    descriptors = raw_features[:, : len(DESCRIPTOR_NAMES)].copy()
    medians = np.nanmedian(descriptors, axis=0)
    descriptors = np.where(np.isfinite(descriptors), descriptors, medians)
    source = pd.Categorical(frame["align_source"].astype(str)).codes.astype(np.int64)
    components = (
        source,
        _bin(descriptors[:, 1], (8, 12, 16, 20, 25, 30, 40)),
        _bin(descriptors[:, 0], (100, 150, 200, 250, 300, 400, 600)),
        _bin(descriptors[:, 2], (1, 2, 3, 4, 6, 10)),
        _bin(descriptors[:, 3], (1, 2, 3, 4, 6)),
        np.sign(descriptors[:, 5]).astype(np.int16) + 1,
    )
    code = np.zeros(len(frame), dtype=np.int64)
    for component in components:
        base = int(component.max()) + 1
        code = code * base + component
    return pd.factorize(code, sort=True)[0].astype(np.int64)


def nested_kennard_stone_rank(
    frame: pd.DataFrame,
    raw_features: np.ndarray,
    *,
    seed: int,
    target_group_size: int = 128,
) -> np.ndarray:
    """Create one nested, source/size-stratified approximate KS curriculum."""

    if len(frame) != len(raw_features):
        raise ValueError("frame and feature matrix must have the same length")
    if target_group_size < 2:
        raise ValueError("target_group_size must be at least 2")

    features = robust_standardize(raw_features)
    parent = _parent_strata(frame, raw_features)
    parent_sizes = np.bincount(parent)
    bucket_counts = np.maximum(
        1, np.ceil(parent_sizes / float(target_group_size)).astype(np.int64)
    )
    scaffold_hash = _stable_hashes(frame["split_scaffold"].fillna(""), seed + 11)
    molecule_hash = _stable_hashes(frame["inchikey"].fillna(""), seed + 29)
    bucket = scaffold_hash % bucket_counts[parent].astype(np.uint64)
    micro_key = parent.astype(np.uint64) << np.uint64(32)
    micro_key |= bucket
    micro = pd.factorize(micro_key, sort=True)[0].astype(np.int64)

    sort_index = np.argsort(micro, kind="stable")
    sorted_micro = micro[sort_index]
    boundaries = np.r_[0, np.flatnonzero(np.diff(sorted_micro)) + 1, len(frame)]
    local_rank = np.empty(len(frame), dtype=np.int64)
    micro_size = np.empty(len(frame), dtype=np.int64)

    for start, stop in tqdm(
        zip(boundaries[:-1], boundaries[1:]),
        total=len(boundaries) - 1,
        desc="Stratified Kennard-Stone",
    ):
        indices = sort_index[start:stop]
        micro_size[indices] = len(indices)
        local_sort = indices[
            np.lexsort((molecule_hash[indices], scaffold_hash[indices]))
        ]
        local_scaffolds = scaffold_hash[local_sort]
        unique_starts = np.r_[0, np.flatnonzero(np.diff(local_scaffolds)) + 1]
        unique_stops = np.r_[unique_starts[1:], len(local_sort)]
        scaffold_members = [
            local_sort[left:right] for left, right in zip(unique_starts, unique_stops)
        ]
        if len(scaffold_members) == 1:
            ordered = local_sort
        else:
            pieces = []
            for occurrence in range(max(len(values) for values in scaffold_members)):
                candidates = np.asarray(
                    [values[occurrence] for values in scaffold_members if occurrence < len(values)],
                    dtype=np.int64,
                )
                ks = kennard_stone_order(
                    features[candidates], molecule_hash[candidates]
                )
                pieces.append(candidates[ks])
            ordered = np.concatenate(pieces)
        local_rank[ordered] = np.arange(len(ordered), dtype=np.int64)

    micro_priority = (local_rank.astype(np.float64) + 0.5) / micro_size

    # First interleave the randomized micro-groups within each chemically
    # meaningful parent stratum, then interleave parent strata according to
    # their exact population. This retains local KS diversity while keeping
    # every prefix close to the full source/size distribution.
    within_parent = np.lexsort((molecule_hash, micro_priority, parent))
    sorted_parent = parent[within_parent]
    parent_starts = np.r_[0, np.flatnonzero(np.diff(sorted_parent)) + 1]
    parent_stops = np.r_[parent_starts[1:], len(frame)]
    parent_local_rank = np.empty(len(frame), dtype=np.int64)
    for start, stop in zip(parent_starts, parent_stops):
        parent_local_rank[within_parent[start:stop]] = np.arange(stop - start)
    parent_priority = (
        parent_local_rank.astype(np.float64) + 0.5
    ) / parent_sizes[parent]
    source = pd.Categorical(frame["align_source"].astype(str)).codes.astype(np.int64)
    within_source = np.lexsort((molecule_hash, parent_priority, source))
    sorted_source = source[within_source]
    source_starts = np.r_[0, np.flatnonzero(np.diff(sorted_source)) + 1]
    source_stops = np.r_[source_starts[1:], len(frame)]
    source_local_rank = np.empty(len(frame), dtype=np.int64)
    for start, stop in zip(source_starts, source_stops):
        source_local_rank[within_source[start:stop]] = np.arange(stop - start)
    source_sizes = np.bincount(source)
    priority = (
        source_local_rank.astype(np.float64) + 0.5
    ) / source_sizes[source]
    order = np.lexsort((molecule_hash, priority))
    rank = np.empty(len(frame), dtype=np.int64)
    rank[order] = np.arange(1, len(frame) + 1, dtype=np.int64)
    return rank


def _pca_2d(features: np.ndarray) -> np.ndarray:
    centered = features - features.mean(axis=0, keepdims=True)
    covariance = centered.T @ centered / max(len(centered) - 1, 1)
    _, eigenvectors = np.linalg.eigh(covariance)
    return centered @ eigenvectors[:, -2:]


def _display_fingerprints(smiles: Sequence[str], fingerprint_bits: int) -> np.ndarray:
    """Build exact Morgan bit vectors for the bounded visualization sample."""

    from rdkit import Chem, DataStructs
    from rdkit.Chem import rdFingerprintGenerator

    generator = rdFingerprintGenerator.GetMorganGenerator(
        radius=2, fpSize=fingerprint_bits
    )
    matrix = np.zeros((len(smiles), fingerprint_bits), dtype=np.uint8)
    for index, value in enumerate(
        tqdm(smiles, desc="Display fingerprints", unit="molecule")
    ):
        molecule = Chem.MolFromSmiles(value)
        if molecule is None:
            continue
        fingerprint = generator.GetFingerprint(molecule)
        DataStructs.ConvertToNumpyArray(fingerprint, matrix[index])
    return matrix


def _tsne_2d(features: np.ndarray, *, seed: int, perplexity: float) -> np.ndarray:
    """Embed a bounded display sample; t-SNE is not used for selection."""

    from sklearn.decomposition import PCA
    from sklearn.manifold import TSNE

    components = min(50, features.shape[1], len(features) - 1)
    reduced = PCA(
        n_components=components,
        svd_solver="randomized",
        random_state=seed,
    ).fit_transform(features)
    effective_perplexity = min(float(perplexity), max(5.0, (len(features) - 1) / 3))
    model = TSNE(
        n_components=2,
        perplexity=effective_perplexity,
        learning_rate="auto",
        init="pca",
        max_iter=1_000,
        random_state=seed,
        method="barnes_hut",
        angle=0.5,
        n_jobs=-1,
        verbose=1,
    )
    return model.fit_transform(reduced).astype(np.float32)


def _grid_coverage(coordinates: np.ndarray, indices: np.ndarray, bins: int = 80) -> float:
    lower = np.quantile(coordinates, 0.005, axis=0)
    upper = np.quantile(coordinates, 0.995, axis=0)
    scaled = (coordinates[indices] - lower) / np.maximum(upper - lower, 1e-8)
    valid = np.all((scaled >= 0.0) & (scaled <= 1.0), axis=1)
    cells = np.floor(scaled[valid] * (bins - 1)).astype(np.int32)
    occupied = np.unique(cells[:, 0] * bins + cells[:, 1]).size
    return float(occupied / (bins * bins))


def plot_selection(
    frame: pd.DataFrame,
    raw_features: np.ndarray,
    rank: np.ndarray,
    *,
    sizes: Sequence[int],
    seed: int,
    output: Path,
    display_molecules: int,
    tsne_perplexity: float,
    fingerprint_bits: int,
) -> dict[str, object]:
    """Plot chemical-space selections and coverage against random sampling."""

    import matplotlib.pyplot as plt

    standardized = robust_standardize(raw_features)
    coordinates = _pca_2d(standardized)
    molecule_hash = _stable_hashes(frame["inchikey"], seed + 101)
    random_order = np.argsort(molecule_hash)
    ks_order = np.argsort(rank)
    scaffold_codes = pd.factorize(frame["split_scaffold"].fillna(""), sort=True)[0]
    full_source = frame["align_source"].value_counts(normalize=True)

    scaffold_ks = []
    scaffold_random = []
    grid_ks = []
    grid_random = []
    source_tv_ks = []
    source_tv_random = []
    total_scaffolds = np.unique(scaffold_codes).size
    for size in sizes:
        selected = ks_order[:size]
        random = random_order[:size]
        scaffold_ks.append(np.unique(scaffold_codes[selected]).size / total_scaffolds)
        scaffold_random.append(np.unique(scaffold_codes[random]).size / total_scaffolds)
        grid_ks.append(_grid_coverage(coordinates, selected))
        grid_random.append(_grid_coverage(coordinates, random))
        for indices, target in ((selected, source_tv_ks), (random, source_tv_random)):
            observed = frame.iloc[indices]["align_source"].value_counts(normalize=True)
            aligned = full_source.to_frame("full").join(observed.rename("sample"), how="outer").fillna(0)
            target.append(float(0.5 * np.abs(aligned["full"] - aligned["sample"]).sum()))

    display_count = min(int(display_molecules), len(frame))
    display_indices = random_order[:display_count]
    fingerprint_features = _display_fingerprints(
        frame.iloc[display_indices]["canonical_smiles"].astype(str).tolist(),
        fingerprint_bits,
    )
    display_coordinates = _tsne_2d(
        fingerprint_features, seed=seed, perplexity=tsne_perplexity
    )
    point_size = np.clip(40_000.0 / display_count, 1.5, 6.0)

    figure = plt.figure(figsize=(25, 12), constrained_layout=True)
    grid = figure.add_gridspec(2, 12, height_ratios=(1.35, 0.9))
    selected_color = "#1764AB"
    unselected_color = "#F28E2B"
    for column, size in enumerate(sizes):
        axis = figure.add_subplot(grid[0, column * 3 : column * 3 + 3])
        selected_mask = rank[display_indices] <= size
        layers = [
            (
                selected_mask,
                selected_color,
                f"Selected: {selected_mask.sum():,} shown ({size // 1000}k total)",
            ),
            (
                ~selected_mask,
                unselected_color,
                f"Unselected: {(~selected_mask).sum():,} shown "
                f"({(len(frame) - size) // 1000}k total)",
            ),
        ]
        # Draw the majority first so the minority class remains visible.
        for mask, color, label in sorted(layers, key=lambda item: -item[0].sum()):
            axis.scatter(
                display_coordinates[mask, 0],
                display_coordinates[mask, 1],
                s=point_size,
                c=color,
                alpha=0.68,
                linewidths=0,
                rasterized=True,
                label=label,
            )
        axis.set_title(f"{size // 1000}k nested subset", fontsize=18, weight="bold")
        axis.set_xlabel("Morgan fingerprint t-SNE 1", fontsize=13)
        if column == 0:
            axis.set_ylabel("Morgan fingerprint t-SNE 2", fontsize=13)
        axis.legend(
            frameon=True,
            facecolor="white",
            framealpha=0.9,
            fontsize=10,
            loc="best",
            markerscale=2.4,
        )
        axis.tick_params(labelsize=10)

    x = np.asarray(sizes) / 1000
    axis = figure.add_subplot(grid[1, :5])
    axis.plot(x, scaffold_ks, "o-", color="#276FBF", linewidth=2.8, label="Stratified KS")
    axis.plot(x, scaffold_random, "o--", color="#777777", linewidth=2.2, label="Random")
    axis.set_xlabel("Training molecules (thousands)", fontsize=14)
    axis.set_ylabel("Fraction of full-train scaffolds covered", fontsize=14)
    axis.set_title("Bemis–Murcko scaffold coverage", fontsize=17, weight="bold")
    axis.grid(alpha=0.2)
    axis.legend(frameon=False, fontsize=12)
    axis.tick_params(labelsize=11)

    axis = figure.add_subplot(grid[1, 5:9])
    axis.plot(x, grid_ks, "o-", color="#2A9D8F", linewidth=2.8, label="Stratified KS")
    axis.plot(x, grid_random, "o--", color="#777777", linewidth=2.2, label="Random")
    axis.set_xlabel("Training molecules (thousands)", fontsize=14)
    axis.set_ylabel("Occupied fingerprint-PCA grid", fontsize=14)
    axis.set_title("Chemical-space coverage", fontsize=17, weight="bold")
    axis.grid(alpha=0.2)
    axis.legend(frameon=False, fontsize=11)
    axis.tick_params(labelsize=11)

    axis = figure.add_subplot(grid[1, 9:])
    axis.plot(x, source_tv_ks, "o-", color="#E76F51", linewidth=2.8, label="Stratified KS")
    axis.plot(x, source_tv_random, "o--", color="#777777", linewidth=2.2, label="Random")
    axis.set_xlabel("Training molecules (thousands)", fontsize=14)
    axis.set_ylabel("Source total-variation distance", fontsize=14)
    axis.set_title("Source representativeness (lower is better)", fontsize=17, weight="bold")
    axis.grid(alpha=0.2)
    axis.legend(frameon=False, fontsize=11)
    axis.tick_params(labelsize=11)

    figure.suptitle(
        "OpenMolSpec nested training-set preview: stratified approximate Kennard–Stone\n"
        f"Blue = selected, orange = unselected in one fixed {display_count:,}-molecule "
        "t-SNE display sample",
        fontsize=23,
        weight="bold",
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output, dpi=220, bbox_inches="tight")
    plt.close(figure)
    return {
        "output": str(output),
        "training_pool": int(len(frame)),
        "sizes": list(map(int, sizes)),
        "scaffold_coverage_ks": scaffold_ks,
        "scaffold_coverage_random": scaffold_random,
        "fingerprint_grid_coverage_ks": grid_ks,
        "fingerprint_grid_coverage_random": grid_random,
        "source_tv_ks": source_tv_ks,
        "source_tv_random": source_tv_random,
        "tsne_display_molecules": display_count,
        "tsne_perplexity": float(tsne_perplexity),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Plot an in-memory fingerprint Kennard-Stone scaling preview"
    )
    parser.add_argument(
        "--split-file",
        default="builds/openmolspec-20260830/release-v1/splits/align_split.parquet",
    )
    parser.add_argument("--sizes", nargs="+", type=int, default=list(DEFAULT_SIZES))
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--seed", type=int, default=2025)
    parser.add_argument("--fingerprint-bits", type=int, default=512)
    parser.add_argument("--projection-dims", type=int, default=24)
    parser.add_argument("--target-group-size", type=int, default=128)
    parser.add_argument(
        "--display-molecules",
        type=int,
        default=20_000,
        help="Deterministic full-pool sample used only for the t-SNE figure",
    )
    parser.add_argument("--tsne-perplexity", type=float, default=50.0)
    parser.add_argument(
        "--output",
        default="artifacts/figures/openmolspec_kennard_stone_preview.png",
    )
    parser.add_argument(
        "--max-molecules",
        type=int,
        default=None,
        help="Optional deterministic development cap; omit for the full train split",
    )
    args = parser.parse_args()
    if args.display_molecules < 100:
        raise ValueError("--display-molecules must be at least 100")
    if args.tsne_perplexity <= 0:
        raise ValueError("--tsne-perplexity must be positive")

    split = pd.read_parquet(
        args.split_file,
        columns=[
            "inchikey", "canonical_smiles", "split_scaffold", "align_source", "split"
        ],
    )
    train = split.loc[split["split"].eq("train")].reset_index(drop=True)
    if args.max_molecules and args.max_molecules < len(train):
        hashes = _stable_hashes(train["inchikey"], args.seed + 503)
        train = train.iloc[np.argsort(hashes)[: args.max_molecules]].reset_index(drop=True)
    sizes = tuple(sorted(set(args.sizes)))
    if not sizes or sizes[0] < 1 or sizes[-1] > len(train):
        raise ValueError(f"sizes must lie between 1 and the training pool ({len(train):,})")

    raw_features, valid = featurize_smiles(
        train["canonical_smiles"].astype(str).tolist(),
        workers=args.workers,
        seed=args.seed,
        fingerprint_bits=args.fingerprint_bits,
        projection_dims=args.projection_dims,
    )
    rank = nested_kennard_stone_rank(
        train,
        raw_features,
        seed=args.seed,
        target_group_size=args.target_group_size,
    )
    summary = plot_selection(
        train,
        raw_features,
        rank,
        sizes=sizes,
        seed=args.seed,
        output=Path(args.output),
        display_molecules=args.display_molecules,
        tsne_perplexity=args.tsne_perplexity,
        fingerprint_bits=args.fingerprint_bits,
    )
    summary["fingerprint_failures"] = int((~valid).sum())
    summary["selection_ids_persisted"] = False
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
