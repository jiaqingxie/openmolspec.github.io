"""Rotation-invariant scalar labels from parsed Gaussian properties."""

import numpy as np
from openmolspec.core.constants import BOHR_TO_ANGSTROM, HARTREE_TO_EV

POLAR_TARGETS = ("polar_iso", "polar_anisotropy")
PROPERTY_UNITS = {"dipole_total": "D", "polar_iso": "Angstrom^3",
                  "polar_anisotropy": "Angstrom^3", "gap": "eV"}
ACTIVE_PROPERTY_TARGETS = ("dipole_total", "polar_iso", "gap")


def convert_benchmark_units(record):
    """Convert a freshly parsed record once; annotate units to prevent ambiguity."""
    if "units" in record:
        raise ValueError("Refusing to convert an already unit-tagged record")
    record["gap"] *= HARTREE_TO_EV
    for name in POLAR_TARGETS:
        record[name] *= BOHR_TO_ANGSTROM ** 3
    record["units"] = dict(PROPERTY_UNITS)
    return record


def polar_invariants(value):
    """Return trace/3 and anisotropy in atomic units (Bohr^3).

    Accept a symmetric 3x3 matrix or Gaussian archive order xx,xy,yy,xz,yz,zz.
    Missing or malformed tensors remain missing; never substitute zero labels.
    """
    try:
        tensor = np.asarray(value, dtype=np.float64)
        if tensor.size == 6:
            xx, xy, yy, xz, yz, zz = tensor.reshape(-1)
            tensor = np.array([[xx, xy, xz], [xy, yy, yz], [xz, yz, zz]])
        if tensor.shape != (3, 3) or not np.isfinite(tensor).all():
            raise ValueError("Invalid polarizability")
        if not np.allclose(tensor, tensor.T, atol=1e-6):
            raise ValueError("Asymmetric polarizability")
        iso = float(np.trace(tensor) / 3)
        anisotropy = float(np.sqrt(1.5 * np.sum((tensor - iso * np.eye(3)) ** 2)))
        return iso, anisotropy
    except (TypeError, ValueError):
        return float("nan"), float("nan")
