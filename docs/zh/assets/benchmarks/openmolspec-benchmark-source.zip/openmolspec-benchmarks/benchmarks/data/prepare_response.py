"""Export Cartesian response derivatives from the frozen frequency payload."""
import argparse
import json
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import torch
from torch_geometric.data import Data
from tqdm import tqdm

from benchmarks.data.prepare import _write_lmdb, load_official_split
from benchmarks.data.prepare_hessian import read_array

RESPONSE_UNITS = {"dedipole": "Debye/Angstrom", "depolar": "Bohr^3/Angstrom"}


def response_record(z, pos, dd, dp, sample_id, cutoff=5.0):
    z = np.asarray(z, dtype=np.int64).reshape(-1)
    n = len(z)
    pos = np.asarray(pos).reshape(n, 3)
    dd, dp = np.asarray(dd), np.asarray(dp)
    if dd.shape != (n, 3, 3) or dp.shape != (n, 3, 3, 3):
        raise ValueError(f"{sample_id}: incompatible response shapes")
    if not all(np.isfinite(x).all() for x in (pos, dd, dp)):
        raise ValueError(f"{sample_id}: nonfinite response or geometry")
    if not np.allclose(dp, dp.swapaxes(-1, -2), atol=1e-6):
        raise ValueError(f"{sample_id}: asymmetric polarizability derivative")
    distances = np.linalg.norm(pos[:, None] - pos[None, :], axis=-1)
    if cutoff <= 0 or np.any((distances + np.eye(n)) < 1e-8):
        raise ValueError(f"{sample_id}: invalid graph geometry/cutoff")
    dst, src = np.where((distances < cutoff) & ~np.eye(n, dtype=bool))
    if not len(src):
        raise ValueError(f"{sample_id}: no radius edges")
    return Data(pos=torch.tensor(pos, dtype=torch.float32),
                atomic_numbers=torch.tensor(z), natoms=torch.tensor([n]),
                edge_index=torch.tensor(np.stack((src, dst)), dtype=torch.long),
                dedipole=torch.tensor(dd, dtype=torch.float32),
                depolar=torch.tensor(dp, dtype=torch.float32), sample_id=str(sample_id))


def run(payload, split_file, output, limit_per_split=None, cutoff=5.0):
    payload, output = Path(payload), Path(output)
    if cutoff <= 0 or (limit_per_split is not None and limit_per_split < 1):
        raise ValueError("cutoff and limit must be positive")
    split = load_official_split(str(split_file))
    split["split"] = split["split"].replace({"validation": "eval"})
    if limit_per_split:
        split = split.groupby("split", sort=False).head(limit_per_split).copy()
    index = pd.read_parquet(payload / "index.parquet")
    selected = split.merge(index[["sample_id", "shard", "row_in_shard"]],
                           on="sample_id", how="left", validate="one_to_one")
    if selected["shard"].isna().any():
        raise ValueError("Some split records are missing from frequency payload")
    if any((output / "equiformer_v3" / f"{s}.lmdb").exists()
           for s in ("train", "eval", "test")):
        raise FileExistsError("Choose a new output directory; LMDB already exists")
    counts, audit = {}, []
    for mode in ("train", "eval", "test"):
        subset = selected[selected["split"] == mode]
        if subset.empty:
            raise ValueError(f"Empty {mode} split")
        def records():
            with tqdm(total=len(subset), desc=f"Response {mode}") as progress:
                for shard, rows in subset.groupby("shard", sort=True):
                    with h5py.File(payload / f"{shard}.h5", "r") as handle:
                        # Read each compressed field once per shard for large exports.
                        # Sparse smoke selections can read individual records instead.
                        source = handle
                        if len(rows) > 32:
                            source = {"arrays": {
                                name: {key: handle["arrays"][name][key][:]
                                       for key in ("values", "offsets", "shapes", "present")}
                                for name in ("atomic_numbers", "coordinates", "dipole_deriv", "polar_deriv")}}
                        for row in rows.itertuples():
                            arrays = [read_array(source, name, int(row.row_in_shard))
                                      for name in ("atomic_numbers", "coordinates", "dipole_deriv", "polar_deriv")]
                            data = response_record(
                                *arrays, row.sample_id, cutoff=cutoff)
                            data.source_dataset = row.source_dataset
                            data.inchikey = row.inchikey
                            audit.append({"sample_id": row.sample_id, "split": mode})
                            yield row.sample_id, data
                            progress.update()
        counts[mode] = _write_lmdb(
            output / "equiformer_v3" / f"{mode}.lmdb", records(),
            map_size=200 * 1024**3,
        )
    selected.to_parquet(output / "benchmark_split.parquet", index=False)
    pd.DataFrame(audit).to_parquet(output / "response_records.parquet", index=False)
    summary = {"counts": counts, "cutoff_angstrom": cutoff,
               "response_units": RESPONSE_UNITS,
               "axes": {"dedipole": "atom,coordinate,dipole",
                        "depolar": "atom,coordinate,polarization,polarization"},
               "label_conversion": "none; preserve released parser-converted values",
               "payload": str(payload.resolve()), "split_file": str(Path(split_file).resolve()),
               "limit_per_split": limit_per_split}
    (output / "summary.json").write_text(json.dumps(summary, indent=2)+"\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", default="builds/openmolspec-20260830/release-v1/payload/frequency")
    parser.add_argument("--split-file", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--limit-per-split", type=int)
    parser.add_argument("--cutoff", type=float, default=5.0)
    print(json.dumps(run(**vars(parser.parse_args())), indent=2))


if __name__ == "__main__":
    main()
