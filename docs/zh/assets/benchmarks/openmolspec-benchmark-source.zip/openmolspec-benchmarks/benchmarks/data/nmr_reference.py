"""Referenced H/C computed shifts, never experimental or atom-assigned spectra."""

import hashlib
import re
from pathlib import Path

import numpy as np


def load_tms_reference(path):
    path = Path(path)
    raw = path.read_bytes()
    text = raw.decode("utf-8", errors="replace")
    if "Optimization completed." not in text or "Error termination" in text:
        raise ValueError("TMS optimization failed or is incomplete")
    if not text.rstrip().splitlines()[-1].strip().startswith("Normal termination"):
        raise ValueError("TMS log has not terminated normally")
    frequencies = [float(x) for line in re.findall(r"Frequencies --([^\n]+)", text)
                   for x in line.split()]
    if len(frequencies) != 45 or not np.isfinite(frequencies).all() or min(frequencies) <= 0:
        raise ValueError("TMS must have 45 positive vibrational frequencies")
    # The reference is specific to the production template, including its IOPs.
    compact = re.sub(r"\s+", "", text).upper()
    for keyword in ("B3LYP/6-311+G**", "EM=GD3BJ", "INT=ULTRAFINE",
                    "OPBE/6-311+G(2D,P)", "3/76=0770002300",
                    "3/77=1000010000", "3/78=1000010000"):
        if keyword not in compact:
            raise ValueError(f"Reference is missing required method setting: {keyword}")
    matches = re.findall(r"^\s*\d+\s+([A-Za-z]+)\s+Isotropic\s*=\s*([-+\d.EeDd]+)",
                         text, re.MULTILINE)
    if len(matches) != 17:
        raise ValueError("Expected exactly one 17-atom TMS shielding block")
    groups = {element: [float(v.replace("D", "E").replace("d", "e"))
                         for e, v in matches if e == element]
              for element in ("H", "C", "Si")}
    if {e: len(v) for e, v in groups.items()} != {"H": 12, "C": 4, "Si": 1}:
        raise ValueError("Reference composition is not TMS")
    if not all(np.isfinite(v).all() for v in groups.values()):
        raise ValueError("Nonfinite reference shielding")
    return {
        "id": "tms-" + hashlib.sha256(raw).hexdigest()[:16],
        "source_log": str(path.resolve()), "source_sha256": hashlib.sha256(raw).hexdigest(),
        "sigma_ref_ppm": {e: float(np.mean(groups[e])) for e in ("H", "C")},
        "sigma_range_ppm": {e: [min(groups[e]), max(groups[e])] for e in ("H", "C")},
        "geometry_method": "B3LYP/6-311+G(d,p) D3BJ int=ultrafine nosymm",
        "nmr_method": "OPBE/6-311+G(2d,p) NMR IOP(3/76=0770002300,3/77=1000010000,3/78=1000010000)",
        "solvent": "gas phase", "unit": "ppm", "formula": "delta = sigma_ref - sigma",
        "kind": "computed referenced shifts; not experimentally calibrated",
        "frequency_count": len(frequencies), "minimum_frequency_cm-1": min(frequencies),
    }


def hc_shift_record(atomic_numbers, shielding, reference):
    z = np.asarray(atomic_numbers)
    sigma = np.asarray(shielding, dtype=np.float64)
    if z.ndim != 1 or sigma.shape != z.shape or not len(z):
        raise ValueError("NMR atomic numbers and shielding must be aligned 1D arrays")
    if not np.isfinite(z).all() or not np.equal(z, np.floor(z)).all() or np.any((z < 1) | (z > 118)):
        raise ValueError("Invalid NMR atomic numbers")
    if not np.isfinite(sigma).all():
        raise ValueError("Nonfinite NMR shielding")
    result = {"nmr_reference_id": reference["id"], "nmr_shift_unit": "ppm",
              "nmr_representation": "sorted_per_atom_shifts_unassigned_no_grouping_no_J",
              "nmr_quality_flags": []}
    for element, number, label in (("H", 1, "h"), ("C", 6, "c")):
        values = np.sort(reference["sigma_ref_ppm"][element] - sigma[z == number]).astype(np.float32)
        result[f"nmr_{label}_shifts_ppm"] = values
        result[f"nmr_{label}_present"] = bool(len(values))
        if not len(values):
            result["nmr_quality_flags"].append(f"no_{element}_nuclei")
    # No atom indices/assignments, no clipping, no per-molecule min-max, no fake integrals.
    return result
