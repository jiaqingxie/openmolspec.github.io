"""Copy frozen KS subsets from a prepared Vib2Mol LMDB, without reprocessing."""

import argparse
import json
from pathlib import Path

import lmdb
import pandas as pd
from tqdm import tqdm


def copy_records(source, target, keys):
    """Preserve serialized values exactly; read sorted keys in bounded batches."""
    reader = lmdb.open(str(source), subdir=False, readonly=True, lock=False,
                       readahead=True)
    try:
        writer = lmdb.open(str(target), subdir=False,
                           map_size=max(1 << 30, source.stat().st_size * 2))
        try:
            with reader.begin() as read:
                for start in tqdm(range(0, len(keys), 8192),
                                  desc=target.stem, unit="batch"):
                    with writer.begin(write=True) as write:
                        for key in keys[start:start + 8192]:
                            value = read.get(key)
                            if value is None:
                                raise ValueError(f"Missing record {key!r} in {source}")
                            write.put(key, value)
            writer.sync()
        finally:
            writer.close()
    finally:
        reader.close()


def run(data_dir, split_file, output):
    data_dir, split_file, output = map(Path, (data_dir, split_file, output))
    if output.exists():
        raise FileExistsError(f"Output already exists; use a new directory: {output}")
    if data_dir.resolve() in output.resolve().parents:
        raise ValueError("Output must not be inside the source dataset")
    selected = pd.read_parquet(split_file)
    selected = selected.rename(columns={"align_sample_id": "sample_id",
                                         "align_source": "source_dataset"})
    source_index = pd.read_parquet(data_dir / "benchmark_split.parquet")
    for index in (selected, source_index):
        if not {"sample_id", "split"}.issubset(index.columns):
            raise ValueError("Split index requires sample_id and split")
        if index.sample_id.isna().any() or index.sample_id.duplicated().any():
            raise ValueError("Split index has missing or duplicate sample IDs")
        index["sample_id"] = index.sample_id.astype(str)
        index["split"] = index.split.replace({"validation": "eval"})
        if not set(index.split).issubset({"train", "eval", "test"}):
            raise ValueError("Unknown split label")
    keys_by_split = {}
    for mode in ("train", "eval", "test"):
        wanted = set(selected.loc[selected.split == mode, "sample_id"])
        available = set(source_index.loc[source_index.split == mode, "sample_id"])
        if not wanted or not wanted.issubset(available):
            raise ValueError(f"{mode}: empty subset or IDs outside source split")
        if mode != "train" and wanted != available:
            raise ValueError(f"{mode}: held-out IDs must match the source exactly")
        source = data_dir / "vib2mol" / f"openspec_{mode}.lmdb"
        if not source.is_file():
            raise FileNotFoundError(source)
        keys_by_split[mode] = sorted(key.encode() for key in wanted)
    destination = output / "vib2mol"
    destination.mkdir(parents=True)
    summary = {"state": "building", "source": str(data_dir.resolve()),
               "split_file": str(split_file.resolve()), "values_byte_identical": True,
               "splits": {mode: len(keys) for mode, keys in keys_by_split.items()}}
    summary_path = output / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    for mode, keys in keys_by_split.items():
        copy_records(data_dir / "vib2mol" / f"openspec_{mode}.lmdb",
                     destination / f"openspec_{mode}.lmdb", keys)
    selected.to_parquet(output / "benchmark_split.parquet", index=False)
    # Retain provenance, without presenting the 1M counts as this subset's counts.
    normalization = data_dir / "normalization.json"
    if normalization.is_file():
        summary["source_normalization"] = json.loads(normalization.read_text())
    summary["state"] = "completed"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", default="benchmark_data/release_v1_minmax")
    parser.add_argument("--split-file", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.data_dir, args.split_file, args.output), indent=2))


if __name__ == "__main__":
    main()
