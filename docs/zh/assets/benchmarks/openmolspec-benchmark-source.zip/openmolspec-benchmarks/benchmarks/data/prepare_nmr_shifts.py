"""Build atom-assigned H/C shift graphs from frozen NMR labels and source geometry.

No sorted spectrum labels, atom reordering, or cross-conformer substitutions.
All atoms remain in the graph; only H and C contribute supervised targets.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import time

import h5py
import numpy as np
import pandas as pd
from rdkit import Chem
import torch
from torch_geometric.data import Data
from tqdm import tqdm

from benchmarks.data.nmr_reference import load_tms_reference
from benchmarks.data.prepare import _write_lmdb, load_official_split
from benchmarks.data.prepare_hessian import read_array

NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[DdEe][-+]?\d+)?"
SHIELDING = re.compile(rf"^\s*(\d+)\s+([A-Za-z]+)\s+Isotropic\s*=\s*({NUMBER})", re.M)
ORIENTATION = re.compile(
    r"(?:Input|Standard) orientation:\s*\n\s*-+\n"
    r"[^\n]*Coordinates \(Angstroms\)[^\n]*\n[^\n]*\n\s*-+\n"
    r"(.*?)\n\s*-+", re.S)
TENSOR = re.compile(r'\s+'.join(rf'{axis}\s*=\s*({NUMBER})'
                              for axis in ('XX', 'YX', 'ZX', 'XY', 'YY', 'ZY', 'XZ', 'YZ', 'ZZ')))


def complete_tensor_end(text, shielding, *, require_scf=True):
    """Verify SCF/GIAO provenance and every atom's finite tensor."""
    before = text[:shielding[0].start()]
    if (require_scf and 'SCF Done:' not in before) or 'SCF GIAO Magnetic shielding tensor (ppm):' not in before:
        raise ValueError('NMR calculation did not terminate normally; completion unverified')
    tensor_end = None
    for i, atom in enumerate(shielding):
        end = shielding[i+1].start() if i+1 < len(shielding) else len(text)
        tensors = list(TENSOR.finditer(text, atom.end(), end))
        if len(tensors) != 1 or not all(np.isfinite(float(x.replace('D', 'E').replace('d', 'e')))
                                      for x in tensors[0].groups()):
            raise ValueError('Abnormal termination with incomplete shielding tensors')
        tensor_end = tensors[0].end()
    return tensor_end


def termination_metadata(text, shielding):
    """Salvage only explicitly recognized failures after complete NMR output."""
    if 'Error termination' not in text and text.rstrip().splitlines()[-1].strip().startswith('Normal termination'):
        return dict(normal_termination=True, nmr_completion='normal_termination')
    tensor_end = complete_tensor_end(text, shielding)
    tail = text[tensor_end:]
    if 'Error termination' in text[:tensor_end] or 'Erroneous write.' in text[:tensor_end]:
        raise ValueError('NMR calculation failed before shielding completion')
    # Some Gaussian jobs finish response Link 1002 but lose their internal input
    # before final termination. Do not accept this message without stage evidence.
    finished_response = re.search(r'Leave Link\s+1002\b[^\n]*\n', tail)
    if finished_response and not re.search(r'Error termination|Erroneous write\.', tail[:finished_response.end()]):
        deleted_input = re.fullmatch(
            r'\s*Internal input file was deleted!\s*'
            r'Error termination via Lnk1e[^\n]*\s*', tail[finished_response.end():])
        if deleted_input:
            return dict(normal_termination=False,
                        nmr_completion='complete_shielding_post_nmr_internal_input_deleted')
        # A small number of jobs were externally truncated in Link 601 after
        # Link 1002 had already completed and printed every requested shielding
        # tensor.  Accept only the observed, unambiguous EOF signature: exactly
        # one subsequent Link 601 entry and EOF immediately after Gaussian
        # announces the optional spin-rotation calculation.  The caller still
        # verifies the source hash and every shielding value against the frozen
        # payload, so this does not turn arbitrary truncated logs into labels.
        post_response = tail[finished_response.end():]
        link_entries = list(re.finditer(r'\(Enter [^\n]*[/\\]l(\d+)\.exe\)', post_response))
        spin_rotation = re.search(r'Calculating spin-rotation constants\.\s*\Z', post_response)
        if (len(link_entries) == 1 and link_entries[0][1] == '601'
                and spin_rotation and link_entries[0].end() < spin_rotation.start()
                and not re.search(r'Error termination|Erroneous write\.|Normal termination', post_response)
                and not re.search(r'Leave Link\s+601\b', post_response)):
            return dict(
                normal_termination=False,
                nmr_completion='complete_shielding_post_nmr_link601_spin_rotation_truncation')
        # A few frozen jobs hit Gaussian scratch/file-table corruption while
        # Link 601 was performing optional post-response reporting.  Recover
        # only the two observed I/O signatures, after a clean Link 1002 exit,
        # with Link 601 as the sole subsequent link and an explicit terminal
        # error.  This is intentionally not a generic Link 601 failure rule.
        link601_io_error = (
            re.search(r'FileIO operation on non-existent file\.', post_response)
            or re.search(r'RdWrB1 read garbage pointers\.', post_response))
        if (len(link_entries) == 1 and link_entries[0][1] == '601'
                and link601_io_error
                and link_entries[0].end() < link601_io_error.start()
                and re.search(r'Error termination', post_response[link601_io_error.start():])
                and not re.search(r'Error termination|Erroneous write\.',
                                  post_response[:link_entries[0].end()])
                and not re.search(r'Leave Link\s+601\b|Normal termination', post_response)):
            return dict(
                normal_termination=False,
                nmr_completion='complete_shielding_post_nmr_link601_io_failure')
    finished = re.search(r'Leave Link\s+601\b', tail)
    final_link = re.search(r'\(Enter [^\n]*[/\\]l9999\.exe\)', tail)
    write_error = tail.find('Erroneous write.')
    final_error = re.search(r'Error termination via Lnk1e in [^\n]*[/\\]l9999\.exe\b', tail)
    reported_link_error = re.search(
        r'Error termination via Lnk1e in [^\n]*[/\\]l(\d+)\.exe\b', tail)
    if (finished and final_link and final_error
            and finished.end() < final_link.start() < final_error.start()
            and 'Error termination' not in tail[:final_link.end()]
            and not re.search(r'\(Enter ', tail[final_link.end():])):
        return dict(normal_termination=False,
                    nmr_completion='complete_shielding_post_nmr_l9999_error')
    if (finished and final_link and finished.end() < final_link.start()
            and 'Error termination' not in tail[:final_link.end()]
            and 'Erroneous write.' not in tail[:final_link.end()]
            and (not reported_link_error or reported_link_error[1] == '9999')
            and not re.search(r'\(Enter ', tail[final_link.end():])):
        if write_error > final_link.end():
            completion = 'complete_shielding_post_nmr_l9999_write_failure'
        else:
            # Link 9999 only writes the final archive/termination record.  A
            # frozen file ending or failing here cannot invalidate shielding
            # already completed by Link 1002 and post-processed by Link 601.
            completion = 'complete_shielding_post_nmr_l9999_incomplete_finalization'
        return dict(normal_termination=False, nmr_completion=completion)
    raise ValueError(
        'NMR calculation did not terminate normally; not a verified post-NMR cleanup failure')


def archive_geometry(text, shielding):
    """Recover a damaged prefix using only its completed SP/NMR archive."""
    if not text.rstrip().splitlines()[-1].strip().startswith('Normal termination'):
        raise ValueError('Archive geometry recovery requires normal final termination')
    if 'Error termination' in text[shielding[0].start():]:
        raise ValueError('Archive geometry recovery has an error during/after NMR')
    archives = re.findall(r'(?m)^\s*1\\1\\.*?\\\\@', text[shielding[-1].end():], re.S)
    if len(archives) != 1:
        raise ValueError('Archive geometry recovery requires one terminal archive')
    fields = ''.join(line.strip() for line in archives[0].splitlines()).split('\\\\')
    if len(fields) < 5 or '\\SP\\' not in fields[0] or not re.search(r'\bNMR\b', fields[1], re.I):
        raise ValueError('Archive is not a completed single-point NMR calculation')
    props = dict(item.split('=', 1) for item in fields[4].split('\\') if '=' in item)
    try:
        energy, rmsd = float(props['HF']), float(props['RMSD'])
    except (KeyError, ValueError) as exc:
        raise ValueError('Missing archive SCF convergence evidence') from exc
    if not np.isfinite(energy) or not np.isfinite(rmsd) or not 0 <= rmsd <= 1e-7:
        raise ValueError('Unverified archive SCF convergence')
    coords = fields[3].split('\\')
    charge = tuple(map(int, coords[0].split(',')))
    atoms = [a.split(',') for a in coords[1:]]
    if len(charge) != 2 or charge[1] < 1 or any(len(a) not in (4, 5) for a in atoms):
        raise ValueError('Unsupported archive geometry')
    z = np.array([Chem.GetPeriodicTable().GetAtomicNumber(a[0]) for a in atoms])
    pos = np.array([[float(v) for v in a[-3:]] for a in atoms])
    elements = [Chem.GetPeriodicTable().GetAtomicNumber(m[2]) for m in shielding]
    if not np.array_equal(z, elements) or not np.isfinite(pos).all():
        raise ValueError('Archive/shielding atomic assignment mismatch')
    end = complete_tensor_end(text, shielding, require_scf=False)
    tail = text[end:]
    if not re.search(r'Leave Link\s+1002\b.*?Leave Link\s+601\b.*?\(Enter [^\n]*[/\\]l9999\.exe\)', tail, re.S):
        raise ValueError('Incomplete response/finalization sequence for archive geometry')
    sigma = np.array([float(m[3].replace('D', 'E').replace('d', 'e')) for m in shielding])
    metadata = dict(normal_termination=False,
                    nmr_completion='verified_terminal_archive_geometry_after_damaged_prefix',
                    nmr_geometry_source='NMR terminal SP archive')
    return z, pos, sigma, charge, metadata


def parse_assigned_geometry(text, *, with_metadata=False):
    """Return coordinates and shielding in Gaussian atom order; reject ambiguity."""
    shielding = list(SHIELDING.finditer(text))
    if not shielding:
        raise ValueError('No shielding block')
    ids = [int(m[1]) for m in shielding]
    if ids != list(range(1, len(ids) + 1)):
        raise ValueError('Multiple, incomplete, or out-of-order shielding blocks')
    geometry = list(ORIENTATION.finditer(text[:shielding[0].start()]))
    rows = [line.split() for line in geometry[-1][1].strip().splitlines()] if geometry else []
    if not geometry or any(len(row) != 6 for row in rows) or [int(row[0]) for row in rows] != ids:
        result = archive_geometry(text, shielding)
        return result if with_metadata else result[:4]
    if any(len(row) != 6 for row in rows) or [int(row[0]) for row in rows] != ids:
        raise ValueError('Geometry/shielding atom IDs disagree')
    z = np.array([int(row[1]) for row in rows], dtype=np.int64)
    elements = np.array([Chem.GetPeriodicTable().GetAtomicNumber(m[2]) for m in shielding])
    if not np.array_equal(z, elements):
        raise ValueError('Geometry/shielding elements disagree')
    number = lambda s: float(s.replace('D', 'E').replace('d', 'e'))
    pos = np.array([[number(x) for x in row[3:]] for row in rows])
    sigma = np.array([number(m[3]) for m in shielding])
    charges = re.findall(r'Charge\s*=\s*(-?\d+)\s+Multiplicity\s*=\s*(\d+)', text[:shielding[0].start()])
    if not charges:
        raise ValueError('Missing charge/multiplicity')
    charge = tuple(map(int, charges[-1]))
    # Concurrent jobs can overwrite the prefix of a successful log. Accept its
    # remaining successful suffix only with an independent terminal archive.
    errors = list(re.finditer(r'Error termination[^\n]*', text))
    if errors and errors[-1].end() < geometry[-1].start() and text.rstrip().splitlines()[-1].strip().startswith('Normal termination'):
        suffix = text[geometry[-1].start():]
        archives = re.findall(r'(?m)^\s*1\\1\\.*?\\\\@', suffix, re.S)
        if len(archives) != 1:
            raise ValueError('Mixed log lacks a unique successful terminal archive')
        fields = ''.join(line.strip() for line in archives[0].splitlines()).split('\\\\')
        if len(fields) < 5:
            raise ValueError('Incomplete terminal archive in mixed log')
        coords = fields[3].split('\\')
        archive_charge = tuple(map(int, coords[0].split(',')))
        atoms = [a.split(',') for a in coords[1:]]
        if any(len(a) not in (4, 5) for a in atoms):
            raise ValueError('Unsupported mixed-log archive coordinates')
        archive_z = [Chem.GetPeriodicTable().GetAtomicNumber(a[0]) for a in atoms]
        archive_pos = np.array([[number(v) for v in a[-3:]] for a in atoms])
        if not np.array_equal(z, archive_z) or archive_charge != charge:
            raise ValueError('Mixed-log archive atom order/charge mismatch')
        distances = lambda p: np.linalg.norm(p[:, None] - p[None, :], axis=-1)
        if not np.allclose(distances(pos), distances(archive_pos), atol=5e-5, rtol=0):
            raise ValueError('Mixed-log archive geometry mismatch')
        # Compare proper rotations too: distances alone would accept reflections.
        p, q = pos-pos.mean(0), archive_pos-archive_pos.mean(0)
        u, _, vt = np.linalg.svd(p.T @ q)
        rotation = u @ np.diag([1., 1., np.linalg.det(u @ vt)]) @ vt
        if not np.allclose(p @ rotation, q, atol=5e-5, rtol=0):
            raise ValueError('Mixed-log archive stereogeometry mismatch')
        end = complete_tensor_end(suffix, list(SHIELDING.finditer(suffix)))
        tail = suffix[end:]
        if not re.search(r'Leave Link\s+601\b.*?\(Enter [^\n]*[/\\]l9999\.exe\)', tail, re.S):
            raise ValueError('Mixed log lacks completed NMR finalization')
        metadata = dict(normal_termination=False,
                        nmr_completion='verified_normal_suffix_with_mixed_failed_prefix')
    else:
        metadata = termination_metadata(text, shielding)
    result = (z, pos, sigma, charge)
    return (*result, metadata) if with_metadata else result


def shift_graph(z, pos, sigma, reference, sample_id, cutoff):
    z, pos, sigma = np.asarray(z), np.asarray(pos), np.asarray(sigma)
    n = len(z)
    if z.shape != (n,) or pos.shape != (n, 3) or sigma.shape != (n,) or not n:
        raise ValueError('Invalid geometry/shielding shapes')
    if not all(np.isfinite(a).all() for a in (z, pos, sigma)):
        raise ValueError('Nonfinite geometry/shielding')
    if not np.equal(z, np.floor(z)).all() or np.any((z < 1) | (z > 118)):
        raise ValueError('Invalid atomic numbers')
    if not np.isfinite(cutoff) or cutoff <= 0:
        raise ValueError('Invalid cutoff')
    h, c = z == 1, z == 6
    target = np.zeros(n, dtype=np.float32)
    for mask, element in ((h, 'H'), (c, 'C')):
        target[mask] = reference['sigma_ref_ppm'][element] - sigma[mask]
    if not np.isfinite(target).all():
        raise ValueError('Nonfinite shifts')
    dist = np.linalg.norm(pos[:, None] - pos[None, :], axis=-1)
    offdiag = ~np.eye(n, dtype=bool)
    if np.any(dist[offdiag] < 1e-8):
        raise ValueError('Overlapping atoms')
    dst, src = np.where((dist < cutoff) & offdiag)
    return Data(
        pos=torch.tensor(pos, dtype=torch.float32),
        atomic_numbers=torch.tensor(z, dtype=torch.long), natoms=torch.tensor([n]),
        edge_index=torch.tensor(np.stack((src, dst)), dtype=torch.long),
        atom_id=torch.arange(n), nmr_shift=torch.tensor(target[:, None]),
        nmr_mask=torch.tensor(h | c), nmr_h_mask=torch.tensor(h), nmr_c_mask=torch.tensor(c),
        has_nmr_target=torch.tensor([bool((h | c).any())]),
        sample_id=str(sample_id), nmr_reference_id=reference['id'],
        nmr_shift_unit='ppm', coordinate_unit='Angstrom',
    )


def build_record(job, reference, cutoff):
    row, frozen_z, frozen_sigma = job
    sid = row.sample_id
    try:
        path = Path(row.nmr_log_path)
        raw = path.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        if sha != row.nmr_file_hash:
            raise ValueError('Source log hash differs from manifest')
        z, pos, sigma, (charge, multiplicity), metadata = parse_assigned_geometry(
            raw.decode('utf-8', errors='replace'), with_metadata=True)
        if not np.array_equal(z, frozen_z) or sigma.shape != frozen_sigma.shape or not np.allclose(
                sigma, frozen_sigma, rtol=0, atol=1e-6):
            raise ValueError('Raw atom order/shielding disagrees with frozen NMR payload')
        data = shift_graph(z, pos, sigma, reference, sid, cutoff)
        data.charge, data.multiplicity = torch.tensor([charge]), torch.tensor([multiplicity])
        data.source_dataset, data.inchikey = str(row.source_dataset), str(row.inchikey)
        data.nmr_log_path, data.nmr_file_hash = str(path), sha
        data.normal_termination = torch.tensor([metadata['normal_termination']])
        data.nmr_completion = metadata['nmr_completion']
        data.nmr_geometry_source = metadata.get('nmr_geometry_source', 'NMR orientation preceding shielding')
        return sid, data, None
    except (OSError, ValueError, RuntimeError, OverflowError) as exc:
        return sid, None, f'{type(exc).__name__}: {exc}'


def run(payload, manifest, split_file, output, reference_log, workers=32,
        cutoff=5.0, limit_per_split=None, skip_invalid=False, collect_errors=False):
    payload, output = Path(payload), Path(output)
    if output.exists():
        raise FileExistsError(f'Refusing to overwrite {output}')
    if workers < 1 or not np.isfinite(cutoff) or cutoff <= 0 or (limit_per_split is not None and limit_per_split < 1):
        raise ValueError('workers, cutoff, limit must be positive')
    reference = load_tms_reference(reference_log)
    split = load_official_split(str(split_file))
    split['split'] = split.split.replace({'validation': 'eval'})
    if set(split.split) != {'train', 'eval', 'test'} or split.inchikey.isna().any() or split.inchikey.duplicated().any():
        raise ValueError('Expected three molecule-unique splits')
    if 'split_scaffold' in split and split.groupby('split_scaffold').split.nunique().max() > 1:
        raise ValueError('Scaffold leakage across splits')
    if limit_per_split:
        split = split.groupby('split', sort=False).head(limit_per_split).copy()
    index = pd.read_parquet(payload / 'index.parquet', columns=['sample_id', 'shard', 'row_in_shard'])
    selected = split.merge(index, on='sample_id', how='left', validate='one_to_one')
    paths = pd.read_parquet(manifest, columns=['sample_id', 'nmr_log_path', 'nmr_file_hash'])
    selected = selected.merge(paths, on='sample_id', how='left', validate='one_to_one')
    if selected[['shard', 'nmr_log_path', 'nmr_file_hash']].isna().any().any():
        raise ValueError('Missing frozen NMR record or hashed source log')
    output.mkdir(parents=True)
    summary = dict(state='building', version='structure-hc-nmr-v6', counts={}, nuclei={},
                   recovered_abnormal_termination_counts={},
                   no_hc_target_counts={}, supervised_counts={},
                   no_hc_policy='retain original split; all masks false, exclude from loss and metrics',
                   requested_counts={k: int(v) for k, v in split.split.value_counts().items()},
                   cutoff_angstrom=cutoff, reference=reference, skip_invalid=skip_invalid,
                   collect_errors=collect_errors,
                   geometry_source='NMR orientation preceding shielding, or verified terminal SP archive; see per-record nmr_geometry_source',
                   atom_order='Gaussian order; atom_id is zero-based, local to each molecule',
                   target='nmr_shift [natoms,1], ppm; supervise only nmr_mask (H or C)',
                   non_target_fill='zero placeholder, never a supervised label',
                   method_verification='reference verified; source protocol not individually verified',
                   frequency_geometry_equivalence='not assumed or required; use actual NMR calculation geometry',
                   payload=str(payload.resolve()), manifest=str(Path(manifest).resolve()),
                   split_file=str(Path(split_file).resolve()),
                   split_sha256=hashlib.sha256(Path(split_file).read_bytes()).hexdigest(),
                   limit_per_split=limit_per_split)
    def save():
        (output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    save()
    (output/'nmr_reference.json').write_text(json.dumps(reference, indent=2)+'\n')
    accepted, rejected, recovered = [], [], []
    started = time.monotonic()
    try:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for mode in ('train', 'eval', 'test'):
                subset = selected[selected.split == mode]
                stats = {x: dict(count=0, sum=0., sum_sq=0., min=None, max=None) for x in ('h', 'c')}
                summary['no_hc_target_counts'][mode] = 0
                summary['recovered_abnormal_termination_counts'][mode] = 0
                def records():
                    for shard, rows in subset.groupby('shard', sort=True):
                        with h5py.File(payload/f'{shard}.h5', 'r') as handle:
                            arrays = {'arrays': {name: {key: handle['arrays'][name][key][:]
                                      for key in ('values', 'offsets', 'shapes', 'present')}
                                      for name in ('atomic_numbers', 'nmr_isotropic')}}
                        rows = list(rows.itertuples(index=False))
                        # Bounded prefetch: do not retain a whole shard of graph objects/futures.
                        for start in range(0, len(rows), workers * 4):
                            jobs = [(r, read_array(arrays, 'atomic_numbers', int(r.row_in_shard)),
                                     read_array(arrays, 'nmr_isotropic', int(r.row_in_shard)))
                                    for r in rows[start:start+workers*4]]
                            for sid, data, error in pool.map(lambda j: build_record(j, reference, cutoff), jobs):
                                if error:
                                    rejected.append(dict(sample_id=sid, split=mode, error=error))
                                    if not skip_invalid and not collect_errors:
                                        raise ValueError(f'{sid}: {error}; no silent split changes')
                                    continue
                                accepted.append(sid)
                                if not bool(data.normal_termination.item()):
                                    summary['recovered_abnormal_termination_counts'][mode] += 1
                                    recovered.append(dict(sample_id=sid, split=mode, reason=data.nmr_completion))
                                if not bool(data.has_nmr_target.item()):
                                    summary['no_hc_target_counts'][mode] += 1
                                for x in ('h', 'c'):
                                    values = data.nmr_shift[getattr(data, f'nmr_{x}_mask')].numpy().astype(np.float64)
                                    st = stats[x]
                                    st['count'] += values.size
                                    st['sum'] += float(values.sum())
                                    st['sum_sq'] += float((values**2).sum())
                                    if values.size:
                                        st['min'] = min(st['min'], float(values.min())) if st['min'] is not None else float(values.min())
                                        st['max'] = max(st['max'], float(values.max())) if st['max'] is not None else float(values.max())
                                yield sid, data
                summary['counts'][mode] = _write_lmdb(output/'equiformer_v3'/f'{mode}.lmdb',
                    tqdm(records(), total=len(subset), desc=f'Atom NMR {mode}', unit='molecule', mininterval=5),
                    map_size=200*1024**3, commit_interval=4096)
                summary['nuclei'][mode] = stats
                summary['supervised_counts'][mode] = summary['counts'][mode] - summary['no_hc_target_counts'][mode]
                if not skip_invalid and not collect_errors and summary['counts'][mode] != len(subset):
                    raise ValueError('Split count mismatch')
                if not summary['counts'][mode] and not collect_errors:
                    raise ValueError(f'No valid {mode} records')
                save()
        if rejected and not skip_invalid:
            raise ValueError(f'{len(rejected)} invalid records; see excluded_records.parquet; no silent split changes')
        summary['train_target_statistics'] = {}
        for x, st in summary['nuclei']['train'].items():
            n = st['count']
            mean = st['sum']/n if n else None
            std = float(np.sqrt(max(0., st['sum_sq']/n-mean**2))) if n else None
            summary['train_target_statistics'][x] = dict(count=n, mean_ppm=mean, std_ppm=std)
        split[split.sample_id.isin(accepted)].to_parquet(output/'benchmark_split.parquet', index=False)
        summary.update(state='completed', excluded=len(rejected), elapsed_seconds=time.monotonic()-started)
    except Exception as exc:
        summary.update(state='failed', error=str(exc), excluded=len(rejected))
        raise
    finally:
        pd.DataFrame(recovered, columns=['sample_id', 'split', 'reason']).to_parquet(output/'recovered_records.parquet', index=False)
        pd.DataFrame(rejected, columns=['sample_id', 'split', 'error']).to_parquet(output/'excluded_records.parquet', index=False)
        save()
    return summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--payload', default='builds/openmolspec-20260830/release-v1/payload/nmr')
    p.add_argument('--manifest', default='builds/openmolspec-20260830/datasets/openspec_manifest.parquet')
    p.add_argument('--reference-log', default='artifacts/calculations/tms_reference/tms_reference.log')
    p.add_argument('--split-file', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--workers', type=int, default=32)
    p.add_argument('--cutoff', type=float, default=5.)
    p.add_argument('--limit-per-split', type=int)
    p.add_argument('--skip-invalid', action='store_true', help='Explicitly allow audited exclusions; counts/heldouts may change')
    p.add_argument('--collect-errors', action='store_true', help='Report all invalid records, then fail the build; preserves strict split policy')
    print(json.dumps(run(**vars(p.parse_args())), indent=2))


if __name__ == '__main__':
    main()
