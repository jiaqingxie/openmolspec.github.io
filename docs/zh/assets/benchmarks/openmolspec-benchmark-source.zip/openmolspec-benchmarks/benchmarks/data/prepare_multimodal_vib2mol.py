"""Join validated H/C property exports to Vib2Mol by exact sample ID."""
import argparse
import json
import pickle
import shutil
from pathlib import Path

import lmdb
import numpy as np
import pandas as pd
from tqdm import tqdm
from benchmarks.engines.nmr_normalization import read_nmr_arrays


def run(source, properties, output, limit_per_split=None):
    source, properties, output = map(Path, (source, properties, output))
    if output.exists():
        raise FileExistsError(f'Refusing to overwrite {output}')
    if limit_per_split is not None and limit_per_split < 2:
        raise ValueError('At least two records per split are required')
    for root in (source, properties):
        if root.resolve() == output.resolve() or root.resolve() in output.resolve().parents:
            raise ValueError('Output must be separate from inputs')
    summary = json.loads((properties/'summary.json').read_text())
    if summary.get('state') != 'completed':
        raise ValueError('Property/NMR export is incomplete')
    reference = json.loads((properties/'nmr_reference.json').read_text())
    left = pd.read_parquet(properties/'benchmark_split.parquet')
    right = pd.read_parquet(source/'benchmark_split.parquet')
    for index in (left, right):
        index['split'] = index['split'].replace({'validation':'eval'})
        if index.sample_id.isna().any() or index.sample_id.duplicated().any():
            raise ValueError('Missing or duplicate sample IDs')
        if not set(index.split).issubset({'train','eval','test'}):
            raise ValueError('Invalid split labels')
    merged = left.merge(right[['sample_id','split','inchikey']], on='sample_id',
                        how='left', suffixes=('', '_source'), validate='one_to_one')
    if not (merged.split == merged.split_source).all() or not (merged.inchikey == merged.inchikey_source).all():
        raise ValueError('Vib2Mol/property identity or split mismatch')
    for mode in ('eval','test'):
        if set(left.loc[left.split==mode,'sample_id']) != set(right.loc[right.split==mode,'sample_id']):
            raise ValueError('Held-out sets must match exactly')
    destination = output/'vib2mol'
    destination.mkdir(parents=True)
    report = dict(state='building', version='vib2mol-hc-v1', source=str(source.resolve()),
                  properties=str(properties.resolve()), counts={}, limit_per_split=limit_per_split,
                  modalities=['ir','raman','1H-NMR','13C-NMR'], nmr_pairing='same sample_id',
                  normalization='IR/Raman minmax; H/C train median/IQR fitted at training')
    (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    shutil.copy2(properties/'nmr_reference.json', output/'nmr_reference.json')
    kept = []
    try:
        for mode in ('train','eval','test'):
            ids = sorted(left.loc[left.split==mode,'sample_id'])
            if limit_per_split:
                ids = ids[:limit_per_split]
            if len(ids) < 2:
                raise ValueError('Empty or singleton split')
            a = source/'vib2mol'/f'openspec_{mode}.lmdb'
            b = properties/'vib2conf'/f'{mode}.lmdb'
            with lmdb.open(str(a),subdir=False,readonly=True,lock=False,readahead=True) as vib, \
                 lmdb.open(str(b),subdir=False,readonly=True,lock=False,readahead=True) as props, \
                 lmdb.open(str(destination/f'openspec_{mode}.lmdb'),subdir=False,
                           map_size=max(1<<30,2*(a.stat().st_size+b.stat().st_size))) as writer:
                with vib.begin() as vt, props.begin() as pt:
                    for start in tqdm(range(0,len(ids),4096),desc=f'Vib2Mol H/C {mode}',unit='batch'):
                        with writer.begin(write=True) as tx:
                            for sid in ids[start:start+4096]:
                                key = sid.encode()
                                va, pb = vt.get(key), pt.get(key)
                                if va is None or pb is None:
                                    raise ValueError(f'Missing paired record: {sid}')
                                record, nmr = pickle.loads(va), pickle.loads(pb)
                                read_nmr_arrays(nmr)
                                if nmr['nmr_reference_id'] != reference['id']:
                                    raise ValueError(f'NMR reference mismatch: {sid}')
                                if nmr['sample_id'] != sid or nmr.get('nmr_sample_id') != sid:
                                    raise ValueError(f'NMR pairing mismatch: {sid}')
                                if not record.get('kekule_smiles'):
                                    raise ValueError(f'Missing SMILES: {sid}')
                                for field in ('ir','raman'):
                                    x = np.asarray(record[field])
                                    if x.dtype != np.float32 or x.shape != (1024,) or not np.isfinite(x).all() or x.min()<0 or x.max()>1:
                                        raise ValueError(f'Invalid normalized spectrum: {sid}')
                                    if not np.array_equal(x,nmr[field]):
                                        raise ValueError(f'Spectrum mismatch across exports: {sid}')
                                record.update({k:v for k,v in nmr.items() if k.startswith('nmr_')})
                                record.update(sample_id=sid,inchikey=nmr['inchikey'],source_dataset=nmr['source_dataset'],
                                              spectrum_normalization=nmr['spectrum_normalization'])
                                tx.put(key,pickle.dumps(record,protocol=pickle.HIGHEST_PROTOCOL))
                writer.sync()
            report['counts'][mode] = len(ids)
            kept.extend(ids)
        left[left.sample_id.isin(kept)].to_parquet(output/'benchmark_split.parquet',index=False)
        report['state'] = 'completed'
    except Exception as exc:
        report.update(state='failed',error=str(exc))
        raise
    finally:
        (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',default='benchmark_data/release_v1_minmax')
    p.add_argument('--properties',required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--limit-per-split',type=int)
    a=p.parse_args()
    print(json.dumps(run(a.source,a.properties,a.output,a.limit_per_split),indent=2))


if __name__ == '__main__':
    main()
