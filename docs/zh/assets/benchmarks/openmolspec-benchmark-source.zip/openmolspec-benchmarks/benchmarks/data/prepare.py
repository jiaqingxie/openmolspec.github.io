"""Prepare OpenMolSpec benchmark task datasets with a fixed leakage-free split.

Every formal task consumes the frozen scaffold-disjoint ``align_split.parquet``
so validation and test molecules are identical across models. Demo preparation
may generate a temporary InChIKey-grouped split for pipeline smoke tests.

Outputs under ``--output`` (default ``benchmark_data``)::

    benchmark_data/
        benchmark_split.parquet   # sample_id -> split, source, inchikey
        summary.json              # counts, leakage numbers, smoke-test flags
        vib2mol/{openspec_train,openspec_eval,openspec_test}.lmdb
        vib2conf/{train,eval,test}.lmdb
        equiformer_v3/{train,eval,test}.lmdb

Example:
    python -m benchmarks.data.prepare \\
        --split-file <release>/splits/align_split.parquet --workers 32
    python -m benchmarks prepare-demo --sample-size 5000
"""

import argparse
import json
import multiprocessing
import pickle
import shutil
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

import lmdb
import numpy as np
import pandas as pd
import torch
from benchmarks.data.scalar_properties import POLAR_TARGETS, polar_invariants, convert_benchmark_units
from tqdm import tqdm

from openmolspec.datasets.splits import _partition_groups, _stable_order

SPLIT_RATIOS = {"train": 0.8, "validation": 0.1, "test": 0.1}
PROPERTY_FIELDS = ("energy", "gap", "homo", "lumo", "dipole_total", "zpve")
EXPORT_FORMATS = ("vib2mol", "vib2conf", "equiformer_v3")
DEFAULT_LMDB_MAP_SIZE_GB = 40.0


# ---------------------------------------------------------------------------
# Split index
# ---------------------------------------------------------------------------


def build_split_index(identity: pd.DataFrame, seed: int = 2025) -> pd.DataFrame:
    """Assign a temporary train/validation/test split for demo runs."""

    groups: Dict[str, List[int]] = {}
    for row_index, inchikey in enumerate(identity["inchikey"]):
        key = str(inchikey) if pd.notna(inchikey) else f"__missing__:{row_index}"
        groups.setdefault(key, []).append(row_index)
    assignment = _partition_groups(groups, seed, dict(SPLIT_RATIOS))
    split_of_index: Dict[int, str] = {}
    for split_name, indices in assignment.items():
        for index in indices:
            split_of_index[index] = split_name
    identity = identity.copy()
    identity["split"] = [split_of_index[index] for index in range(len(identity))]
    return identity


def load_official_split(path: str) -> pd.DataFrame:
    """Load the frozen aligned scaffold split as a record-level index."""

    split = pd.read_parquet(path)
    required = {"align_sample_id", "split", "inchikey", "align_source"}
    missing = sorted(required - set(split.columns))
    if missing:
        raise ValueError(f"Official split is missing columns: {', '.join(missing)}")
    split = split.loc[split["align_sample_id"].notna()].copy()
    split["sample_id"] = split["align_sample_id"].astype(str)
    if split["sample_id"].duplicated().any():
        raise ValueError("Official split contains duplicate align_sample_id values")
    split["source_dataset"] = split["align_source"].astype(str)
    columns = ["sample_id", "split", "source_dataset", "inchikey"]
    if "split_scaffold" in split.columns:
        columns.append("split_scaffold")
    return split[columns].reset_index(drop=True)


def stable_molecule_sample(
    identity: pd.DataFrame,
    sample_size: Optional[int],
    seed: int = 2025,
) -> pd.DataFrame:
    """Select approximately ``sample_size`` records without splitting molecules.

    Molecule groups are ordered by the same stable SHA-256 rule used for the
    benchmark split.  Consequently a demo subset is reproducible and does not
    depend on the row order in the input pickle.  The returned size may exceed
    the requested size by the records belonging to the final molecule group.
    """

    if not sample_size or sample_size >= len(identity):
        return identity.copy()
    if sample_size < 1:
        raise ValueError("sample_size must be a positive integer")

    groups: Dict[str, List[int]] = {}
    for row_index, inchikey in enumerate(identity["inchikey"]):
        key = str(inchikey) if pd.notna(inchikey) else f"__missing__:{row_index}"
        groups.setdefault(key, []).append(row_index)

    selected: List[int] = []
    for key in _stable_order(groups, seed):
        selected.extend(groups[key])
        if len(selected) >= sample_size:
            break
    return identity.iloc[sorted(selected)].copy()


# ---------------------------------------------------------------------------
# SMILES -> Vib2Mol molecular identity
# ---------------------------------------------------------------------------


def _kekule_one(smiles: str) -> str:
    from rdkit import Chem

    try:
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            return None
        return Chem.MolToSmiles(molecule, isomericSmiles=False, canonical=True, kekuleSmiles=True)
    except Exception:
        return None


def _vib2mol_identity_one(smiles: str) -> Tuple[Optional[str], Optional[str]]:
    """Return canonical Kekule SMILES and molecular formula in one RDKit pass."""

    from rdkit import Chem
    from rdkit.Chem import rdMolDescriptors

    try:
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            return None, None
        kekule = Chem.MolToSmiles(
            molecule, isomericSmiles=False, canonical=True, kekuleSmiles=True
        )
        return kekule, rdMolDescriptors.CalcMolFormula(molecule)
    except Exception:
        return None, None


def kekule_smiles_parallel(smiles_values: List[str], workers: int) -> List[Optional[str]]:
    """Canonicalize a list of SMILES to kekule form using a process pool."""

    if workers <= 1:
        return [_kekule_one(value) for value in tqdm(smiles_values, desc="kekule SMILES")]
    with multiprocessing.Pool(workers) as pool:
        results = list(tqdm(pool.imap(_kekule_one, smiles_values, chunksize=512), total=len(smiles_values), desc="kekule SMILES"))
    return results


def vib2mol_identities_parallel(
    smiles_values: List[str], workers: int
) -> List[Tuple[Optional[str], Optional[str]]]:
    """Compute Vib2Mol SMILES/formula targets with an optional process pool."""

    if workers <= 1:
        return [
            _vib2mol_identity_one(value)
            for value in tqdm(smiles_values, desc="Vib2Mol identities")
        ]
    with multiprocessing.Pool(workers) as pool:
        return list(
            tqdm(
                pool.imap(_vib2mol_identity_one, smiles_values, chunksize=512),
                total=len(smiles_values),
                desc="Vib2Mol identities",
            )
        )


# ---------------------------------------------------------------------------
# LMDB writers
# ---------------------------------------------------------------------------


def _write_lmdb(
    path: Path,
    records: Iterable[Tuple[str, Any]],
    map_size: int = int(40e9),
    *,
    overwrite: bool = False,
    commit_interval: int = 10_000,
) -> int:
    """Stream records to LMDB and return the number written.

    Refusing to reuse an existing LMDB prevents stale keys from a previous,
    larger demo run.  ``overwrite`` only removes the exact requested LMDB file
    and its lock file.
    """

    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = Path(f"{path}-lock")
    existing = [candidate for candidate in (path, lock_path) if candidate.exists()]
    if existing and not overwrite:
        raise FileExistsError(
            f"LMDB already exists: {path}. Choose a new --output or pass --overwrite."
        )
    if overwrite:
        for candidate in existing:
            if candidate.is_dir():
                shutil.rmtree(candidate)
            else:
                candidate.unlink()

    environment = lmdb.open(str(path), map_size=map_size, subdir=False, meminit=False, lock=False)
    count = 0
    try:
        transaction = environment.begin(write=True)
        try:
            for count, (key, value) in enumerate(records, start=1):
                transaction.put(key.encode(), pickle.dumps(value))
                if count % commit_interval == 0:
                    transaction.commit()
                    transaction = environment.begin(write=True)
            transaction.commit()
        except Exception:
            transaction.abort()
            raise
    finally:
        environment.close()
    return count


def _coords(record: pd.Series) -> np.ndarray:
    coordinates = np.asarray(record["coordinate"], dtype=np.float32)
    n_atoms = len(record["atom"])
    return coordinates.reshape(n_atoms, 3)


def _property_value(record: pd.Series, field: str) -> float:
    value = record.get(field)
    if value is None:
        return float("nan")
    try:
        return float(np.asarray(value).reshape(-1)[0])
    except (TypeError, ValueError, IndexError):
        return float("nan")


def _spectrum(record: pd.Series, field: str) -> np.ndarray:
    value = record.get(field)
    if value is None:
        return np.zeros(1024, dtype=np.float32)
    return np.asarray(value, dtype=np.float32).reshape(-1)


# ---------------------------------------------------------------------------
# Exporters
# ---------------------------------------------------------------------------


def export_vib2mol(
    frame: pd.DataFrame,
    output_dir: Path,
    split_map: pd.DataFrame,
    workers: int,
    *,
    map_size: int = int(40e9),
    overwrite: bool = False,
) -> Dict[str, int]:
    """Export LMDBs in the Vib2Mol format (``{ds}_{mode}.lmdb``)."""

    records = split_map.merge(
        frame[["sample_id", "smiles", "ir", "raman"] + list(PROPERTY_FIELDS)],
        on="sample_id", how="left",
    )
    identities = vib2mol_identities_parallel(records["smiles"].tolist(), workers)
    records["kekule_smiles"] = [item[0] for item in identities]
    records["formula"] = [item[1] for item in identities]
    kekule_failures = int(records["kekule_smiles"].isna().sum())
    formula_failures = int(records["formula"].isna().sum())
    counts: Dict[str, int] = {}
    for mode in ("train", "eval", "test"):
        subset = records[records["split"] == mode]

        def rows() -> Iterator[Tuple[str, Dict[str, Any]]]:
            for _, row in tqdm(subset.iterrows(), total=len(subset), desc=f"vib2mol {mode}"):
                values: Dict[str, Any] = {
                    "ir": _spectrum(row, "ir"),
                    "raman": _spectrum(row, "raman"),
                    "kekule_smiles": row["kekule_smiles"] or "",
                    "formula": row["formula"] or "",
                }
                for field in PROPERTY_FIELDS:
                    values[field] = _property_value(row, field)
                yield str(row["sample_id"]), values

        counts[mode] = _write_lmdb(
            output_dir / "vib2mol" / f"openspec_{mode}.lmdb",
            rows(), map_size, overwrite=overwrite,
        )
    counts["kekule_failures"] = kekule_failures
    counts["formula_failures"] = formula_failures
    return counts


def export_vib2conf(
    frame: pd.DataFrame,
    output_dir: Path,
    split_map: pd.DataFrame,
    *,
    map_size: int = int(40e9),
    overwrite: bool = False,
) -> Dict[str, int]:
    """Export LMDBs in the Vib2Conf format (``{mode}.lmdb``)."""

    frame = frame.copy()
    polar = [polar_invariants(value) for value in frame.get("polar", [None] * len(frame))]
    for index, name in enumerate(POLAR_TARGETS):
        frame[name] = [values[index] for values in polar]
    fields = PROPERTY_FIELDS + POLAR_TARGETS
    records = split_map.merge(
        frame[["sample_id", "atom", "coordinate", "ir", "raman"] + list(fields)],
        on="sample_id", how="left",
    )
    counts: Dict[str, int] = {}
    for mode in ("train", "eval", "test"):
        subset = records[records["split"] == mode]
        def rows() -> Iterator[Tuple[str, Dict[str, Any]]]:
            for _, row in tqdm(subset.iterrows(), total=len(subset), desc=f"vib2conf {mode}"):
                values: Dict[str, Any] = {
                    "pos": _coords(row),
                    "z": np.asarray(row["atom"], dtype=np.int64),
                    "ir": _spectrum(row, "ir"),
                    "raman": _spectrum(row, "raman"),
                }
                for field in fields:
                    values[field] = _property_value(row, field)
                convert_benchmark_units(values)
                yield str(row["sample_id"]), values

        counts[mode] = _write_lmdb(
            output_dir / "vib2conf" / f"{mode}.lmdb",
            rows(), map_size, overwrite=overwrite,
        )
    return counts


def export_equiformer_v3(
    frame: pd.DataFrame,
    output_dir: Path,
    split_map: pd.DataFrame,
    *,
    map_size: int = int(40e9),
    overwrite: bool = False,
) -> Dict[str, int]:
    """Export LMDBs of PyG ``Data`` objects for the EquiformerV3 wrapper."""

    try:
        from torch_geometric.data import Data
    except ImportError as error:  # pragma: no cover
        raise RuntimeError("torch_geometric is required for the EquiformerV3 export") from error

    records = split_map.merge(
        frame[["sample_id", "atom", "coordinate", "ir", "raman"] + list(PROPERTY_FIELDS)],
        on="sample_id", how="left",
    )
    counts: Dict[str, int] = {}
    for mode in ("train", "eval", "test"):
        subset = records[records["split"] == mode]
        def rows() -> Iterator[Tuple[str, Any]]:
            for _, row in tqdm(subset.iterrows(), total=len(subset), desc=f"equiformer {mode}"):
                data = Data(
                    pos=torch.as_tensor(_coords(row)),
                    atomic_numbers=torch.as_tensor(np.asarray(row["atom"], dtype=np.int64)),
                    natoms=torch.tensor([int(len(row["atom"]))]),
                    # (1, 1024) so PyG batches spectra by stacking along dim 0.
                    ir_spectrum=torch.as_tensor(_spectrum(row, "ir")).unsqueeze(0),
                    raman_spectrum=torch.as_tensor(_spectrum(row, "raman")).unsqueeze(0),
                )
                for field in PROPERTY_FIELDS:
                    data[field] = torch.tensor(_property_value(row, field), dtype=torch.float32)
                data.sample_id = str(row["sample_id"])
                yield str(row["sample_id"]), data

        counts[mode] = _write_lmdb(
            output_dir / "equiformer_v3" / f"{mode}.lmdb",
            rows(), map_size, overwrite=overwrite,
        )
    return counts


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


def run(
    *,
    pickle_path: str,
    manifest_path: str,
    record_qc_path: Optional[str],
    split_path: Optional[str],
    output: str,
    seed: int,
    workers: int,
    limit: Optional[int] = None,
    sample_size: Optional[int] = None,
    formats: Sequence[str] = EXPORT_FORMATS,
    demo_mode: bool = False,
    map_size_gb: float = DEFAULT_LMDB_MAP_SIZE_GB,
    overwrite: bool = False,
) -> Dict[str, Any]:
    if not split_path and not demo_mode:
        raise ValueError(
            "Formal preparation requires --split-file; generated splits are demo-only"
        )
    if split_path and not Path(split_path).is_file():
        raise FileNotFoundError(f"Official split does not exist: {split_path}")

    frame = pd.read_pickle(pickle_path)
    frame["sample_id"] = frame["sample_id"].astype(str)

    manifest = pd.read_parquet(manifest_path)
    manifest["sample_id"] = manifest["sample_id"].astype(str)
    identity = frame[["sample_id"]].merge(
        manifest[["sample_id", "source_dataset", "inchikey", "canonical_smiles"]],
        on="sample_id", how="left",
    )

    requested_sample_size = sample_size if sample_size is not None else limit
    identity = stable_molecule_sample(identity, requested_sample_size, seed)
    frame = frame[frame["sample_id"].isin(set(identity["sample_id"]))].copy()

    if demo_mode or not record_qc_path:
        identity["qc_pass"] = True
    else:
        if not Path(record_qc_path).exists():
            raise FileNotFoundError(
                f"QC report does not exist: {record_qc_path}"
            )
        record_qc = pd.read_parquet(record_qc_path)
        record_qc["sample_id"] = record_qc["sample_id"].astype(str)
        qc_pass_ids = set(record_qc.loc[record_qc["qc_pass"], "sample_id"])
        identity["qc_pass"] = identity["sample_id"].isin(qc_pass_ids)

    if split_path:
        split_frame = load_official_split(split_path)
        qc_pass_ids = set(identity.loc[identity["qc_pass"], "sample_id"])
        split_frame = split_frame[split_frame["sample_id"].isin(qc_pass_ids)].copy()
        split_kind = "official_scaffold"
    else:
        split_frame = build_split_index(identity, seed=seed)
        split_frame = split_frame[split_frame["qc_pass"]].drop(columns=["qc_pass"])
        split_kind = "demo_inchikey"
    split_frame["split"] = split_frame["split"].replace({"validation": "eval"})
    frame = frame[frame["sample_id"].isin(set(split_frame["sample_id"]))].copy()

    output_dir = Path(output)
    output_dir.mkdir(parents=True, exist_ok=True)
    split_frame[["sample_id", "split", "source_dataset", "inchikey"]].to_parquet(
        output_dir / "benchmark_split.parquet", index=False
    )

    unknown_formats = sorted(set(formats) - set(EXPORT_FORMATS))
    if unknown_formats:
        raise ValueError(f"Unknown export formats: {', '.join(unknown_formats)}")
    map_size = int(map_size_gb * 1024 ** 3)
    export_counts: Dict[str, Dict[str, int]] = {}
    if "vib2mol" in formats:
        export_counts["vib2mol"] = export_vib2mol(
            frame, output_dir, split_frame, workers,
            map_size=map_size, overwrite=overwrite,
        )
    if "vib2conf" in formats:
        export_counts["vib2conf"] = export_vib2conf(
            frame, output_dir, split_frame,
            map_size=map_size, overwrite=overwrite,
        )
    if "equiformer_v3" in formats:
        export_counts["equiformer_v3"] = export_equiformer_v3(
            frame, output_dir, split_frame,
            map_size=map_size, overwrite=overwrite,
        )

    summary = {
        "seed": seed,
        "split_kind": split_kind,
        "split_file": str(split_path) if split_path else None,
        "ratios": dict(SPLIT_RATIOS) if split_kind == "demo_inchikey" else None,
        "split_counts": split_frame["split"].value_counts().to_dict(),
        "unique_inchikey_total": int(split_frame["inchikey"].nunique()),
        "unique_inchikey_train": int(split_frame[split_frame["split"] == "train"]["inchikey"].nunique()),
        "unique_inchikey_val": int(split_frame[split_frame["split"] == "eval"]["inchikey"].nunique()),
        "unique_inchikey_test": int(split_frame[split_frame["split"] == "test"]["inchikey"].nunique()),
        "leakage": {
            "train_test_molecule_overlap": int(
                len(set(split_frame[split_frame["split"] == "train"]["inchikey"])
                    & set(split_frame[split_frame["split"] == "test"]["inchikey"]))
            ),
            "train_test_scaffold_overlap": (
                int(
                    len(
                        set(split_frame.loc[split_frame["split"] == "train", "split_scaffold"])
                        & set(split_frame.loc[split_frame["split"] == "test", "split_scaffold"])
                    )
                )
                if "split_scaffold" in split_frame.columns
                else None
            ),
        },
        "input_records": int(len(frame)),
        "exported_records": int(len(split_frame)),
        "qc_applied": bool(record_qc_path and not demo_mode),
        "demo_mode": demo_mode,
        "sample_size_requested": requested_sample_size,
        "formats": list(formats),
        "exports": export_counts,
    }
    with open(output_dir / "summary.json", "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, default=str)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare OpenMolSpec benchmark datasets")
    parser.add_argument("--pickle", default="artifacts/processed/openspec.pickle")
    parser.add_argument("--manifest", default="datasets/openspec_manifest.parquet")
    parser.add_argument(
        "--record-qc",
        default=None,
        help="Optional record_qc.parquet applied in addition to the frozen split",
    )
    parser.add_argument(
        "--split-file",
        default=None,
        help="Frozen release align_split.parquet (required for formal preparation)",
    )
    parser.add_argument("--output", default="benchmark_data")
    parser.add_argument("--seed", type=int, default=2025)
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--sample-size", type=int, default=None, help="Stable molecule-level demo sample")
    parser.add_argument("--limit", type=int, default=None, help=argparse.SUPPRESS)
    parser.add_argument("--formats", nargs="+", choices=EXPORT_FORMATS, default=list(EXPORT_FORMATS))
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Allow a temporary InChIKey split when no frozen split is supplied",
    )
    parser.add_argument("--overwrite", action="store_true", help="Replace exact LMDB outputs if present")
    args = parser.parse_args()
    summary = run(
        pickle_path=args.pickle,
        manifest_path=args.manifest,
        record_qc_path=args.record_qc,
        split_path=args.split_file,
        output=args.output,
        seed=args.seed,
        workers=args.workers,
        limit=args.limit,
        sample_size=args.sample_size,
        formats=args.formats,
        demo_mode=args.demo,
        overwrite=args.overwrite,
    )
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
