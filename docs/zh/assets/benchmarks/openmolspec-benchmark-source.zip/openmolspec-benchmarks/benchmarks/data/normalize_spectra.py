"""Export separate per-spectrum min-max training LMDBs without changing raw inputs."""
import argparse
import hashlib
import json
import pickle
import shutil
import time
from itertools import islice
from pathlib import Path

import lmdb
import numpy as np
from tqdm import tqdm

POLICY = {
    'method': 'minmax', 'version': 1, 'bounds': 'minimum_and_maximum',
    'scope': 'per_record_per_modality', 'clip': [0.0, 1.0],
    'constant_policy': 'zeros', 'invalid_policy': 'fail_without_dropping_records',
    'dtype': 'float32', 'compute_dtype': 'float32', 'points': 1024,
    'absolute_intensity_preserved': False,
}


def minmax(values):
    values = np.asarray(values, dtype=np.float32)
    if values.shape != (1024,) or not np.isfinite(values).all():
        raise ValueError('Expected a finite 1024-point spectrum')
    lo, hi = values.min(), values.max()
    span = hi - lo
    if not np.isfinite(span):
        raise ValueError('Nonfinite min-max span')
    constant = bool(span <= 0)
    output = np.zeros_like(values) if constant else np.clip((values - lo) / span, 0, 1)
    return output, {'low': float(lo), 'high': float(hi), 'degenerate': constant,
                    'below_low': int((values < lo).sum()),
                    'above_high': int((values > hi).sum())}


def normalize_record(record):
    if not isinstance(record, dict):
        raise ValueError('Expected dictionary record')
    if 'spectrum_normalization' in record:
        raise ValueError('Record already normalized; use raw source LMDB')
    output = dict(record)
    bounds = {}
    for name in ('ir', 'raman'):
        output[name], bounds[name] = minmax(record[name])
    output['spectrum_normalization'] = {
        'method': POLICY['method'], 'version': 1, 'bounds': bounds}
    return output


def normalize_batch(items):
    """Vectorize numeric work while keeping record keys and fields unchanged."""
    records = []
    for key, value in items:
        record = pickle.loads(value)
        if not isinstance(record, dict) or 'spectrum_normalization' in record:
            raise ValueError(f'key={key!r}: expected raw dictionary record')
        record = dict(record)
        record['spectrum_normalization'] = {'method': POLICY['method'], 'version': 1, 'bounds': {}}
        records.append(record)
    degenerate = {'ir': 0, 'raman': 0}
    for name in degenerate:
        arrays = []
        for (key, _), record in zip(items, records):
            array = np.asarray(record[name], dtype=np.float32)
            if array.shape != (1024,) or not np.isfinite(array).all():
                raise ValueError(f'key={key!r}: invalid {name} spectrum')
            arrays.append(array)
        values = np.stack(arrays)
        low, high = values.min(axis=1), values.max(axis=1)
        span = high - low
        if not np.isfinite(span).all():
            raise ValueError('Nonfinite min-max span')
        constant = span <= 0
        scaled = np.clip((values - low[:, None]) / np.where(constant, 1, span)[:, None], 0, 1)
        scaled[constant] = 0
        degenerate[name] = int(constant.sum())
        for i, record in enumerate(records):
            record[name] = scaled[i]
            record['spectrum_normalization']['bounds'][name] = {
                'low': float(low[i]), 'high': float(high[i]), 'degenerate': bool(constant[i]),
                'below_low': 0, 'above_high': 0}
    return [(key, pickle.dumps(record, protocol=pickle.HIGHEST_PROTOCOL))
            for (key, _), record in zip(items, records)], degenerate


def export_split(source, target, batch_size=256, commit_interval=8192, readahead=True):
    if batch_size < 1 or commit_interval < 1:
        raise ValueError('Batch size and commit interval must be positive')
    source = Path(source)
    reader = lmdb.open(str(source), subdir=False, readonly=True, lock=False,
                       readahead=readahead, max_readers=256)
    # Conservative virtual map capacity for metadata and LMDB pages, not RAM.
    map_size = max(1 << 30, source.stat().st_size * 4)
    writer = lmdb.open(str(target), subdir=False, map_size=map_size)
    digest = hashlib.sha256()
    count = 0
    pending = 0
    timings = dict(read=0.0, transform=0.0, hash=0.0, write_commit=0.0)
    started = time.perf_counter()
    degenerate = {'ir': 0, 'raman': 0}
    transaction = writer.begin(write=True)
    try:
        with reader.begin() as read_txn:
            expected = read_txn.stat()['entries']
            if expected == 0:
                raise ValueError(f'Empty source split: {source}')
            cursor = iter(read_txn.cursor())
            with tqdm(total=expected, desc=f'Normalize {source.stem}', unit='record') as progress:
                while True:
                    tick = time.perf_counter()
                    items = list(islice(cursor, min(batch_size, commit_interval - pending)))
                    timings['read'] += time.perf_counter() - tick
                    if not items:
                        break
                    tick = time.perf_counter()
                    try:
                        output, constants = normalize_batch(items)
                    except Exception as exc:
                        raise ValueError(f'{source.name}: {exc}') from exc
                    timings['transform'] += time.perf_counter() - tick
                    tick = time.perf_counter()
                    for key, value in items:
                        digest.update(len(key).to_bytes(8, 'big'))
                        digest.update(key)
                        digest.update(len(value).to_bytes(8, 'big'))
                        digest.update(value)
                    timings['hash'] += time.perf_counter() - tick
                    tick = time.perf_counter()
                    with transaction.cursor() as write_cursor:
                        consumed, added = write_cursor.putmulti(output, append=True, overwrite=False)
                    if consumed != len(items) or added != len(items):
                        raise RuntimeError('LMDB bulk insert did not preserve all keys')
                    count += len(items)
                    pending += len(items)
                    for name in degenerate:
                        degenerate[name] += constants[name]
                    if pending == commit_interval:
                        transaction.commit()
                        transaction = writer.begin(write=True)
                        pending = 0
                    timings['write_commit'] += time.perf_counter() - tick
                    progress.update(len(items))
        tick = time.perf_counter()
        transaction.commit()
        transaction = None
        writer.sync()
        timings['write_commit'] += time.perf_counter() - tick
        with writer.begin() as txn:
            if txn.stat()['entries'] != expected:
                raise RuntimeError('Output count differs from source')
        return {'records': count, 'source': str(source.resolve()),
                'source_records_sha256': digest.hexdigest(), 'degenerate_spectra': degenerate,
                'timing_seconds': timings, 'elapsed_seconds': time.perf_counter() - started}
    finally:
        if transaction is not None:
            transaction.abort()
        writer.close()
        reader.close()


def run(data_dir, output, format, batch_size=256, commit_interval=8192, readahead=True):
    if batch_size < 1 or commit_interval < 1:
        raise ValueError('Batch size and commit interval must be positive')
    source, destination = Path(data_dir).resolve(), Path(output).resolve()
    if destination == source or source in destination.parents or destination in source.parents:
        raise ValueError('Source and output must be separate, non-nested directories')
    if destination.exists():
        raise FileExistsError(f'Output exists; choose a new directory: {destination}')
    files = {split: (f'openspec_{split}.lmdb' if format == 'vib2mol' else f'{split}.lmdb')
             for split in ('train', 'eval', 'test')}
    for filename in files.values():
        if not (source / format / filename).is_file():
            raise FileNotFoundError(source / format / filename)
    (destination / format).mkdir(parents=True)
    manifest = {'state': 'building', 'source_root': str(source), 'format': format,
                'normalization': POLICY, 'splits': {},
                'export_settings': dict(batch_size=batch_size, commit_interval=commit_interval,
                                        readahead=readahead)}
    report = destination / 'normalization.json'

    def save():
        report.write_text(json.dumps(manifest, indent=2, allow_nan=False) + '\n')

    save()
    try:
        for split, filename in files.items():
            manifest['splits'][split] = export_split(source / format / filename,
                                                     destination / format / filename,
                                                     batch_size, commit_interval, readahead)
            save()
        for filename in ('benchmark_split.parquet', 'excluded.parquet'):
            if (source / filename).is_file():
                shutil.copy2(source / filename, destination / filename)
        # Preserve source provenance explicitly rather than copying a stale summary.
        if (source / 'summary.json').is_file():
            shutil.copy2(source / 'summary.json', destination / 'source_summary.json')
        manifest['state'] = 'completed'
        save()
        return manifest
    except Exception as exc:
        manifest.update(state='failed', error=f'{type(exc).__name__}: {exc}')
        save()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', required=True, help='Root containing vib2mol/ or vib2conf/')
    parser.add_argument('--output', required=True, help='New benchmark root; never overwritten')
    parser.add_argument('--format', required=True, choices=['vib2mol', 'vib2conf'])
    parser.add_argument('--batch-size', type=int, default=256, help='Records per vectorized export batch')
    parser.add_argument('--commit-interval', type=int, default=8192, help='Records per durable transaction')
    parser.add_argument('--readahead', action=argparse.BooleanOptionalAction, default=True)
    print(json.dumps(run(**vars(parser.parse_args())), indent=2))


if __name__ == '__main__':
    main()
