"""Prepare a common four-property spectral benchmark from the frozen payload."""
import argparse
import json
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
from tqdm import tqdm

from benchmarks.data.prepare import _write_lmdb, load_official_split
from benchmarks.data.prepare_hessian import read_array
from benchmarks.data.scalar_properties import polar_invariants, convert_benchmark_units, PROPERTY_UNITS

UNITS = PROPERTY_UNITS
FIELDS = ("ir_spectrum", "raman_spectrum", "dipole_total", "gap", "polar")


def make_record(arrays):
    result = {}
    for name, field in (("ir", "ir_spectrum"), ("raman", "raman_spectrum")):
        value = np.asarray(arrays[field], dtype=np.float64).reshape(-1)
        if value.shape != (1024,) or not np.isfinite(value).all():
            raise ValueError(f"invalid {field}")
        result[name] = value  # Keep released intensities, including Raman float64.
    for name in ("dipole_total", "gap"):
        value = np.asarray(arrays[name], dtype=np.float64).reshape(-1)
        if value.size != 1 or not np.isfinite(value).all():
            raise ValueError(f"invalid {name}")
        result[name] = float(value[0])
    result["polar_iso"], result["polar_anisotropy"] = polar_invariants(arrays["polar"])
    if not all(np.isfinite(result[name]) for name in UNITS):
        raise ValueError("invalid polar")
    return convert_benchmark_units(result)


def run(payload, split_file, output, limit_per_split=None):
    payload, output = Path(payload), Path(output)
    if limit_per_split is not None and limit_per_split < 1:
        raise ValueError("limit-per-split must be positive")
    if any((output / "vib2conf" / f"{mode}.lmdb").exists()
           for mode in ("train", "eval", "test")):
        raise FileExistsError("Choose a new output directory; prepared LMDB exists")
    split = load_official_split(str(split_file))
    split["split"] = split["split"].replace({"validation": "eval"})
    if limit_per_split:
        split = split.groupby("split", sort=False).head(limit_per_split).copy()
    index = pd.read_parquet(payload / "index.parquet")
    selected = split.merge(index[["sample_id", "shard", "row_in_shard"]],
                           on="sample_id", how="left", validate="one_to_one")
    if selected["shard"].isna().any():
        raise ValueError("Split records missing from frozen frequency payload")
    audit, accepted, counts = [], [], {}
    for mode in ("train", "eval", "test"):
        subset = selected[selected["split"] == mode]
        def records():
            with tqdm(total=len(subset), desc=f"Spectrum properties {mode}") as progress:
                for shard, rows in subset.groupby("shard", sort=True):
                    with h5py.File(payload / f"{shard}.h5", "r") as handle:
                        source = {"arrays": {
                            field: {key: handle["arrays"][field][key][:]
                                    for key in ("values", "offsets", "shapes", "present")}
                            for field in FIELDS}}
                        for row in rows.itertuples():
                            try:
                                record = make_record({field: read_array(source, field, int(row.row_in_shard))
                                                      for field in FIELDS})
                            except (ValueError, TypeError) as exc:
                                audit.append({"sample_id": row.sample_id, "split": mode, "reason": str(exc)})
                            else:
                                record.update(sample_id=row.sample_id, source_dataset=row.source_dataset,
                                              inchikey=row.inchikey)
                                accepted.append(row.sample_id)
                                yield row.sample_id, record
                            progress.update()
        counts[mode] = _write_lmdb(output / "vib2conf" / f"{mode}.lmdb", records())
    selected[selected.sample_id.isin(accepted)].to_parquet(output / "benchmark_split.parquet", index=False)
    pd.DataFrame(audit, columns=["sample_id", "split", "reason"]).to_parquet(output / "excluded.parquet", index=False)
    summary = {"counts": counts, "excluded": len(audit), "units": UNITS,
               "payload": str(payload.resolve()), "split_file": str(Path(split_file).resolve()),
               "limit_per_split": limit_per_split,
               "spectrum_grid": {"min_cm-1": 400, "max_cm-1": 4000, "points": 1024},
               "selection": "finite paired spectra and all four targets; original split assignments retained"}
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    if not all(counts.values()):
        raise ValueError(f"Empty split after filtering: {counts}; see excluded.parquet")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", default="builds/openmolspec-20260830/release-v1/payload/frequency")
    parser.add_argument("--split-file", default="builds/openmolspec-20260830/release-v1/splits/scaling/align_ks_200k.parquet")
    parser.add_argument("--output", default="benchmark_data/spectrum_properties_ks200k")
    parser.add_argument("--limit-per-split", type=int)
    args = parser.parse_args()
    print(json.dumps(run(**vars(args)), indent=2))


if __name__ == "__main__":
    main()
