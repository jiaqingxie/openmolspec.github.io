"""Persist nested Kennard--Stone scaling splits for OpenMolSpec benchmarks."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd

from benchmarks.data.plot_kennard_stone import (
    DEFAULT_SIZES,
    featurize_smiles,
    nested_kennard_stone_rank,
)


SPLIT_COLUMNS = (
    "align_sample_id",
    "inchikey",
    "canonical_smiles",
    "align_source",
    "split_scaffold",
    "split",
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_scaling_split(
    original: pd.DataFrame,
    train_rank: pd.DataFrame,
    size: int,
) -> pd.DataFrame:
    """Return one exact-size train split with the original held-out rows."""

    selected_ids = train_rank.loc[
        train_rank["ks_rank"].le(size), "align_sample_id"
    ]
    selected = original.loc[original["align_sample_id"].isin(selected_ids)].copy()
    selected = selected.loc[selected["split"].eq("train")]
    selected = selected.merge(
        train_rank[["align_sample_id", "ks_rank"]],
        on="align_sample_id",
        how="left",
        validate="one_to_one",
    ).sort_values("ks_rank")
    heldout = original.loc[original["split"].ne("train")].copy()
    heldout["ks_rank"] = pd.NA
    heldout = heldout.sort_values(["split", "inchikey"], kind="stable")
    result = pd.concat((selected, heldout), ignore_index=True)
    result["ks_rank"] = result["ks_rank"].astype("Int32")
    result["scaling_train_size"] = np.int32(size)
    if len(selected) != size:
        raise RuntimeError(f"expected {size:,} train rows, found {len(selected):,}")
    return result


def _validate_nested(
    split_files: Sequence[tuple[int, pd.DataFrame]],
    heldout_ids: set[str],
) -> None:
    previous: set[str] = set()
    for size, frame in split_files:
        train = set(frame.loc[frame["split"].eq("train"), "align_sample_id"])
        heldout = set(frame.loc[frame["split"].ne("train"), "align_sample_id"])
        if len(train) != size:
            raise RuntimeError(f"{size:,} split has {len(train):,} training rows")
        if not previous.issubset(train):
            raise RuntimeError(f"{size:,} split is not nested")
        if heldout != heldout_ids:
            raise RuntimeError(f"{size:,} split changed validation/test molecules")
        previous = train


def run(
    *,
    split_file: str,
    output_dir: str,
    sizes: Sequence[int],
    workers: int,
    seed: int,
    fingerprint_bits: int,
    projection_dims: int,
    target_group_size: int,
) -> dict[str, object]:
    source_path = Path(split_file)
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    original = pd.read_parquet(source_path, columns=list(SPLIT_COLUMNS))
    if original["align_sample_id"].isna().any():
        raise ValueError("official aligned split contains missing align_sample_id values")
    if original["align_sample_id"].duplicated().any():
        raise ValueError("official aligned split contains duplicate align_sample_id values")

    train = original.loc[original["split"].eq("train")].reset_index(drop=True)
    normalized_sizes = tuple(sorted(set(map(int, sizes))))
    if not normalized_sizes or normalized_sizes[0] < 1:
        raise ValueError("at least one positive subset size is required")
    if normalized_sizes[-1] > len(train):
        raise ValueError(
            f"largest subset ({normalized_sizes[-1]:,}) exceeds train pool "
            f"({len(train):,})"
        )

    raw_features, valid = featurize_smiles(
        train["canonical_smiles"].astype(str).tolist(),
        workers=workers,
        seed=seed,
        fingerprint_bits=fingerprint_bits,
        projection_dims=projection_dims,
    )
    rank = nested_kennard_stone_rank(
        train,
        raw_features,
        seed=seed,
        target_group_size=target_group_size,
    )
    rank_frame = train[
        ["align_sample_id", "inchikey", "align_source", "split_scaffold"]
    ].copy()
    rank_frame["ks_rank"] = rank.astype(np.int32)
    rank_frame = rank_frame.sort_values("ks_rank").reset_index(drop=True)
    rank_path = destination / "kennard_stone_rank.parquet"
    rank_frame.to_parquet(rank_path, index=False, compression="zstd")

    heldout_ids = set(
        original.loc[original["split"].ne("train"), "align_sample_id"].astype(str)
    )
    materialized = []
    outputs: dict[str, object] = {}
    total_scaffolds = train["split_scaffold"].nunique(dropna=False)
    for size in normalized_sizes:
        frame = build_scaling_split(original, rank_frame, size)
        materialized.append((size, frame))
        path = destination / f"align_ks_{size // 1000}k.parquet"
        frame.to_parquet(path, index=False, compression="zstd")
        selected = frame.loc[frame["split"].eq("train")]
        outputs[f"{size // 1000}k"] = {
            "path": str(path),
            "sha256": _sha256(path),
            "train": int(len(selected)),
            "validation": int(frame["split"].eq("validation").sum()),
            "test": int(frame["split"].eq("test").sum()),
            "unique_inchikey_train": int(selected["inchikey"].nunique()),
            "unique_scaffolds_train": int(
                selected["split_scaffold"].nunique(dropna=False)
            ),
            "scaffold_coverage": float(
                selected["split_scaffold"].nunique(dropna=False) / total_scaffolds
            ),
            "source_counts": {
                str(key): int(value)
                for key, value in selected["align_source"].value_counts().items()
            },
        }
    _validate_nested(materialized, heldout_ids)

    summary = {
        "algorithm": "source-stratified approximate Kennard-Stone",
        "source_split": str(source_path),
        "source_split_sha256": _sha256(source_path),
        "seed": seed,
        "fingerprint": {
            "kind": "Morgan",
            "radius": 2,
            "bits": fingerprint_bits,
            "signed_projection_dimensions": projection_dims,
        },
        "molecular_descriptors": [
            "molecular_weight",
            "heavy_atoms",
            "hetero_atoms",
            "rings",
            "rotatable_bonds",
            "formal_charge",
            "fraction_csp3",
            "tpsa",
        ],
        "target_group_size": target_group_size,
        "train_pool": int(len(train)),
        "validation": int(original["split"].eq("validation").sum()),
        "test": int(original["split"].eq("test").sum()),
        "fingerprint_failures": int((~valid).sum()),
        "nested": True,
        "heldout_sets_unchanged": True,
        "rank_file": {
            "path": str(rank_path),
            "sha256": _sha256(rank_path),
            "records": int(len(rank_frame)),
        },
        "subsets": outputs,
    }
    summary_path = destination / "summary.json"
    with summary_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    return {"summary": str(summary_path), **summary}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Persist nested fingerprint Kennard-Stone scaling splits"
    )
    parser.add_argument(
        "--split-file",
        default="builds/openmolspec-20260830/release-v1/splits/align_split.parquet",
    )
    parser.add_argument(
        "--output-dir",
        default="builds/openmolspec-20260830/release-v1/splits/scaling",
    )
    parser.add_argument("--sizes", nargs="+", type=int, default=list(DEFAULT_SIZES))
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--seed", type=int, default=2025)
    parser.add_argument("--fingerprint-bits", type=int, default=512)
    parser.add_argument("--projection-dims", type=int, default=24)
    parser.add_argument("--target-group-size", type=int, default=128)
    args = parser.parse_args()
    summary = run(
        split_file=args.split_file,
        output_dir=args.output_dir,
        sizes=args.sizes,
        workers=args.workers,
        seed=args.seed,
        fingerprint_bits=args.fingerprint_bits,
        projection_dims=args.projection_dims,
        target_group_size=args.target_group_size,
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
