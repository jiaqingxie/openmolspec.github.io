"""Rebuild 200k/1M property LMDBs with paired, TMS-referenced H/C NMR shifts.

Reuse validated normalized spectra/physical-unit targets, not model checkpoints.
Original payloads and source LMDBs remain unchanged. No model training is run.
"""

import argparse
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import pickle
import time

import h5py
import lmdb
import numpy as np
import pandas as pd
from tqdm import tqdm

from benchmarks.data.nmr_reference import hc_shift_record, load_tms_reference
from benchmarks.data.prepare import load_official_split
from benchmarks.data.scalar_properties import PROPERTY_UNITS


def read_array(arrays, name, row):
    group = arrays[name]
    if not group["present"][row]:
        raise ValueError(f"Missing {name}")
    start, end = group["offsets"][row:row + 2]
    shape = group["shapes"][row]
    return group["values"][int(start):int(end)].reshape(tuple(shape[shape >= 0]))


def validate_source(record, sample_id, inchikey):
    if record.get("sample_id") != sample_id or record.get("inchikey") != inchikey:
        raise ValueError(f"{sample_id}: source identity mismatch")
    if record.get("spectrum_normalization", {}).get("method") != "minmax":
        raise ValueError(f"{sample_id}: source is not minmax normalized")
    for field in ("ir", "raman"):
        x = np.asarray(record[field])
        if x.dtype != np.float32 or x.shape != (1024,) or not np.isfinite(x).all():
            raise ValueError(f"{sample_id}: invalid float32 {field}")
        if x.min() < 0 or x.max() > 1:
            raise ValueError(f"{sample_id}: spectrum outside [0,1]")
    for field, unit in PROPERTY_UNITS.items():
        if record.get("units", {}).get(field) != unit or not np.isfinite(record[field]):
            raise ValueError(f"{sample_id}: invalid target/unit {field}")


def run(source, nmr_payload, split_files, outputs, reference_log, limit_per_split=None):
    source, nmr_payload = Path(source), Path(nmr_payload)
    reference = load_tms_reference(reference_log)
    outputs = {name: Path(path) for name, path in outputs.items()}
    if set(outputs) != set(split_files) or not outputs:
        raise ValueError("Provide matching nonempty split/output mappings")
    paths = [p.resolve() for p in outputs.values()]
    if len(set(paths)) != len(paths) or any(a in b.parents for a in paths for b in paths if a != b):
        raise ValueError("Output directories must be distinct and non-nested")
    for path in outputs.values():
        if path.exists():
            raise FileExistsError(f"Refusing to overwrite {path}")
        if source.resolve() == path.resolve() or source.resolve() in path.resolve().parents:
            raise ValueError("Output must be separate from source")
    if limit_per_split is not None and limit_per_split < 1:
        raise ValueError("limit-per-split must be positive")
    source_index = pd.read_parquet(source / "benchmark_split.parquet")
    if source_index.sample_id.duplicated().any():
        raise ValueError("Duplicate source IDs")
    source_index = source_index.set_index("sample_id")
    splits, memberships = {}, {}
    for name, file in split_files.items():
        split = load_official_split(str(file))
        split["split"] = split.split.replace({"validation": "eval"})
        if not set(split.split).issubset({"train", "eval", "test"}):
            raise ValueError("Invalid split label")
        if not set(split.sample_id).issubset(source_index.index):
            raise ValueError("Missing IDs in source data")
        original = source_index.loc[split.sample_id]
        if not np.array_equal(original.split.to_numpy(), split.split.to_numpy()) or not np.array_equal(
                original.inchikey.to_numpy(), split.inchikey.to_numpy()):
            raise ValueError("Source and official split identity/assignments disagree")
        for mode in ("eval", "test"):
            if set(split.loc[split.split == mode, "sample_id"]) != set(source_index.index[source_index.split == mode]):
                raise ValueError("Validation/test IDs must match the full source")
        if set(split.split) != {"train", "eval", "test"}:
            raise ValueError("Empty split")
        splits[name] = split
        memberships[name] = set(split.sample_id)
    ordered = sorted(memberships, key=lambda name: len(memberships[name]))
    if any(not memberships[a].issubset(memberships[b]) for a, b in zip(ordered, ordered[1:])):
        raise ValueError("Training subsets must be nested")
    if limit_per_split:
        small = splits[ordered[0]].groupby("split", sort=False).head(limit_per_split)
        keep = set(small.sample_id)
        for name in splits:
            splits[name] = splits[name][splits[name].sample_id.isin(keep)].copy()
            memberships[name] = set(splits[name].sample_id)
    union = pd.concat(splits.values()).drop_duplicates("sample_id")
    index = pd.read_parquet(nmr_payload / "index.parquet")
    selected = union.merge(index[["sample_id", "shard", "row_in_shard"]],
                           on="sample_id", how="left", validate="one_to_one")
    if selected.shard.isna().any():
        raise ValueError("Missing paired NMR records; refusing cross-record fallback")
    summaries = {}
    for name, output in outputs.items():
        (output / "vib2conf").mkdir(parents=True)
        summaries[name] = {
            "state": "building", "version": "hc-nmr-v1", "source": str(source.resolve()),
            "nmr_payload": str(nmr_payload.resolve()), "reference": reference,
            "split_file": str(Path(split_files[name]).resolve()),
            "split_sha256": hashlib.sha256(Path(split_files[name]).read_bytes()).hexdigest(),
            "counts": {}, "units": PROPERTY_UNITS, "excluded": 0,
            "nmr_pairing": "same align_sample_id, no cross-record or conformer substitution",
            "nmr_representation": "unassigned sorted per-atom shifts, not grouped experimental peaks",
            "nmr_method_verification": "reference validated; source protocol assumed from production template, not individually verified",
            "available_modalities": ["ir", "raman", "1H-NMR", "13C-NMR"], "model_agnostic": True,
            "limit_per_split": limit_per_split,
        }
        (output / "summary.json").write_text(json.dumps(summaries[name], indent=2) + "\n")
        (output / "nmr_reference.json").write_text(json.dumps(reference, indent=2) + "\n")
    started = time.monotonic()
    try:
        for mode in ("train", "eval", "test"):
            subset = selected[selected.split == mode]
            counts = {name: 0 for name in outputs}
            stats = {name: {label: {"nuclei": 0, "empty_records": 0, "min_ppm": None, "max_ppm": None}
                            for label in ("h", "c")} for name in outputs}
            with ExitStack() as stack:
                source_path = source / "vib2conf" / f"{mode}.lmdb"
                reader = lmdb.open(str(source_path), subdir=False, readonly=True, lock=False, readahead=True)
                stack.callback(reader.close)
                read = stack.enter_context(reader.begin())
                writers, txns = {}, {}
                for name, output in outputs.items():
                    writers[name] = lmdb.open(str(output / "vib2conf" / f"{mode}.lmdb"),
                                             subdir=False, map_size=max(1 << 30, source_path.stat().st_size * 3))
                    stack.callback(writers[name].close)
                    txns[name] = writers[name].begin(write=True)
                try:
                    with tqdm(total=len(subset), desc=f"H/C multimodal {mode}", unit="record", mininterval=5) as progress:
                        for shard, rows in subset.groupby("shard", sort=True):
                            with h5py.File(nmr_payload / f"{shard}.h5", "r") as handle:
                                arrays = {field: {key: handle["arrays"][field][key][:]
                                                  for key in ("values", "offsets", "shapes", "present")}
                                          for field in ("atomic_numbers", "nmr_isotropic")}
                            for row in rows.sort_values("sample_id").itertuples():
                                key = row.sample_id.encode()
                                raw = read.get(key)
                                if raw is None:
                                    raise ValueError(f"Missing source LMDB key {row.sample_id}")
                                record = pickle.loads(raw)
                                validate_source(record, row.sample_id, row.inchikey)
                                if "nmr_reference_id" in record:
                                    raise ValueError("Source already has derived NMR; select the original minmax source")
                                record.update(hc_shift_record(
                                    read_array(arrays, "atomic_numbers", int(row.row_in_shard)),
                                    read_array(arrays, "nmr_isotropic", int(row.row_in_shard)), reference))
                                record["nmr_sample_id"] = row.sample_id
                                value = pickle.dumps(record, protocol=pickle.HIGHEST_PROTOCOL)
                                for name in outputs:
                                    if row.sample_id not in memberships[name]:
                                        continue
                                    txns[name].put(key, value)
                                    counts[name] += 1
                                    for label in ("h", "c"):
                                        v = record[f"nmr_{label}_shifts_ppm"]
                                        st = stats[name][label]
                                        st["nuclei"] += len(v)
                                        st["empty_records"] += int(len(v) == 0)
                                        if len(v):
                                            lo, hi = float(v[0]), float(v[-1])
                                            st["min_ppm"] = lo if st["min_ppm"] is None else min(lo, st["min_ppm"])
                                            st["max_ppm"] = hi if st["max_ppm"] is None else max(hi, st["max_ppm"])
                                    if counts[name] % 8192 == 0:
                                        txns[name].commit()
                                        txns[name] = writers[name].begin(write=True)
                                progress.update()
                    for name in outputs:
                        expected = int((splits[name].split == mode).sum())
                        if counts[name] != expected:
                            raise ValueError(f"{name}/{mode}: count mismatch")
                        txns[name].commit()
                        txns[name] = None
                        writers[name].sync()
                        summaries[name]["counts"][mode] = counts[name]
                        summaries[name].setdefault("nmr_statistics", {})[mode] = stats[name]
                finally:
                    for txn in txns.values():
                        if txn is not None:
                            txn.abort()
        for name, output in outputs.items():
            splits[name].to_parquet(output / "benchmark_split.parquet", index=False)
            summaries[name].update(state="completed", elapsed_seconds=time.monotonic() - started)
            (output / "summary.json").write_text(json.dumps(summaries[name], indent=2) + "\n")
    except Exception as exc:
        for name, output in outputs.items():
            summaries[name].update(state="failed", error=str(exc))
            (output / "summary.json").write_text(json.dumps(summaries[name], indent=2) + "\n")
        raise
    return summaries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", default="benchmark_data/spectrum_properties_ks1000k_minmax")
    parser.add_argument("--release", default="builds/openmolspec-20260830/release-v1")
    parser.add_argument("--output-root", default="benchmark_data")
    parser.add_argument("--reference-log", default="artifacts/calculations/tms_reference/tms_reference.log")
    parser.add_argument("--limit-per-split", type=int)
    args = parser.parse_args()
    release = Path(args.release)
    print(json.dumps(run(args.source, release / "payload/nmr",
        {"200k": release / "splits/scaling/align_ks_200k.parquet",
         "1000k": release / "splits/align_split.parquet"},
        {name: Path(args.output_root) / f"spectrum_properties_ks{name}_hc_nmr_minmax"
         for name in ("200k", "1000k")}, args.reference_log, args.limit_per_split), indent=2))


if __name__ == "__main__":
    main()
