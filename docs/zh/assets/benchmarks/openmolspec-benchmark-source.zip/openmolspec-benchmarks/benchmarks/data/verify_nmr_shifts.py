"""Read every exported graph and verify labels, split identity and summary counts."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import pickle

import lmdb
import numpy as np
import pandas as pd
from tqdm import tqdm

from benchmarks.data.prepare import load_official_split


def verify(output):
    output = Path(output)
    summary = json.loads((output / 'summary.json').read_text())
    assert summary['state'] == 'completed', 'Build is not complete'
    assert not summary['skip_invalid'] and summary['excluded'] == 0
    source = Path(summary['split_file'])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == summary['split_sha256']
    expected = load_official_split(str(source))
    expected['split'] = expected.split.replace({'validation': 'eval'})
    if summary['limit_per_split']:
        expected = expected.groupby('split', sort=False).head(summary['limit_per_split'])
    saved = pd.read_parquet(output / 'benchmark_split.parquet')
    pd.testing.assert_frame_equal(
        saved.sort_values('sample_id').reset_index(drop=True),
        expected.sort_values('sample_id').reset_index(drop=True))
    assert expected.inchikey.is_unique
    if 'split_scaffold' in expected:
        assert expected.groupby('split_scaffold').split.nunique().max() == 1
    reference = summary['reference']
    recovered = []
    result = {}
    for mode in ('train', 'eval', 'test'):
        rows = expected[expected.split == mode].set_index('sample_id')
        seen = set()
        atoms = Counter()
        moments = {x: [0., 0.] for x in ('h', 'c')}
        no_target = 0
        with lmdb.open(str(output / 'equiformer_v3' / f'{mode}.lmdb'),
                       subdir=False, readonly=True, lock=False) as env:
            with env.begin() as txn:
                assert txn.stat()['entries'] == len(rows) == summary['counts'][mode]
                for key, raw in tqdm(txn.cursor(), total=len(rows), desc=f'Verify {mode}', mininterval=5):
                    sid = key.decode()
                    assert sid in rows.index and sid not in seen, sid
                    seen.add(sid)
                    d = pickle.loads(raw)  # Locally built, trusted artifacts only.
                    assert d.sample_id == sid and d.inchikey == rows.loc[sid, 'inchikey'], sid
                    assert d.source_dataset == rows.loc[sid, 'source_dataset'], sid
                    z, pos, y = d.atomic_numbers.numpy(), d.pos.numpy(), d.nmr_shift.numpy()
                    n = len(z)
                    h, c = z == 1, z == 6
                    assert pos.shape == (n, 3) and y.shape == (n, 1), sid
                    assert np.isfinite(pos).all() and np.isfinite(y).all(), sid
                    assert np.array_equal(d.atom_id.numpy(), np.arange(n)), sid
                    assert np.array_equal(d.nmr_h_mask.numpy(), h), sid
                    assert np.array_equal(d.nmr_c_mask.numpy(), c), sid
                    assert np.array_equal(d.nmr_mask.numpy(), h | c), sid
                    assert bool(d.has_nmr_target.item()) == bool((h | c).any()), sid
                    assert (y[~(h | c)] == 0).all(), sid
                    assert d.nmr_reference_id == reference['id'] and d.nmr_shift_unit == 'ppm', sid
                    edges = d.edge_index.numpy()
                    assert edges.shape[0] == 2 and ((edges >= 0) & (edges < n)).all(), sid
                    if edges.size:
                        assert (edges[0] != edges[1]).all(), sid
                        distances = np.linalg.norm(pos[edges[0]] - pos[edges[1]], axis=1)
                        assert (distances <= summary['cutoff_angstrom'] + 1e-5).all(), sid
                    no_target += int(not (h | c).any())
                    for name, mask in (('h', h), ('c', c)):
                        values = y[mask].astype(np.float64)
                        atoms[name] += len(values)
                        moments[name][0] += values.sum()
                        moments[name][1] += np.square(values).sum()
                    if not d.normal_termination.item():
                        recovered.append((sid, mode, d.nmr_completion))
        assert seen == set(rows.index)
        assert no_target == summary['no_hc_target_counts'][mode]
        assert len(seen) - no_target == summary['supervised_counts'][mode]
        assert sum(r[1] == mode for r in recovered) == summary['recovered_abnormal_termination_counts'][mode]
        for name in ('h', 'c'):
            stats = summary['nuclei'][mode][name]
            assert atoms[name] == stats['count']
            np.testing.assert_allclose(moments[name], [stats['sum'], stats['sum_sq']], rtol=1e-9, atol=1e-6)
            if mode == 'train' and atoms[name]:
                normalizer = summary['train_target_statistics'][name]
                mean = moments[name][0] / atoms[name]
                std = np.sqrt(max(0., moments[name][1] / atoms[name] - mean**2))
                assert normalizer['count'] == atoms[name]
                np.testing.assert_allclose([normalizer['mean_ppm'], normalizer['std_ppm']],
                                           [mean, std], rtol=1e-9, atol=1e-6)
        result[mode] = dict(records=len(seen), atoms=dict(atoms), no_hc=no_target)
    audit = pd.read_parquet(output / 'recovered_records.parquet')
    assert set(recovered) == set(audit.itertuples(index=False, name=None))
    assert len(audit) == len(recovered)
    assert pd.read_parquet(output / 'excluded_records.parquet').empty
    result['recovered_records'] = len(recovered)
    result['status'] = 'verified'
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    result = verify(args.output)
    (Path(args.output) / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
