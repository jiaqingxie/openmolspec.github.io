"""Profile training labels only, in benchmark units, without preparing spectra."""
import argparse
import json
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
from tqdm import tqdm

from benchmarks.data.prepare import load_official_split
from benchmarks.data.prepare_hessian import read_array
from benchmarks.data.scalar_properties import PROPERTY_UNITS, polar_invariants, convert_benchmark_units


def run(payload, split_file, output):
    payload, output = Path(payload), Path(output)
    split = load_official_split(split_file)
    split = split[split['split'] == 'train']
    index = pd.read_parquet(payload / 'index.parquet')
    selected = split.merge(index[['sample_id', 'shard', 'row_in_shard']],
                           on='sample_id', how='left', validate='one_to_one')
    if selected.shard.isna().any():
        raise ValueError('Training IDs missing from payload')
    records = []
    fields = ('dipole_total', 'gap', 'polar')
    for shard, rows in tqdm(list(selected.groupby('shard')), desc='Training label ranges'):
        with h5py.File(payload / f'{shard}.h5', 'r') as handle:
            source = {'arrays': {field: {key: handle['arrays'][field][key][:]
                       for key in ('values', 'offsets', 'shapes', 'present')}
                       for field in fields}}
            for row in rows.itertuples():
                values = {field: read_array(source, field, int(row.row_in_shard)) for field in fields}
                result = {}
                for name in ('dipole_total', 'gap'):
                    a = np.asarray(values[name], dtype=float).reshape(-1)
                    result[name] = float(a[0]) if a.size == 1 else float('nan')
                result['polar_iso'], result['polar_anisotropy'] = polar_invariants(values['polar'])
                convert_benchmark_units(result)
                records.append({name: result[name] for name in PROPERTY_UNITS})
    frame = pd.DataFrame(records)
    common = np.isfinite(frame).all(axis=1)
    stats = {}
    for name, unit in PROPERTY_UNITS.items():
        values = frame.loc[common, name].to_numpy()
        if not len(values):
            raise ValueError('No complete training labels')
        mean, std = float(values.mean()), float(values.std())
        stats[name] = dict(unit=unit, count=len(values), mean=mean, std=std,
                          negative=int((values < 0).sum()), zero=int((values == 0).sum()),
                          outside_5std=int((np.abs(values-mean) > 5*std).sum()),
                          **{key: float(value) for key, value in zip(
                              ('min', 'p01', 'p05', 'p50', 'p95', 'p99', 'max'),
                              np.quantile(values, [0, .01, .05, .5, .95, .99, 1]))})
    summary = dict(split_file=str(Path(split_file).resolve()), split='train',
                   requested=len(selected), complete_labels=int(common.sum()),
                   missing_labels=int((~common).sum()),
                   scope='Label-complete training candidates; spectra not revalidated here', targets=stats)
    output.mkdir(parents=True, exist_ok=True)
    (output / 'target_ranges.json').write_text(json.dumps(summary, indent=2)+'\n')
    pd.DataFrame(stats).T.to_csv(output / 'target_ranges.csv', index_label='target')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--payload', default='builds/openmolspec-20260830/release-v1/payload/frequency')
    parser.add_argument('--split-file', default='builds/openmolspec-20260830/release-v1/splits/scaling/align_ks_200k.parquet')
    parser.add_argument('--output', default='reports/benchmark/spectrum_property_ranges_ks200k')
    print(json.dumps(run(**vars(parser.parse_args())), indent=2))
