"""Stream frozen frequency shards into Harmony-style Hi/Hij training LMDBs."""

import argparse
import json
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
import torch
from torch_geometric.data import Data
from tqdm import tqdm

from benchmarks.data.prepare import _write_lmdb, load_official_split
from openmolspec.core.constants import HESSIAN_AU_TO_EV_ANGSTROM2


def hessian_record(z, pos, hessian, sample_id, cutoff=5.0):
    z = np.asarray(z, dtype=np.int64).reshape(-1)
    pos = np.asarray(pos, dtype=np.float64)
    h = np.asarray(hessian, dtype=np.float64)
    n = len(z)
    if pos.shape == (3*n,):
        pos = pos.reshape(n, 3)
    if pos.shape != (n, 3) or h.shape != (3*n, 3*n):
        raise ValueError(f"{sample_id}: incompatible coordinate/Hessian shapes")
    if not np.isfinite(pos).all() or not np.isfinite(h).all():
        raise ValueError(f"{sample_id}: nonfinite coordinate/Hessian")
    if not np.allclose(h, h.T, atol=1e-6, rtol=1e-5):
        raise ValueError(f"{sample_id}: asymmetric reference Hessian")
    h = h * HESSIAN_AU_TO_EV_ANGSTROM2
    distances = np.linalg.norm(pos[:, None] - pos[None, :], axis=-1)
    if np.any((distances + np.eye(n)) < 1e-8):
        raise ValueError(f"{sample_id}: overlapping atoms")
    mask = (distances < cutoff) & ~np.eye(n, dtype=bool)
    dst, src = np.where(mask)
    if len(src) == 0:
        raise ValueError(f"{sample_id}: no radius edges")
    blocks = h.reshape(n, 3, n, 3)
    hi = blocks[np.arange(n), :, np.arange(n), :]
    hij = blocks[dst, :, src, :]
    retained = np.eye(n, dtype=bool) | mask
    omitted = blocks.transpose(0, 2, 1, 3)[~retained]
    data = Data(
        pos=torch.tensor(pos, dtype=torch.float32),
        atomic_numbers=torch.tensor(z), natoms=torch.tensor([n]),
        edge_index=torch.tensor(np.stack((src, dst)), dtype=torch.long),
        Hi=torch.tensor(hi, dtype=torch.float32),
        Hij=torch.tensor(hij, dtype=torch.float32), sample_id=str(sample_id),
    )
    return data, float(np.sum(omitted**2)), float(np.sum(h**2))


def read_array(handle, name, row):
    group = handle["arrays"][name]
    if not group["present"][row]:
        raise ValueError(f"missing {name}")
    start, end = group["offsets"][row:row+2]
    shape = group["shapes"][row]
    return group["values"][int(start):int(end)].reshape(tuple(shape[shape >= 0]))


def run(payload, split_file, output, limit_per_split=None, cutoff=5.0):
    payload, output = Path(payload), Path(output)
    if cutoff <= 0 or (limit_per_split is not None and limit_per_split < 1):
        raise ValueError("cutoff and limit must be positive")
    split = load_official_split(str(split_file))
    split["split"] = split["split"].replace({"validation": "eval"})
    if limit_per_split:
        split = split.groupby("split", sort=False).head(limit_per_split).copy()
    index = pd.read_parquet(payload / "index.parquet")
    selected = split.merge(index[["sample_id", "shard", "row_in_shard"]],
                           on="sample_id", how="left", validate="one_to_one")
    if selected["shard"].isna().any():
        raise ValueError("Some split records are missing from frequency payload")
    if any((output / "equiformer_v3" / f"{s}.lmdb").exists()
           for s in ("train", "eval", "test")):
        raise FileExistsError("Choose a new output directory; LMDB already exists")
    counts, audit = {}, []
    for mode in ("train", "eval", "test"):
        subset = selected[selected["split"] == mode]
        if subset.empty:
            raise ValueError(f"Empty {mode} split")
        def records():
            with tqdm(total=len(subset), desc=f"Hessian {mode}") as progress:
                for shard, rows in subset.groupby("shard", sort=True):
                    with h5py.File(payload / f"{shard}.h5", "r") as handle:
                        # Read each compressed field once per shard for large exports.
                        # Sparse smoke selections can read individual records instead.
                        source = handle
                        if len(rows) > 32:
                            source = {"arrays": {
                                name: {key: handle["arrays"][name][key][:]
                                       for key in ("values", "offsets", "shapes", "present")}
                                for name in ("atomic_numbers", "coordinates", "hessian")}}
                        for row in rows.itertuples():
                            arrays = [read_array(source, name, int(row.row_in_shard))
                                      for name in ("atomic_numbers", "coordinates", "hessian")]
                            data, omitted, total = hessian_record(
                                *arrays, row.sample_id, cutoff=cutoff)
                            data.source_dataset = row.source_dataset
                            data.inchikey = row.inchikey
                            audit.append({"sample_id": row.sample_id, "split": mode,
                                          "omitted_squared_norm": omitted,
                                          "total_squared_norm": total})
                            yield row.sample_id, data
                            progress.update()
        counts[mode] = _write_lmdb(
            output / "equiformer_v3" / f"{mode}.lmdb", records(),
            map_size=200 * 1024**3,
        )
    selected.to_parquet(output / "benchmark_split.parquet", index=False)
    pd.DataFrame(audit).to_parquet(output / "hessian_coverage.parquet", index=False)
    total = sum(r["total_squared_norm"] for r in audit)
    summary = {"counts": counts, "cutoff_angstrom": cutoff,
               "hessian_unit": "eV/Angstrom^2", "mass_weighted": False,
               "input_hessian_unit": "Hartree/Bohr^2",
               "unit_conversion_factor": HESSIAN_AU_TO_EV_ANGSTROM2,
               "edge_convention": "Hij = H[target, :, source, :]",
               "omitted_frobenius_fraction": (sum(r["omitted_squared_norm"] for r in audit)
                                               / max(total, 1e-30))**0.5,
               "payload": str(payload.resolve()), "split_file": str(Path(split_file).resolve()),
               "limit_per_split": limit_per_split}
    (output / "summary.json").write_text(json.dumps(summary, indent=2)+"\n")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", default="builds/openmolspec-20260830/release-v1/payload/frequency")
    parser.add_argument("--split-file", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--limit-per-split", type=int)
    parser.add_argument("--cutoff", type=float, default=5.0)
    print(json.dumps(run(**vars(parser.parse_args())), indent=2))


if __name__ == "__main__":
    main()
