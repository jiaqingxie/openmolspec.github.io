"""Fixed optimizer-update budget and validation cadence for scaling runs."""
import time

import torch
from tqdm import tqdm

from benchmarks.trainers.base import TrainingOutcome


def run_steps(trainer, writer):
    engine = trainer.engine
    if trainer.evaluate_only:
        trainer._load_model_and_normalizer()
        validation = engine.evaluate_validation()
        test = engine.evaluate_test()
        trainer._write_test_scalars(writer, test, 0)
        return TrainingOutcome(validation, test)
    if not len(engine.train_loader):
        raise ValueError('Step training requires a nonempty train loader')
    iterator = None
    epoch = 0
    best_score = float('inf')
    best_validation, best_state = {}, None
    running = 0.
    count = 0
    started = time.monotonic()
    last_log = started
    progress = tqdm(range(1, trainer.max_steps + 1), desc='Train steps',
                    disable=not engine.is_primary or engine.progress_mode != 'tqdm',
                    dynamic_ncols=True)
    for step in progress:
        if iterator is None:
            sampler = getattr(engine.train_loader, 'sampler', None)
            if hasattr(sampler, 'set_epoch'):
                sampler.set_epoch(epoch)
            iterator = iter(engine.train_loader)
        try:
            batch = next(iterator)
        except StopIteration:
            epoch += 1
            sampler = getattr(engine.train_loader, 'sampler', None)
            if hasattr(sampler, 'set_epoch'):
                sampler.set_epoch(epoch)
            iterator = iter(engine.train_loader)
            batch = next(iterator)
        engine.model.train()
        batch = engine.move_batch(batch)
        rates = [g['lr'] for g in engine.optimizer.param_groups]
        engine.optimizer.zero_grad(set_to_none=True)
        loss = engine.compute_loss(batch)
        loss.backward()
        engine.optimizer.step()
        if trainer.scheduler is not None:
            trainer.scheduler.step()
        trainer.global_step = step
        running += float(loss.detach())
        count += 1
        if engine.is_primary and engine.progress_mode == 'tqdm':
            progress.set_description(f'Train step {step}/{trainer.max_steps} loss:{running/count:.6f}')
        now = time.monotonic()
        if engine.is_primary and engine.progress_mode == 'log' and now-last_log >= engine.progress_interval_seconds:
            print(f'[{engine.name}] step {step}/{trainer.max_steps} | loss={running/count:.6g} | lr={rates[0]:.6g}', flush=True)
            last_log = now
        if writer is not None and (step == 1 or step % 100 == 0 or step == trainer.max_steps):
            for i, rate in enumerate(rates):
                writer.add_scalar(f'train/learning_rate_group_{i}', rate, step)
        if step % trainer.eval_every_steps and step != trainer.max_steps:
            continue
        totals = torch.tensor([running, count], device=trainer.device, dtype=torch.float64)
        if torch.distributed.is_initialized():
            torch.distributed.all_reduce(totals)
        mean_loss = (totals[0]/totals[1]).item()
        validation = engine.evaluate_validation(description=f'Step {step} [Valid]')
        score = trainer.validation_score(validation)
        if score < best_score:
            best_score, best_validation = score, validation
            trainer.best_step = step
            if trainer.debug:
                best_state = {k:v.detach().cpu().clone() for k,v in trainer.model.state_dict().items()}
            else:
                trainer._save_checkpoint()
        if writer is not None:
            writer.add_scalar('train/loss', mean_loss, step)
            writer.add_scalar('time/elapsed_seconds', time.monotonic()-started, step)
            for name, value in validation.items():
                writer.add_scalar(f'validation/{name}', value, step)
            writer.flush()
        if engine.is_primary:
            progress.write(f'[{engine.name}] step {step}/{trainer.max_steps} | train_loss={mean_loss:.6g} | '
                           + ' | '.join(f'{k}={v:.6g}' for k,v in validation.items()))
        running, count = 0., 0
    if trainer.debug:
        if best_state is None:
            raise RuntimeError('No finite validation score')
        trainer.model.load_state_dict(best_state)
    else:
        trainer._load_model_and_normalizer()
    test = engine.evaluate_test()
    trainer._write_test_scalars(writer, test, trainer.best_step)
    return TrainingOutcome(best_validation, test)
