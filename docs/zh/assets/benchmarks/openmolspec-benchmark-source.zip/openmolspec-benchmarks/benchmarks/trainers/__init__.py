"""Experiment-level benchmark trainers.

Concrete trainers are imported lazily so selecting Equiformer does not import
Vib2Conf's vendored dependency tree, and vice versa.
"""

__all__ = [
    "BaseTrainer",
    "TrainingOutcome",
    "EquiformerTrainer",
    "Vib2ConfPropertyTrainer",
]


def __getattr__(name: str):
    if name in {"BaseTrainer", "TrainingOutcome"}:
        from .base import BaseTrainer, TrainingOutcome

        return {
            "BaseTrainer": BaseTrainer,
            "TrainingOutcome": TrainingOutcome,
        }[name]
    if name == "EquiformerTrainer":
        from .equiformer import EquiformerTrainer

        return EquiformerTrainer
    if name == "Vib2ConfPropertyTrainer":
        from .vib2conf import Vib2ConfPropertyTrainer

        return Vib2ConfPropertyTrainer
    raise AttributeError(name)
