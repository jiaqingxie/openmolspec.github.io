"""YAML-driven benchmark experiment launcher.

The runner normalizes the public experiment contract and delegates model work
to the existing adapters. Normal runs persist reproducibility metadata and
artifacts in one run directory; debug runs use an automatically cleaned
temporary directory and leave no files behind.
"""

from __future__ import annotations

import errno
import fcntl
import importlib.metadata
import json
import os
import platform
import pty
import shutil
import shlex
import struct
import subprocess
import sys
import tempfile
import termios
import time
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, MutableMapping, Optional

import yaml

from benchmarks.models.registry import REPOSITORY_ROOT


SUPPORTED_TASKS = (
    "structure2nmr",
    "structure2hessian",
    "structure2response",
    "structure2property",
    "structure2spectrum",
    "structure2observables",
    "spectrum2structure",
    "spectrum2property",
)
PROPERTY_TARGETS = ("energy", "homo", "lumo", "gap", "dipole_total", "zpve")
SPECTRUM_TARGETS = ("ir_spectrum", "raman_spectrum")
DEBUG_SUPPORTED_TASKS = (
    "structure2nmr",
    "spectrum2structure",
    "structure2hessian",
    "structure2response",
    "structure2property",
    "structure2spectrum",
    "structure2observables",
    "spectrum2property",
)


def _mapping(config: Mapping[str, Any], key: str) -> Dict[str, Any]:
    value = config.get(key, {})
    if not isinstance(value, Mapping):
        raise ValueError(f"YAML section '{key}' must be a mapping")
    return dict(value)


def _required(section: Mapping[str, Any], key: str, section_name: str) -> Any:
    value = section.get(key)
    if value is None or value == "":
        raise ValueError(f"YAML requires '{section_name}.{key}'")
    return value


def _slug(value: Any) -> str:
    text = str(value).strip().lower().replace("_", "-")
    allowed = "abcdefghijklmnopqrstuvwxyz0123456789-."
    slug = "".join(character if character in allowed else "-" for character in text)
    return "-".join(part for part in slug.split("-") if part) or "default"


def _repository_path(value: str | Path) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = REPOSITORY_ROOT / path
    return path.resolve()


def _apply_debug_overrides(config: Mapping[str, Any]) -> Dict[str, Any]:
    """Return an isolated, quick experiment configuration for debugging."""

    resolved = deepcopy(dict(config))
    family = str(resolved["task"]["family"])
    if family not in DEBUG_SUPPORTED_TASKS:
        supported = ", ".join(DEBUG_SUPPORTED_TASKS)
        raise ValueError(
            f"Debug mode is not implemented safely for {family}; "
            f"currently supported: {supported}"
        )
    resolved["debug"]["enabled"] = True
    if 'max_steps' not in resolved['training']:
        resolved["training"]["epochs"] = 1
    resolved["training"]["workers"] = 0
    if family not in ("structure2hessian", "structure2response", "structure2nmr", "spectrum2structure"):
        resolved["training"]["gpus"] = 1
    if family == 'spectrum2structure' and 'max_steps' not in resolved['training']:
        resolved['training']['generation_epochs'] = 1
    return resolved


def load_config(path: str | Path) -> Dict[str, Any]:
    """Load, default and validate one benchmark experiment YAML."""

    config_path = Path(path).expanduser().resolve()
    with open(config_path, "r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)
    if not isinstance(raw, Mapping):
        raise ValueError("Experiment YAML must contain a top-level mapping")

    experiment = _mapping(raw, "experiment")
    task = _mapping(raw, "task")
    model = _mapping(raw, "model")
    data = _mapping(raw, "data")
    training = _mapping(raw, "training")
    output = _mapping(raw, "output")
    debug = _mapping(raw, "debug")

    family = str(_required(task, "family", "task"))
    if family not in SUPPORTED_TASKS:
        supported = ", ".join(SUPPORTED_TASKS)
        raise ValueError(f"Unsupported task.family '{family}'; choose one of: {supported}")
    model_name = str(_required(model, "name", "model"))
    expected_models = {
        "structure2nmr": "equiformer_v3",
        "structure2hessian": "equiformer_v3",
        "structure2response": "equiformer_v3",
        "structure2property": "equiformer_v3",
        "structure2spectrum": "equiformer_v3",
        "structure2observables": "equiformer_v3",
        "spectrum2structure": "vib2mol",
        "spectrum2property": "vib2conf",
    }
    if model_name != expected_models[family]:
        raise ValueError(
            f"task {family} requires model.name={expected_models[family]}, got {model_name}"
        )
    if family == 'spectrum2structure' and model.get('stage', 'pipeline') not in ('matching', 'generation-train', 'pipeline'):
        raise ValueError('Vib2Mol YAML stage must be matching, generation-train or pipeline')

    targets = task.get("targets")
    if targets is None:
        if family == 'structure2nmr':
            targets = ['H', 'C']
        elif family == "structure2response":
            targets = ["dedipole", "depolar"]
        elif family == "structure2hessian":
            targets = ["Hi", "Hij"]
        elif family == "structure2property":
            targets = list(PROPERTY_TARGETS)
        elif family == "structure2spectrum":
            targets = list(SPECTRUM_TARGETS)
        elif family == "structure2observables":
            targets = [*PROPERTY_TARGETS, *SPECTRUM_TARGETS]
        elif family == "spectrum2structure":
            targets = ["kekule_smiles"]
        else:
            targets = list(PROPERTY_TARGETS)
    if not isinstance(targets, list) or not targets:
        raise ValueError("task.targets must be a non-empty list")
    targets = [str(target) for target in targets]
    allowed_targets = {
        "structure2nmr": {"H", "C"},
        "structure2hessian": {"Hi", "Hij"},
        "structure2response": {"dedipole", "depolar"},
        "structure2property": set(PROPERTY_TARGETS),
        "structure2spectrum": set(SPECTRUM_TARGETS),
        "structure2observables": set(PROPERTY_TARGETS + SPECTRUM_TARGETS),
        "spectrum2structure": {"kekule_smiles"},
        "spectrum2property": set(PROPERTY_TARGETS) | {"polar_iso", "polar_anisotropy"},
    }[family]
    unknown_targets = sorted(set(targets) - allowed_targets)
    if unknown_targets:
        raise ValueError(f"Unsupported targets for {family}: {', '.join(unknown_targets)}")

    modality = str(task.get("modality", "ir-raman" if family.startswith("spectrum2") else "3d"))
    allowed_modalities = (
        "ir", "raman", "ir-raman", "ir-raman-hnmr", "ir-raman-nmr"
    )
    if family.startswith("spectrum2") and modality not in allowed_modalities:
        raise ValueError(f"Unsupported spectrum task modality: {modality}")

    experiment.setdefault("name", f"{model_name}-{family}")
    experiment.setdefault("release", "demo")
    experiment.setdefault("seed", 624)
    data_root = str(_required(data, "root", "data"))
    if 'max_steps' in training:
        if family not in ('structure2hessian', 'structure2response', 'structure2nmr', 'spectrum2property', 'spectrum2structure'):
            raise ValueError('max_steps is unsupported for this task')
        if 'epochs' in training:
            raise ValueError('Specify max_steps or epochs, not both')
        training.setdefault('eval_every_steps', 2500)
        for key in ('max_steps', 'eval_every_steps'):
            if isinstance(training[key], bool) or not isinstance(training[key], int) or training[key] < 1:
                raise ValueError(f'training.{key} must be a positive integer')
    else:
        training.setdefault("epochs", 2)
    if family == 'spectrum2structure':
        if 'max_steps' in training:
            if 'generation_epochs' in training:
                raise ValueError('generation_epochs cannot be combined with max_steps')
            training.setdefault('generation_max_steps', training['max_steps'])
            value = training['generation_max_steps']
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError('generation_max_steps must be a positive integer')
        elif 'generation_max_steps' in training:
            raise ValueError('generation_max_steps requires max_steps')
    training.setdefault("batch_size", 16)
    if family == 'spectrum2property':
        architecture = model.get('architecture', 'shared_spectroscopy_transformer')
        if architecture != 'shared_spectroscopy_transformer':
            raise ValueError('spectrum2property requires shared_spectroscopy_transformer')
        parameters = model.get('parameters', {})
        if not isinstance(parameters, dict) or set(parameters) - {
                'd_model', 'nheads', 'nlayers', 'patch_size', 'fusion_channels',
                'encoder_layers', 'pooling_layers', 'pooling_queries',
                'hidden_channels', 'dropout'}:
            raise ValueError('Unsupported shared spectroscopy model.parameters')
        if data.get('nmr_normalization', 'median_iqr') != 'median_iqr':
            raise ValueError('NMR normalization is train-only median_iqr')
        training.setdefault('loss', 'smooth_l1')
        training.setdefault('loss_beta', 1.0)
        if training['loss'] != 'smooth_l1':
            raise ValueError('spectrum2property requires training.loss=smooth_l1')
        beta = float(training['loss_beta'])
        if not 0 < beta < float('inf'):
            raise ValueError('training.loss_beta must be finite and positive')
    training.setdefault("learning_rate", 3e-4)
    training.setdefault("weight_decay", 1e-4)
    training.setdefault("workers", 4)
    training.setdefault("device", "cuda:0")
    training.setdefault("gpus", 1)
    training.setdefault("progress", "auto")
    training.setdefault("progress_interval_seconds", 30.0)
    if training["progress"] not in ("auto", "tqdm", "log"):
        raise ValueError("training.progress must be auto, tqdm or log")
    if float(training["progress_interval_seconds"]) <= 0:
        raise ValueError("training.progress_interval_seconds must be positive")
    if int(training["gpus"]) < 1:
        raise ValueError("training.gpus must be at least 1")
    if family not in ("spectrum2structure", "structure2hessian", "structure2response", "structure2nmr") and int(training["gpus"]) != 1:
        raise ValueError(
            f"The current {model_name} adapter is single-GPU; set training.gpus to 1"
        )
    output.setdefault("root", "runs")
    debug.setdefault("enabled", False)
    debug.setdefault("train_samples", 512)
    debug.setdefault("eval_samples", 128)
    debug.setdefault("test_samples", 128)
    for key in ("train_samples", "eval_samples", "test_samples"):
        if int(debug[key]) < 1:
            raise ValueError(f"debug.{key} must be positive")

    resolved = {
        "schema_version": 1,
        "config_path": str(config_path),
        "experiment": experiment,
        "task": {**task, "family": family, "targets": targets, "modality": modality},
        "model": model,
        "data": {**data, "root": str(_repository_path(data_root))},
        "training": training,
        "output": {**output, "root": str(_repository_path(output["root"]))},
        "debug": debug,
    }
    return _apply_debug_overrides(resolved) if debug["enabled"] else resolved


def default_run_dir(config: Mapping[str, Any], run_id: Optional[str] = None) -> Path:
    """Build the canonical run directory for an experiment."""

    experiment = config["experiment"]
    task = config["task"]
    model = config["model"]
    identifier = run_id or config["output"].get("run_id")
    if not identifier:
        timestamp = time.strftime("%Y-%m-%d-%H-%M", time.localtime())
        identifier = f"{timestamp}-{uuid.uuid4().hex[:6]}"
    variant = experiment.get("variant") or "-".join(task["targets"])
    root = Path(config["output"]["root"])
    return (
        root
        / _slug(experiment["release"])
        / _slug(task["family"])
        / _slug(model["name"])
        / _slug(variant)
        / f"seed-{int(experiment['seed'])}"
        / _slug(identifier)
    )


def build_command(config: Mapping[str, Any], run_dir: Path) -> List[str]:
    """Translate the normalized experiment spec into an adapter command."""

    family = config["task"]["family"]
    targets = config["task"]["targets"]
    modality = config["task"]["modality"]
    model = config["model"]
    training = config["training"]
    data_root = Path(config["data"]["root"])
    artifacts = run_dir / "artifacts"

    if family in (
        "structure2property", "structure2spectrum", "structure2observables", "structure2hessian", "structure2response", "structure2nmr"
    ):
        command = [
            sys.executable, "-m", "benchmarks.models.equiformer_v3.train",
            "--task", family,
            "--targets", *targets,
            "--data-dir", str(data_root / "equiformer_v3"),
            "--output", str(artifacts),
            *( ["--max-steps", str(training['max_steps']), '--eval-every-steps', str(training['eval_every_steps'])]
               if 'max_steps' in training else ['--epochs', str(training['epochs'])] ),
            "--batch-size", str(training["batch_size"]),
            "--lr", str(training["learning_rate"]),
            "--weight-decay", str(training["weight_decay"]),
            "--seed", str(config["experiment"]["seed"]),
            "--device", str(training["device"]),
            "--workers", str(training["workers"]),
            "--progress", str(training["progress"]),
            "--progress-interval-seconds",
            str(training["progress_interval_seconds"]),
        ]
        parameters = model.get("parameters", {})
        if parameters:
            command.extend(["--backbone-override", json.dumps(parameters, sort_keys=True)])
        if config["debug"]["enabled"]:
            command.extend([
                "--debug",
                "--debug-train-samples", str(config["debug"]["train_samples"]),
                "--debug-eval-samples", str(config["debug"]["eval_samples"]),
                "--debug-test-samples", str(config["debug"]["test_samples"]),
            ])
        if int(training["gpus"]) > 1:
            command = [sys.executable, "-m", "torch.distributed.run", "--standalone",
                       "--nnodes=1", f"--nproc_per_node={training['gpus']}",
                       "--module", *command[2:]]
        return command

    if family == "spectrum2structure":
        stage = str(model.get("stage", "pipeline"))
        command = [
            sys.executable, "-m", "benchmarks.models.vib2mol.workflow", stage,
            "--output", str(artifacts / 'vib2mol'),
            "--data-dir", str(data_root),
            "--modality", modality,
            *( ['--max-steps', str(training['max_steps']),
                '--eval-every-steps', str(training['eval_every_steps'])]
               if 'max_steps' in training else ['--epochs', str(training['epochs'])] ),
            "--batch-size", str(training["batch_size"]),
            "--lr", str(training["learning_rate"]),
            "--seed", str(config["experiment"]["seed"]),
            "--device", str(training["device"]),
            "--gpus", str(training["gpus"]),
        ]
        if stage == "pipeline":
            command.extend([
                *( ['--generation-max-steps', str(training['generation_max_steps'])]
                   if 'max_steps' in training else
                   ['--generation-epochs', str(training.get('generation_epochs', training['epochs']))] ),
                "--generation-batch-size",
                str(training.get("generation_batch_size", training["batch_size"])),
                "--generation-lr",
                str(training.get("generation_learning_rate", training["learning_rate"])),
            ])
        if model.get("use_formula"):
            command.append("--use-formula")
        if model.get("smiles_augment"):
            command.append("--smiles-augment")
        if model.get("spectra_augment"):
            command.append("--spectra-augment")
        if model.get("frozen_encoder"):
            command.append("--frozen-encoder")
        if stage == 'generation-train':
            checkpoint = model.get('base_checkpoint')
            if not checkpoint:
                raise ValueError('generation-train requires model.base_checkpoint')
            command.extend(['--base-checkpoint', str(_repository_path(str(checkpoint)))])
        if config['debug']['enabled']:
            command.extend(['--debug', '--debug-train-samples', str(config['debug']['train_samples']),
                            '--debug-eval-samples', str(config['debug']['eval_samples']),
                            '--debug-test-samples', str(config['debug']['test_samples'])])
        return command

    if family == "spectrum2property":
        command = [
            sys.executable, "-m", "benchmarks.models.vib2conf.props_head",
            "--model-config", json.dumps(model.get('parameters', {})),
            "--loss-beta", str(training['loss_beta']),
            "--modality", modality,
            "--targets", *targets,
            "--data-dir", str(data_root / "vib2conf"),
            "--output", str(artifacts),
            *( ["--max-steps", str(training['max_steps']), '--eval-every-steps', str(training['eval_every_steps'])]
               if 'max_steps' in training else ['--epochs', str(training['epochs'])] ),
            "--batch-size", str(training["batch_size"]),
            "--lr", str(training["learning_rate"]),
            "--weight-decay", str(training["weight_decay"]),
            "--seed", str(config["experiment"]["seed"]),
            "--device", str(training["device"]),
            "--workers", str(training["workers"]),
            "--progress", str(training["progress"]),
            "--progress-interval-seconds",
            str(training["progress_interval_seconds"]),
        ]
        if config["debug"]["enabled"]:
            command.extend([
                "--debug",
                "--debug-train-samples", str(config["debug"]["train_samples"]),
                "--debug-eval-samples", str(config["debug"]["eval_samples"]),
                "--debug-test-samples", str(config["debug"]["test_samples"]),
            ])
        return command
    raise AssertionError(f"No command builder for {family}")


def _environment_metadata() -> Dict[str, Any]:
    packages: Dict[str, Optional[str]] = {}
    for name in ("torch", "torch-geometric", "numpy", "lmdb", "rdkit", "PyYAML"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    git = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=REPOSITORY_ROOT,
        check=False, capture_output=True, text=True,
    )
    return {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "hostname": platform.node(),
        "platform": platform.platform(),
        "python": sys.version,
        "executable": sys.executable,
        "packages": packages,
        "git_commit": git.stdout.strip() if git.returncode == 0 else None,
    }


def _write_json(path: Path, value: Any) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, default=str)


def _use_pty_progress(progress: str, terminal_is_tty: Optional[bool] = None) -> bool:
    """Use a pseudo-terminal when an interactive tqdm display is requested."""

    if terminal_is_tty is None:
        terminal_is_tty = sys.stdout.isatty()
    return progress == "tqdm" or (progress == "auto" and terminal_is_tty)


def _set_pty_window_size(file_descriptor: int) -> os.terminal_size:
    """Give a new PTY the parent terminal dimensions used by dynamic tqdm."""

    size = shutil.get_terminal_size(fallback=(120, 40))
    columns = max(int(size.columns), 1)
    lines = max(int(size.lines), 1)
    packed = struct.pack("HHHH", lines, columns, 0, 0)
    fcntl.ioctl(file_descriptor, termios.TIOCSWINSZ, packed)
    return os.terminal_size((columns, lines))


def _run_with_pty(
    command: List[str],
    environment: Mapping[str, str],
    log_path: Path,
) -> tuple[subprocess.Popen[bytes], int]:
    """Run a child on a PTY while mirroring its output to screen and log.

    Giving the child a real terminal is what lets tqdm update one line in
    place. This behaves like launching the trainer directly, while retaining
    the experiment runner's reproducibility metadata and train log.
    """

    master_fd, slave_fd = pty.openpty()
    process: Optional[subprocess.Popen[bytes]] = None
    try:
        terminal_size = _set_pty_window_size(slave_fd)
        child_environment = dict(environment)
        child_environment["COLUMNS"] = str(terminal_size.columns)
        child_environment["LINES"] = str(terminal_size.lines)
        process = subprocess.Popen(
            command,
            cwd=REPOSITORY_ROOT,
            env=child_environment,
            stdout=slave_fd,
            stderr=slave_fd,
            close_fds=True,
        )
        os.close(slave_fd)
        slave_fd = -1
        terminal = getattr(sys.stdout, "buffer", sys.stdout)
        with open(log_path, "wb") as log:
            while True:
                try:
                    chunk = os.read(master_fd, 8192)
                except OSError as error:
                    if error.errno == errno.EIO:
                        break
                    raise
                if not chunk:
                    break
                if hasattr(terminal, "write"):
                    if terminal is sys.stdout:
                        terminal.write(chunk.decode(errors="replace"))
                    else:
                        terminal.write(chunk)
                    terminal.flush()
                log.write(chunk)
                log.flush()
        return process, process.wait()
    except BaseException:
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        raise
    finally:
        if slave_fd >= 0:
            os.close(slave_fd)
        os.close(master_fd)


def _execute_experiment(
    config_path: str | Path,
    config: Mapping[str, Any],
    run_dir: Path,
    *,
    dry_run: bool,
    persist_artifacts: bool,
) -> Dict[str, Any]:
    """Execute a resolved experiment in a persistent or temporary directory."""

    command = build_command(config, run_dir)
    summary: Dict[str, Any] = {
        "config": str(Path(config_path).expanduser().resolve()),
        "run_dir": str(run_dir) if persist_artifacts else None,
        "command": command,
        "shell_command": shlex.join(command),
        "dry_run": dry_run,
        "debug": bool(config["debug"]["enabled"]),
        "artifacts_persisted": persist_artifacts,
    }
    if dry_run:
        return summary
    if run_dir.exists() and any(run_dir.iterdir()):
        raise FileExistsError(
            f"Run directory is not empty: {run_dir}. Choose a new --run-id."
        )
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "artifacts").mkdir(exist_ok=True)
    with open(run_dir / "resolved_config.yaml", "w", encoding="utf-8") as handle:
        yaml.safe_dump(config, handle, sort_keys=False, allow_unicode=True)
    _write_json(run_dir / "command.json", command)
    _write_json(run_dir / "environment.json", _environment_metadata())

    started = time.time()
    status: MutableMapping[str, Any] = {
        "state": "running",
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    _write_json(run_dir / "status.json", status)
    environment = os.environ.copy()
    environment["PYTHONUNBUFFERED"] = "1"
    process: Optional[subprocess.Popen[Any]] = None
    try:
        log_path = run_dir / "train.log"
        if _use_pty_progress(str(config["training"]["progress"])):
            process, return_code = _run_with_pty(command, environment, log_path)
        else:
            with open(log_path, "w", encoding="utf-8") as log:
                process = subprocess.Popen(
                    command, cwd=REPOSITORY_ROOT, env=environment,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, bufsize=1,
                )
                assert process.stdout is not None
                for line in process.stdout:
                    print(line, end="", flush=True)
                    log.write(line)
                    log.flush()
                return_code = process.wait()
        if return_code != 0:
            raise subprocess.CalledProcessError(return_code, command)
    except BaseException as error:
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        status.update({
            "state": "failed",
            "finished_at": datetime.now(timezone.utc).isoformat(),
            "elapsed_seconds": time.time() - started,
            "error": f"{type(error).__name__}: {error}",
        })
        _write_json(run_dir / "status.json", status)
        raise
    status.update({
        "state": "completed",
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.time() - started,
        "return_code": 0,
    })
    _write_json(run_dir / "status.json", status)
    summary["status"] = dict(status)
    return summary


def run_experiment(
    config_path: str | Path,
    *,
    dry_run: bool = False,
    run_id: Optional[str] = None,
    debug: bool = False,
) -> Dict[str, Any]:
    """Resolve and optionally execute one YAML experiment.

    Debug runs are intentionally ephemeral. They may write checkpoints and
    logs while the child process is running, but the enclosing temporary
    directory is removed before this function returns or propagates an error.
    """

    config = load_config(config_path)
    if debug and not config["debug"]["enabled"]:
        config = _apply_debug_overrides(config)

    if config["debug"]["enabled"]:
        identifier = _slug(run_id or "smoke")
        with tempfile.TemporaryDirectory(
            prefix=f"openmolspec-debug-{identifier}-"
        ) as directory:
            return _execute_experiment(
                config_path,
                config,
                Path(directory),
                dry_run=dry_run,
                persist_artifacts=False,
            )

    return _execute_experiment(
        config_path,
        config,
        default_run_dir(config, run_id=run_id),
        dry_run=dry_run,
        persist_artifacts=True,
    )
