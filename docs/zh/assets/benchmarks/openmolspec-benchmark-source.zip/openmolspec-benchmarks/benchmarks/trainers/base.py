"""Shared epoch/checkpoint lifecycle inspired by Harmony's trainers."""

from __future__ import annotations

import pickle
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn

from benchmarks.engines.base import BaseEngine
from benchmarks.engines.normalization import TargetNormalizer


def load_checkpoint(path: Path, device: str) -> Dict[str, object]:
    """Load current checkpoints and legacy NumPy-scalar demo checkpoints."""

    try:
        return torch.load(path, map_location=device, weights_only=True)
    except pickle.UnpicklingError:
        safe_globals = [
            np.core.multiarray.scalar,
            np.dtype,
            type(np.dtype(np.float64)),
        ]
        with torch.serialization.safe_globals(safe_globals):
            return torch.load(path, map_location=device, weights_only=True)


@dataclass(frozen=True)
class TrainingOutcome:
    """Validation and test results produced by a trainer lifecycle."""

    best_validation: Dict[str, float]
    test: Dict[str, float]


class BaseTrainer:
    """Own epochs, scheduling, model selection and checkpoint restoration."""

    def __init__(
        self,
        *,
        model: nn.Module,
        engine: BaseEngine,
        scheduler: Optional[torch.optim.lr_scheduler.LRScheduler],
        checkpoint_path: Path,
        epochs: int,
        device: str,
        debug: bool = False,
        evaluate_only: bool = False,
        max_steps: Optional[int] = None,
        eval_every_steps: int = 2500,
    ) -> None:
        self.model = model
        self.engine = engine
        self.scheduler = scheduler
        self.checkpoint_path = checkpoint_path
        self.epochs = epochs
        self.device = device
        self.debug = debug
        self.evaluate_only = evaluate_only
        if max_steps is not None and max_steps < 1 or eval_every_steps < 1:
            raise ValueError('Step budget and evaluation interval must be positive')
        self.max_steps = max_steps
        self.eval_every_steps = eval_every_steps
        self.global_step = 0
        self.best_step = 0

    @staticmethod
    def validation_score(metrics: Dict[str, float]) -> float:
        """Select the best checkpoint by summed finite target MAE."""

        values = [
            value
            for name, value in metrics.items()
            if name.startswith("MAE_") and np.isfinite(value)
        ]
        return float(sum(values)) if values else float("inf")

    def _load_model_and_normalizer(self) -> TargetNormalizer:
        if not self.checkpoint_path.is_file():
            raise FileNotFoundError(
                f"Checkpoint does not exist: {self.checkpoint_path}"
            )
        checkpoint = load_checkpoint(self.checkpoint_path, self.device)
        self.model.load_state_dict(checkpoint["state_dict"])
        normalizer = TargetNormalizer.from_state_dict(checkpoint["normalizer"])
        self.engine.normalizer = normalizer
        return normalizer

    def _save_checkpoint(self) -> None:
        normalizer = self.engine.require_normalizer()
        torch.save(
            {
                "state_dict": self.model.state_dict(),
                "global_step": self.global_step,
                "best_step": self.best_step,
                "optimizer": (self.engine.optimizer.state_dict()
                              if self.engine.optimizer is not None else None),
                "scheduler": (self.scheduler.state_dict()
                              if self.scheduler is not None else None),
                "normalizer": normalizer.state_dict(),
                "model_metadata": getattr(self.model, "checkpoint_metadata", None),
            },
            self.checkpoint_path,
        )

    def _print_epoch(
        self,
        epoch: int,
        train_loss: float,
        metrics: Dict[str, float],
        elapsed_seconds: float,
    ) -> None:
        optimizer = self.engine.optimizer
        learning_rate = (
            optimizer.param_groups[0]["lr"] if optimizer is not None else 0.0
        )
        fields = [
            f"[{self.engine.name}] epoch {epoch}/{self.epochs}",
            f"train_loss={train_loss:.6g}",
        ]
        fields.extend(f"{name}={value:.6g}" for name, value in metrics.items())
        fields.extend([
            f"lr={learning_rate:.6g}",
            f"elapsed={elapsed_seconds:.1f}s",
        ])
        print(" | ".join(fields), flush=True)

    def run(self) -> TrainingOutcome:
        """Train or restore a model, then evaluate the held-out test split."""

        writer = None
        primary = (
            not torch.distributed.is_initialized()
            or torch.distributed.get_rank() == 0
        )
        if primary and not self.debug and not self.evaluate_only:
            from torch.utils.tensorboard import SummaryWriter

            writer = SummaryWriter(
                log_dir=str(self.checkpoint_path.parent / "tensorboard")
            )
        try:
            return self._run(writer)
        finally:
            if writer is not None:
                writer.close()

    def _run(self, writer=None) -> TrainingOutcome:

        if self.max_steps is not None:
            from benchmarks.trainers.steps import run_steps
            return run_steps(self, writer)

        best_validation: Dict[str, float] = {}
        best_score = float("inf")
        best_epoch = 0
        best_state_dict: Optional[Dict[str, torch.Tensor]] = None

        if self.evaluate_only:
            self._load_model_and_normalizer()
            best_validation = self.engine.evaluate_validation()
        else:
            for epoch in range(1, self.epochs + 1):
                epoch_started = time.monotonic()
                learning_rates = (
                    [group["lr"] for group in self.engine.optimizer.param_groups]
                    if self.engine.optimizer is not None else []
                )
                train_stats = self.engine.train_epoch(epoch, self.epochs)
                if self.scheduler is not None:
                    self.scheduler.step()
                validation = self.engine.evaluate_validation(
                    description=f"Epoch{epoch:4d} [Valid]"
                )
                score = self.validation_score(validation)
                elapsed = time.monotonic() - epoch_started
                if writer is not None:
                    writer.add_scalar("train/loss", train_stats.loss, epoch)
                    writer.add_scalar("time/epoch_seconds", elapsed, epoch)
                    for index, rate in enumerate(learning_rates):
                        writer.add_scalar(f"train/learning_rate_group_{index}", rate, epoch)
                    for name, value in validation.items():
                        writer.add_scalar(f"validation/{name}", value, epoch)
                    writer.flush()
                self._print_epoch(
                    epoch,
                    train_stats.loss,
                    validation,
                    time.monotonic() - epoch_started,
                )
                if score < best_score:
                    best_score = score
                    best_epoch = epoch
                    best_validation = validation
                    if self.debug:
                        best_state_dict = {
                            name: value.detach().cpu().clone()
                            for name, value in self.model.state_dict().items()
                        }
                    else:
                        self._save_checkpoint()

            if self.debug:
                if best_state_dict is None:
                    raise RuntimeError(
                        "Debug training produced no finite validation score"
                    )
                self.model.load_state_dict(best_state_dict)
            else:
                self._load_model_and_normalizer()

        test_metrics = self.engine.evaluate_test()
        self._write_test_scalars(writer, test_metrics, best_epoch)
        return TrainingOutcome(
            best_validation=best_validation,
            test=test_metrics,
        )

    @staticmethod
    def _write_test_scalars(writer, metrics, step):
        if writer is None:
            return
        for name, value in metrics.items():
            writer.add_scalar(f'test/{name}', value, step)
        writer.flush()
