"""Vib2Conf spectrum-to-property trainer assembly."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional, Sequence

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, Subset

from benchmarks.engines import metrics as metrics_module
from benchmarks.engines.base import resolve_progress_mode
from benchmarks.engines.normalization import fit_or_load_normalizer
from benchmarks.engines.nmr_normalization import fit_or_load_nmr_normalizer
from benchmarks.engines.vib2conf import Vib2ConfPropertyEngine, property_tensor
from benchmarks.models.vib2conf.dataset import (
    PROPERTY_FIELDS,
    LmdbPropsDataset,
    collate_properties,
)
from benchmarks.models.vib2conf.factory import build_spectrum_property_model
from benchmarks.trainers.base import BaseTrainer
from benchmarks.data.scalar_properties import PROPERTY_UNITS


def _debug_subset(dataset: Dataset, samples: int) -> Dataset:
    return Subset(dataset, range(min(samples, len(dataset))))


class Vib2ConfPropertyTrainer:
    """Build and run the Vib2Conf scalar-property benchmark."""

    def __init__(
        self,
        *,
        data_dir: str,
        output: str,
        epochs: int,
        batch_size: int,
        learning_rate: float,
        weight_decay: float,
        seed: int,
        device: str,
        workers: int,
        concat_spectrum: bool,
        loss_beta: float = 1.0,
        modality: str = "ir-raman",
        max_steps: Optional[int] = None,
        eval_every_steps: int = 2500,
        targets: Optional[Sequence[str]] = None,
        progress: str = "auto",
        progress_interval_seconds: float = 30.0,
        debug: bool = False,
        debug_train_samples: int = 512,
        debug_eval_samples: int = 128,
        debug_test_samples: int = 128,
        model_parameters: Optional[Dict[str, object]] = None,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.output = Path(output)
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.seed = seed
        self.device = device
        self.workers = workers
        self.concat_spectrum = concat_spectrum
        self.loss_beta = loss_beta
        self.modality = modality
        self.max_steps = max_steps
        self.eval_every_steps = eval_every_steps
        self.targets = tuple(targets or PROPERTY_FIELDS)
        self.progress_mode = resolve_progress_mode(progress)
        self.progress_interval_seconds = progress_interval_seconds
        self.debug = debug
        self.debug_train_samples = debug_train_samples
        self.debug_eval_samples = debug_eval_samples
        self.debug_test_samples = debug_test_samples
        self.model_parameters = dict(model_parameters or {})

    def _validate(self) -> None:
        unknown = sorted(set(self.targets) - set(PROPERTY_FIELDS))
        if unknown:
            raise ValueError(f"Unknown property targets: {', '.join(unknown)}")
        debug_sizes = (
            self.debug_train_samples,
            self.debug_eval_samples,
            self.debug_test_samples,
        )
        if self.debug and any(samples < 1 for samples in debug_sizes):
            raise ValueError("Debug sample limits must be positive")

    def run(self) -> Dict[str, object]:
        self._validate()
        torch.manual_seed(self.seed)
        np.random.seed(self.seed)
        epochs = 1 if self.debug else self.epochs
        workers = 0 if self.debug else self.workers

        include_nmr = self.modality == "ir-raman-nmr"
        nmr_normalizer = None
        if include_nmr:
            nmr_normalizer = fit_or_load_nmr_normalizer(
                self.data_dir / "train.lmdb", cache_enabled=not self.debug,
                max_records=self.debug_train_samples if self.debug else None,
                progress=self.progress_mode)
        dataset_options = dict(include_nmr=include_nmr,
            reference_id=nmr_normalizer['reference_id'] if nmr_normalizer else None)
        train_source = LmdbPropsDataset(self.data_dir / "train.lmdb", self.targets, **dataset_options)
        eval_source = LmdbPropsDataset(self.data_dir / "eval.lmdb", self.targets, **dataset_options)
        test_source = LmdbPropsDataset(self.data_dir / "test.lmdb", self.targets, **dataset_options)
        train_dataset = (
            _debug_subset(train_source, self.debug_train_samples)
            if self.debug
            else train_source
        )
        eval_dataset = (
            _debug_subset(eval_source, self.debug_eval_samples)
            if self.debug
            else eval_source
        )
        test_dataset = (
            _debug_subset(test_source, self.debug_test_samples)
            if self.debug
            else test_source
        )
        if self.debug:
            print(
                "[Vib2Conf] DEBUG mode | "
                f"train={len(train_dataset):,} | eval={len(eval_dataset):,} | "
                f"test={len(test_dataset):,} | epochs=1 | workers=0 | "
                "checkpoint=disabled",
                flush=True,
            )

        train_loader = DataLoader(
            train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=workers,
            multiprocessing_context="spawn" if workers else None,
            collate_fn=collate_properties,
            drop_last=len(train_dataset) >= self.batch_size,
        )
        eval_loader = DataLoader(
            eval_dataset,
            batch_size=self.batch_size,
            num_workers=workers,
            multiprocessing_context="spawn" if workers else None,
            collate_fn=collate_properties,
        )
        test_loader = DataLoader(
            test_dataset,
            batch_size=self.batch_size,
            num_workers=workers,
            multiprocessing_context="spawn" if workers else None,
            collate_fn=collate_properties,
        )

        model = build_spectrum_property_model(
            self.modality,
            property_targets=self.targets,
            concat_spectrum=self.concat_spectrum,
            nmr_statistics=nmr_normalizer['statistics'] if nmr_normalizer else None,
            **self.model_parameters,
        ).to(self.device)
        model.checkpoint_metadata = {
            "architecture": "shared_spectroscopy_pooling_v2",
            "parameters": model.model_parameters,
            "modality": self.modality, "targets": list(self.targets),
            "nmr_normalization": nmr_normalizer,
        }
        # Include the final partial batch; normalization must not depend on
        # shuffled/drop-last training batches or the optimizer batch size.
        normalizer_loader = DataLoader(
            train_dataset, batch_size=self.batch_size, shuffle=False,
            num_workers=workers, multiprocessing_context="spawn" if workers else None,
            collate_fn=collate_properties,
        )
        normalizer = fit_or_load_normalizer(
            normalizer_loader,
            self.targets,
            property_tensor,
            source_path=self.data_dir / "train.lmdb",
            progress_mode=self.progress_mode,
            cache_enabled=not self.debug,
            cache_tag="spectral-properties-full-train-zscore-v1",
        )
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=self.learning_rate,
            weight_decay=self.weight_decay,
        )
        max_steps = self.max_steps
        if max_steps is not None and self.debug:
            max_steps = min(max_steps, len(train_loader))
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=max_steps or epochs
        )
        engine = Vib2ConfPropertyEngine(
            model=model,
            train_loader=train_loader,
            eval_loader=eval_loader,
            test_loader=test_loader,
            normalizer=normalizer,
            optimizer=optimizer,
            device=self.device,
            progress_mode=self.progress_mode,
            progress_interval_seconds=self.progress_interval_seconds,
            targets=self.targets,
            loss_beta=self.loss_beta,
        )
        self.output.mkdir(parents=True, exist_ok=True)
        lifecycle = BaseTrainer(
            model=model,
            engine=engine,
            scheduler=scheduler,
            checkpoint_path=(
                self.output / "vib2conf_spectrum2property_best.pt"
            ),
            epochs=epochs,
            device=self.device,
            debug=self.debug,
            max_steps=max_steps,
            eval_every_steps=self.eval_every_steps,
        )
        outcome = lifecycle.run()
        summary = {
            "task": "spectrum2property",
            "targets": list(self.targets),
            "target_units": {name: PROPERTY_UNITS.get(name, "Hartree") for name in self.targets},
            "loss": {"name": "smooth_l1", "beta": self.loss_beta, "space": "zscore"},
            "target_normalization": normalizer.state_dict(),
            "model": "Modality-specific embeddings + shared spectroscopy Transformer",
            "model_parameters": model.model_parameters,
            "nmr_normalization": nmr_normalizer,
            "concat_spectrum": self.concat_spectrum,
            "modality": self.modality,
            "max_steps": max_steps,
            "global_step": lifecycle.global_step,
            "best_step": lifecycle.best_step,
            "device": self.device,
            "epochs": epochs,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "weight_decay": self.weight_decay,
            "seed": self.seed,
            "progress": self.progress_mode,
            "progress_interval_seconds": self.progress_interval_seconds,
            "debug": self.debug,
            "train_records": len(train_dataset),
            "val_records": len(eval_dataset),
            "test_records": len(test_dataset),
            "parameters": sum(p.numel() for p in model.parameters()),
            "best_validation": outcome.best_validation,
            "best_test": outcome.test,
        }
        metrics_module.save_results(
            self.output / "results_spectrum2property_vib2conf", [summary]
        )
        return summary


def run(**kwargs) -> Dict[str, object]:
    return Vib2ConfPropertyTrainer(**kwargs).run()
