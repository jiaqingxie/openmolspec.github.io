"""Assemble direct Hessian training with the shared benchmark lifecycle."""

import json
import os
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset
from torch.utils.data.distributed import DistributedSampler
from torch.nn.parallel import DistributedDataParallel

from benchmarks.engines.base import resolve_progress_mode
from benchmarks.engines.hessian import HessianEngine
from benchmarks.engines.normalization import TargetNormalizer
from benchmarks.models.equiformer_v3.dataset import OpenSpecLmdbDataset
from benchmarks.models.equiformer_v3.hessian import DirectHessianModel
from benchmarks.trainers.base import BaseTrainer, load_checkpoint


class HessianTrainer(BaseTrainer):
    """Write a single portable checkpoint; all ranks restore after the writer."""

    def _save_checkpoint(self):
        if not torch.distributed.is_initialized() or torch.distributed.get_rank() == 0:
            super()._save_checkpoint()

    def _load_model_and_normalizer(self):
        if torch.distributed.is_initialized():
            torch.distributed.barrier()
        return super()._load_model_and_normalizer()

    def _print_epoch(self, *args, **kwargs):
        if not torch.distributed.is_initialized() or torch.distributed.get_rank() == 0:
            super()._print_epoch(*args, **kwargs)


class NMRShiftTrainer(HessianTrainer):
    def _load_model_and_normalizer(self):
        if torch.distributed.is_initialized():
            torch.distributed.barrier()
        checkpoint = load_checkpoint(self.checkpoint_path, self.device)
        if checkpoint.get('model_metadata') != self.model.checkpoint_metadata:
            raise ValueError('NMR checkpoint task/backbone/reference/split mismatch')
        self.model.load_state_dict(checkpoint['state_dict'])
        normalizer = TargetNormalizer.from_state_dict(checkpoint['normalizer'])
        if normalizer.state_dict() != self.engine.normalizer.state_dict():
            raise ValueError('NMR checkpoint training normalization mismatch')
        self.engine.normalizer = normalizer
        return normalizer

    def validation_score(self, metrics):
        values = [metrics[f'MAE_{t}'] / self.engine.normalizer.std[t]
                  for t in self.engine.targets if np.isfinite(metrics[f'MAE_{t}'])]
        return float(np.mean(values)) if values else float('inf')


def run(**args):
    distributed = int(os.environ.get("WORLD_SIZE", "1")) > 1
    if distributed:
        if str(args["device"]).startswith("cuda"):
            local_rank = int(os.environ["LOCAL_RANK"])
            torch.cuda.set_device(local_rank)
            args["device"] = f"cuda:{local_rank}"
            backend = "nccl"
        else:
            backend = "gloo"
        torch.distributed.init_process_group(backend=backend)
    try:
        return _run(**args)
    finally:
        if distributed and torch.distributed.is_initialized():
            torch.distributed.destroy_process_group()


def _run(**args):
    distributed = torch.distributed.is_initialized()
    rank = torch.distributed.get_rank() if distributed else 0
    world = torch.distributed.get_world_size() if distributed else 1
    seed = args["seed"]
    torch.manual_seed(seed)
    np.random.seed(seed)
    debug = args.get("debug", False)
    if debug and args.get("evaluate_only"):
        raise ValueError("debug and evaluate-only cannot be combined")
    task = args.get("task", "structure2hessian")
    response = task == "structure2response"
    nmr = task == 'structure2nmr'
    allowed = {'H', 'C'} if nmr else ({"dedipole", "depolar"} if response else {"Hi", "Hij"})
    targets = args.get("targets") or sorted(allowed)
    if not targets or set(targets) - allowed:
        raise ValueError(f"Invalid targets for {task}: {targets}")
    root = Path(args["data_dir"])
    summary_path = root.parent / "summary.json"
    metadata = json.loads(summary_path.read_text())
    if nmr:
        if metadata.get('state') != 'completed' or metadata.get('excluded') != 0:
            raise ValueError('NMR requires a completed, zero-exclusion dataset')
        normalizer_stats = metadata['train_target_statistics']
        for t in targets:
            st = normalizer_stats[t.lower()]
            if st['count'] <= 0 or not np.isfinite(st['mean_ppm']) or not np.isfinite(st['std_ppm']) or st['std_ppm'] <= 0:
                raise ValueError(f'Invalid training normalization for {t}')
    elif response:
        if metadata.get("response_units") != {"dedipole": "Debye/Angstrom", "depolar": "Bohr^3/Angstrom"}:
            raise ValueError("Re-export data with benchmarks.data.prepare_response")
    elif metadata.get("hessian_unit") != "eV/Angstrom^2":
        raise ValueError("Re-export data with benchmarks.data.prepare_hessian")
    loaders, counts = {}, {}
    for mode in ("train", "eval", "test"):
        source = OpenSpecLmdbDataset(root / f"{mode}.lmdb")
        dataset = source
        if debug:
            key = f"debug_{mode}_samples"
            limit = args.get(key, 128 if mode != "train" else 512)
            dataset = Subset(source, range(min(limit, len(source))))
        if not len(dataset):
            raise ValueError(f"Empty {mode} dataset")
        for target in (['nmr_shift', 'nmr_h_mask', 'nmr_c_mask'] if nmr else targets):
            if target not in dataset[0]:
                raise ValueError(f"{mode} LMDB missing {target}; re-export {task} data")
        if nmr:
            if len(source) != metadata['counts'][mode]:
                raise ValueError(f'NMR {mode} count differs from summary')
            sample = dataset[0]
            if sample.nmr_shift_unit != 'ppm' or sample.nmr_reference_id != metadata['reference']['id']:
                raise ValueError('NMR unit/reference mismatch')
        counts[mode] = len(dataset)
        sampler = None
        if distributed:
            if mode == "train":
                if len(dataset) < world:
                    raise ValueError("Training requires at least one sample per rank")
                # Drop at most world-1 records per epoch, shuffled anew each epoch.
                sampler = DistributedSampler(dataset, shuffle=True, seed=seed, drop_last=True)
            else:
                # No padding: each validation/test record is counted exactly once.
                sampler = range(rank, len(dataset), world)
        loaders[mode] = DataLoader(
            dataset, batch_size=args["batch_size"], shuffle=mode == "train" and sampler is None,
            sampler=sampler,
            drop_last=mode == 'train' and args.get('max_steps') is not None and not debug,
            num_workers=0 if debug else args["workers"], collate_fn=source.collate,
            multiprocessing_context=("spawn" if not debug and args["workers"] > 0 else None),
            persistent_workers=not debug and args["workers"] > 0,
            pin_memory=str(args["device"]).startswith("cuda"),
        )
    overrides = json.loads(args["backbone_override"]) if args.get("backbone_override") else {}
    overrides.setdefault("max_radius", metadata["cutoff_angstrom"])
    if overrides["max_radius"] != metadata["cutoff_angstrom"]:
        raise ValueError("Model radius must match prepared graph cutoff")
    if nmr:
        from benchmarks.models.equiformer_v3.nmr import AtomNMRModel
        model = AtomNMRModel(targets, overrides).to(args['device'])
        model.checkpoint_metadata = dict(task=task, targets=targets, backbone=overrides,
                                        reference=metadata['reference'], unit='ppm',
                                        split_sha256=metadata['split_sha256'])
    else:
        model = DirectHessianModel(targets, overrides).to(args["device"])
    training_model = model
    if distributed:
        training_model = DistributedDataParallel(
            model, device_ids=[int(os.environ["LOCAL_RANK"])] if str(args["device"]).startswith("cuda") else None,
            broadcast_buffers=False, find_unused_parameters=True,
        )
    optimizer = torch.optim.AdamW(model.parameters(), lr=args["learning_rate"],
                                  weight_decay=args["weight_decay"])
    epochs = 1 if debug else args["epochs"]
    max_steps = args.get('max_steps')
    if debug and max_steps is not None:
        max_steps = min(max_steps, len(loaders['train']))
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max_steps or epochs)
    # Tensor components must not be shifted by a scalar mean: this breaks rotations.
    normalizer = TargetNormalizer({t: 0. for t in targets}, {t: 1. for t in targets})
    engine_class = HessianEngine
    if nmr:
        from benchmarks.engines.nmr_shifts import NMRShiftEngine
        engine_class = NMRShiftEngine
        normalizer = TargetNormalizer(
            {t: float(normalizer_stats[t.lower()]['mean_ppm']) for t in targets},
            {t: float(normalizer_stats[t.lower()]['std_ppm']) for t in targets})
    engine = engine_class(
        model=training_model, targets=targets, train_loader=loaders["train"],
        eval_loader=loaders["eval"], test_loader=loaders["test"],
        normalizer=normalizer, optimizer=optimizer, device=args["device"],
        progress_mode=resolve_progress_mode(args.get("progress", "auto")),
        progress_interval_seconds=args.get("progress_interval_seconds", 30.),
    )
    if response:
        engine.name = "EquiformerV3 response-direct"
    output = Path(args["output"])
    output.mkdir(parents=True, exist_ok=True)
    if rank == 0:
        print(f"[{task} direct] targets={targets} | {counts} | world_size={world} | "
              f"batch_per_gpu={args['batch_size']} | global_batch={args['batch_size'] * world} | debug={debug}", flush=True)
    trainer_class = NMRShiftTrainer if nmr else HessianTrainer
    trainer = trainer_class(
        model=model, engine=engine, scheduler=scheduler,
        checkpoint_path=output / f"equiformer_v3_{task}_best.pt",
        epochs=epochs, device=args["device"], debug=debug,
        evaluate_only=args.get("evaluate_only", False),
        max_steps=max_steps, eval_every_steps=args.get('eval_every_steps', 2500),
    )
    outcome = trainer.run()
    result = {"task": task, "targets": targets, "counts": counts,
              "world_size": world, "batch_size_per_rank": args["batch_size"],
              "global_batch_size": args["batch_size"] * world,
              "unit": 'ppm' if nmr else (metadata["response_units"] if response else "eV/Angstrom^2"),
              "loss": 'per-nucleus zscore SmoothL1, mean over present nuclei' if nmr else "Cartesian SmoothL1",
              "best_validation": outcome.best_validation, "best_test": outcome.test}
    result.update({'max_steps': max_steps, 'global_step': trainer.global_step,
                   'best_step': trainer.best_step, 'scheduler_unit': 'step' if max_steps else 'epoch',
                   'eval_every_steps': trainer.eval_every_steps if max_steps else None})
    if nmr:
        result.update(normalizer=engine.normalizer.state_dict(),
                      selection_metric='mean(MAE_nucleus / train_std_nucleus)',
                      reference_id=metadata['reference']['id'])
    if not debug and rank == 0:
        (output / f"results_{task}.json").write_text(json.dumps(result, indent=2)+"\n")
    return result
