"""EquiformerV3 trainer assembly for OpenMolSpec observables."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, Subset

from benchmarks.engines import metrics as metrics_module
from benchmarks.engines.base import resolve_progress_mode
from benchmarks.engines.equiformer import EquiformerEngine, target_tensor
from benchmarks.engines.normalization import fit_or_load_normalizer
from benchmarks.models.equiformer_v3.dataset import OpenSpecLmdbDataset
from benchmarks.models.equiformer_v3.model import OpenSpecEquiformerV3
from benchmarks.trainers.base import BaseTrainer

PROPERTY_TARGETS = ("energy", "gap", "homo", "lumo", "dipole_total", "zpve")
SPECTRUM_TARGETS = ("ir_spectrum", "raman_spectrum")

MODE_TARGETS = {
    "structure2property": {"property": list(PROPERTY_TARGETS), "spectrum": []},
    "structure2spectrum": {"property": [], "spectrum": list(SPECTRUM_TARGETS)},
    "structure2observables": {
        "property": list(PROPERTY_TARGETS),
        "spectrum": list(SPECTRUM_TARGETS),
    },
}


def resolve_targets(
    task: str, targets: Optional[List[str]]
) -> Tuple[List[str], List[str]]:
    """Resolve requested heads into property and spectrum groups."""

    defaults = MODE_TARGETS[task]
    if not targets:
        return list(defaults["property"]), list(defaults["spectrum"])
    allowed = set(defaults["property"] + defaults["spectrum"])
    unknown = sorted(set(targets) - allowed)
    if unknown:
        raise ValueError(
            f"Targets are incompatible with {task}: {', '.join(unknown)}"
        )
    properties = [name for name in targets if name in PROPERTY_TARGETS]
    spectra = [name for name in targets if name in SPECTRUM_TARGETS]
    return properties, spectra


def _debug_subset(dataset: Dataset, samples: int) -> Dataset:
    return Subset(dataset, range(min(samples, len(dataset))))


class EquiformerTrainer:
    """Build and run an EquiformerV3 benchmark from CLI/YAML settings."""

    def __init__(
        self,
        *,
        task: str,
        data_dir: str,
        output: str,
        epochs: int,
        batch_size: int,
        learning_rate: float,
        weight_decay: float,
        seed: int,
        device: str,
        workers: int,
        backbone_override: Optional[str],
        evaluate_only: bool = False,
        targets: Optional[List[str]] = None,
        progress: str = "auto",
        progress_interval_seconds: float = 30.0,
        debug: bool = False,
        debug_train_samples: int = 512,
        debug_eval_samples: int = 128,
        debug_test_samples: int = 128,
    ) -> None:
        self.task = task
        self.data_dir = Path(data_dir)
        self.output = Path(output)
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.seed = seed
        self.device = device
        self.workers = workers
        self.backbone_override = backbone_override
        self.evaluate_only = evaluate_only
        self.requested_targets = targets
        self.progress_mode = resolve_progress_mode(progress)
        self.progress_interval_seconds = progress_interval_seconds
        self.debug = debug
        self.debug_train_samples = debug_train_samples
        self.debug_eval_samples = debug_eval_samples
        self.debug_test_samples = debug_test_samples

    def _validate(self) -> None:
        if self.debug and self.evaluate_only:
            raise ValueError("--debug and --evaluate-only cannot be used together")
        debug_sizes = (
            self.debug_train_samples,
            self.debug_eval_samples,
            self.debug_test_samples,
        )
        if self.debug and any(samples < 1 for samples in debug_sizes):
            raise ValueError("Debug sample limits must be positive")

    def run(self) -> Dict[str, object]:
        self._validate()
        torch.manual_seed(self.seed)
        np.random.seed(self.seed)
        property_targets, spectrum_targets = resolve_targets(
            self.task, self.requested_targets
        )
        targets = property_targets + spectrum_targets
        epochs = 1 if self.debug else self.epochs
        workers = 0 if self.debug else self.workers

        train_source = OpenSpecLmdbDataset(self.data_dir / "train.lmdb")
        eval_source = OpenSpecLmdbDataset(self.data_dir / "eval.lmdb")
        test_source = OpenSpecLmdbDataset(self.data_dir / "test.lmdb")
        train_dataset = (
            _debug_subset(train_source, self.debug_train_samples)
            if self.debug
            else train_source
        )
        eval_dataset = (
            _debug_subset(eval_source, self.debug_eval_samples)
            if self.debug
            else eval_source
        )
        test_dataset = (
            _debug_subset(test_source, self.debug_test_samples)
            if self.debug
            else test_source
        )
        if self.debug:
            print(
                "[EquiformerV3] DEBUG mode | "
                f"train={len(train_dataset):,} | eval={len(eval_dataset):,} | "
                f"test={len(test_dataset):,} | epochs=1 | workers=0 | "
                "checkpoint=disabled",
                flush=True,
            )

        train_loader = DataLoader(
            train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=workers,
            collate_fn=train_source.collate,
            drop_last=len(train_dataset) >= self.batch_size,
        )
        eval_loader = DataLoader(
            eval_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=workers,
            collate_fn=eval_source.collate,
        )
        test_loader = DataLoader(
            test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=workers,
            collate_fn=test_source.collate,
        )

        backbone = (
            json.loads(self.backbone_override)
            if self.backbone_override
            else None
        )
        model = OpenSpecEquiformerV3(
            property_targets=property_targets,
            spectrum_targets=spectrum_targets,
            backbone=backbone,
        ).to(self.device)
        normalizer = None
        if not self.evaluate_only:
            normalizer = fit_or_load_normalizer(
                train_loader,
                targets,
                target_tensor,
                source_path=self.data_dir / "train.lmdb",
                progress_mode=self.progress_mode,
                cache_enabled=not self.debug,
            )
        optimizer = None
        scheduler = None
        if not self.evaluate_only:
            optimizer = torch.optim.AdamW(
                model.parameters(),
                lr=self.learning_rate,
                weight_decay=self.weight_decay,
            )
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer, T_max=epochs
            )

        engine = EquiformerEngine(
            model=model,
            train_loader=train_loader,
            eval_loader=eval_loader,
            test_loader=test_loader,
            normalizer=normalizer,
            optimizer=optimizer,
            device=self.device,
            progress_mode=self.progress_mode,
            progress_interval_seconds=self.progress_interval_seconds,
            property_targets=property_targets,
            spectrum_targets=spectrum_targets,
        )
        self.output.mkdir(parents=True, exist_ok=True)
        lifecycle = BaseTrainer(
            model=model,
            engine=engine,
            scheduler=scheduler,
            checkpoint_path=(
                self.output / f"equiformer_v3_{self.task}_best.pt"
            ),
            epochs=epochs,
            device=self.device,
            debug=self.debug,
            evaluate_only=self.evaluate_only,
        )
        outcome = lifecycle.run()
        summary = {
            "task": self.task,
            "targets": targets,
            "model": "EquiformerV3",
            "device": self.device,
            "epochs": epochs,
            "batch_size": self.batch_size,
            "learning_rate": self.learning_rate,
            "weight_decay": self.weight_decay,
            "seed": self.seed,
            "evaluate_only": self.evaluate_only,
            "progress": self.progress_mode,
            "progress_interval_seconds": self.progress_interval_seconds,
            "debug": self.debug,
            "train_records": len(train_dataset),
            "val_records": len(eval_dataset),
            "test_records": len(test_dataset),
            "parameters": sum(p.numel() for p in model.parameters()),
            "best_validation": outcome.best_validation,
            "best_test": outcome.test,
        }
        metrics_module.save_results(
            self.output / f"results_{self.task}", [summary]
        )
        return summary


def run(**kwargs) -> Dict[str, object]:
    """Compatibility function used by the lightweight CLI module."""

    return EquiformerTrainer(**kwargs).run()
