"""Run the unified benchmark command line interface."""

from benchmarks.cli import main


if __name__ == "__main__":
    main()
