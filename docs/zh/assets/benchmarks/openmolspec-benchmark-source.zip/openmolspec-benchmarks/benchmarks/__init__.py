"""Benchmark infrastructure for the OpenMolSpec Scientific Data applications.

Task definitions
----------------

+---------------------+------------------------+------------------------+------------------+
| Task                | Input                  | Target                 | Model            |
+=====================+========================+========================+==================+
| structure->property | 3D structure           | quantum properties     | EquiformerV3     |
| structure->spectrum | 3D structure           | IR / Raman spectrum    | EquiformerV3     |
| structure->observ.  | 3D structure           | properties + spectra   | EquiformerV3     |
| spectrum->structure | IR / Raman spectrum    | kekule SMILES          | Vib2Mol          |
| spectrum->conformer | IR / Raman spectrum    | 3D conformer           | Vib2Conf         |
| spectrum->property  | IR / Raman spectrum    | quantum properties     | Vib2Conf (+head) |
+---------------------+------------------------+------------------------+------------------+

All tasks share one fixed molecule-level (InChIKey) split produced by
``benchmarks.data.prepare`` so the test set is identical across models.
"""

from .engines.metrics import (
    METRICS,
    mae,
    pearson_r,
    cosine_similarity,
    r2,
    rmse,
    save_results,
)

__all__ = [
    "METRICS",
    "mae",
    "pearson_r",
    "cosine_similarity",
    "r2",
    "rmse",
    "save_results",
]
