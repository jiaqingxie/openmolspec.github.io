"""Recoverably archive stopped spectrum2property runs and superseded data only.

Dry-run by default. --apply is only appropriate after stopping jobs on ALL hosts.
No files are unlinked, no scheduler jobs are cancelled, and raw releases stay put.
"""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def candidates(include_data=False):
    targets = sorted((ROOT / "runs").glob("*/spectrum2property"))
    for name in ("spectrum_properties_smoke", "spectrum_properties_units_smoke",
                 "spectrum_property_ranges_ks200k"):
        path = ROOT / "reports/benchmark" / name
        if path.exists():
            targets.append(path)
    if include_data:
        for size in (200, 1000):
            path = ROOT / f"benchmark_data/spectrum_properties_ks{size}k_hc_nmr_minmax/summary.json"
            if not path.is_file() or json.loads(path.read_text()).get("state") != "completed":
                raise ValueError("Both replacement datasets must be complete before retiring old data")
        for size in (200, 400, 600, 800, 1000):
            for suffix in ("", "_minmax"):
                path = ROOT / f"benchmark_data/spectrum_properties_ks{size}k{suffix}"
                if path.exists():
                    targets.append(path)
    for path in targets:
        if path.is_symlink() or not path.is_dir() or ROOT not in path.resolve().parents:
            raise ValueError(f"Unsafe archive target: {path}")
    return targets


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--include-data", action="store_true")
    args = parser.parse_args()
    targets = candidates(args.include_data)
    if not args.apply:
        print(json.dumps({"dry_run": True, "targets": [str(p.relative_to(ROOT)) for p in targets]}, indent=2))
        return
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        try:
            command = (proc / "cmdline").read_bytes()
        except OSError:
            continue
        if b"benchmarks.models.vib2conf.props_head" in command:
            raise RuntimeError(f"Local property trainer still running: PID {proc.name}")
    if not targets:
        print("Nothing to archive")
        return
    archive = ROOT / "artifacts" / ("retired-spectrum2property-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    archive.mkdir()
    records = [{"source": str(p.relative_to(ROOT)),
                "destination": str((archive / p.relative_to(ROOT)).relative_to(ROOT)), "moved": False}
               for p in targets]
    inventory = archive / "inventory.json"
    for row in records:
        inventory.write_text(json.dumps({"recoverable": True, "records": records}, indent=2) + "\n")
        destination = ROOT / row["destination"]
        destination.parent.mkdir(parents=True, exist_ok=True)
        (ROOT / row["source"]).rename(destination)
        row["moved"] = True
    inventory.write_text(json.dumps({"recoverable": True, "records": records}, indent=2) + "\n")
    print(json.dumps({"archive": str(archive), "moved_directories": len(records), "inventory": str(inventory)}, indent=2))


if __name__ == "__main__":
    main()
