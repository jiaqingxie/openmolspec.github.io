#!/usr/bin/env bash
# EquiformerV3 structure->property and structure->spectrum baselines.
# Run on the GPU cluster from the repository root.
set -euo pipefail

# structure -> quantum properties (energy, gap, homo, lumo, dipole_total, zpve)
python -m benchmarks.models.equiformer_v3.train \
    --task structure2property \
    --data-dir benchmark_data/equiformer_v3 \
    --output reports/benchmark \
    --epochs 50 \
    --batch-size 32 \
    --lr 3e-4 \
    --device cuda:0

# structure -> IR / Raman spectra (1024 points each)
python -m benchmarks.models.equiformer_v3.train \
    --task structure2spectrum \
    --data-dir benchmark_data/equiformer_v3 \
    --output reports/benchmark \
    --epochs 50 \
    --batch-size 32 \
    --lr 3e-4 \
    --device cuda:0
