#!/usr/bin/env bash
# Thin wrapper around the tracked Vib2Mol adapter. All arguments are forwarded.
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "${repo_root}"
exec python -m benchmarks.models.vib2mol.workflow "$@"
