#!/usr/bin/env bash
# Vib2Conf spectrum->conformer baseline.
# Run on the GPU cluster from the repository root.
#
# Prerequisites: the LMDBs produced by `python -m benchmarks.data.prepare`
# must be visible at benchmarks/models/vib2conf/upstream/datasets/openspec_vc/:
#
#   mkdir -p benchmarks/models/vib2conf/upstream/datasets
#   ln -sfn "$(pwd)/benchmark_data/vib2conf" benchmarks/models/vib2conf/upstream/datasets/openspec_vc
#
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
data_root="${1:-${repo_root}/benchmark_data}"
device="${2:-cuda:0}"
mkdir -p "${repo_root}/benchmarks/models/vib2conf/upstream/datasets"
ln -sfn "$(realpath "${data_root}/vib2conf")" \
    "${repo_root}/benchmarks/models/vib2conf/upstream/datasets/openspec_vc"

cd "${repo_root}/benchmarks/models/vib2conf/upstream"

# Single-modality Raman
python main.py -train \
    --launch base \
    --model vib2conf_equiformer_moe_balance0001 \
    --ds openspec_vc \
    --task raman \
    --device "${device}"

# Single-modality IR
python main.py -train \
    --launch base \
    --model vib2conf_equiformer_moe_balance0001 \
    --ds openspec_vc \
    --task ir \
    --device "${device}"

# Dual-modality IR+Raman (multi-GPU)
torchrun --nproc_per_node=4 main.py -train --ddp \
    --launch base \
    --model vib2conf_equiformer_moe_balance0001 \
    --ds openspec_vc \
    --task ir-raman

# Retrieval evaluation (Recall@1/3/5) on the test set
python eval.py \
    --ckpt checkpoints/openspec_vc/raman/vib2conf_equiformer_moe_balance0001/*/epoch*.pth \
    --ds openspec_vc --task raman \
    --device "${device}"
