#!/usr/bin/env bash
# Clone each upstream repository beside its OpenMolSpec model adapter.
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
install_repo() {
    local name="$1"
    local url="$2"
    local commit="$3"
    local target="${repo_root}/benchmarks/models/${name}/upstream"

    mkdir -p "$(dirname "${target}")"

    if [[ -e "${target}" && ! -e "${target}/.git" ]]; then
        echo "error: ${target} exists but has no git metadata; move it aside before setup" >&2
        return 2
    fi
    if [[ ! -e "${target}/.git" ]]; then
        git clone "${url}" "${target}"
    fi
    git -C "${target}" fetch origin "${commit}"
    git -C "${target}" checkout --detach "${commit}"
}

install_repo equiformer_v3 https://github.com/atomicarchitects/equiformer_v3.git a7300c58df683dc99cb48027d5bfd4c887486c48
install_repo vib2mol https://github.com/X1nyuLu/vib2mol.git 207a86eb3050012ab5ea20a7e237a5b075d8d057
install_repo vib2conf https://github.com/X1nyuLu/vib2conf.git 70388376639785c2007fc084f15c22f06c1b328a

python -m benchmarks check
