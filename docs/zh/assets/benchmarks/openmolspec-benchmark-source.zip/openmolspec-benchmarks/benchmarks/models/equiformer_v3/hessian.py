"""Direct node/edge Hessian heads following Harmony's Hi/Hij design."""

import torch
from e3nn.io import CartesianTensor

from .model import OpenSpecEquiformerV3
from .edge_head import HessianEdgeHead
from experimental.models.equiformer_v3.transformer_block import FeedForwardNetwork


class DirectHessianModel(OpenSpecEquiformerV3):
    def __init__(self, targets=("Hi", "Hij"), backbone=None):
        super().__init__(property_targets=(), spectrum_targets=(), backbone=backbone)
        self.targets = tuple(targets)
        b = self.backbone
        if b.lmax < 2:
            raise ValueError("Hessian heads require lmax >= 2")
        if set(targets) - {"Hi", "Hij", "dedipole", "depolar"}:
            raise ValueError("Unknown direct tensor target")
        if "depolar" in targets and b.lmax < 3:
            raise ValueError("Polarizability derivative requires lmax >= 3")
        self.heads = torch.nn.ModuleDict()
        for target in ("Hi", "dedipole", "depolar"):
            if target not in targets:
                continue
            self.heads[target] = FeedForwardNetwork(
                b.num_channels, b.attn_hidden_channels, 2 if target == "depolar" else 1,
                lmax=b.lmax, mmax=b.mmax,
                grid_resolution_list=b.ffn_grid_resolution_list,
                activation=b.ffn_activation, use_grid_mlp=b.use_grid_mlp,
                dropout=b.ffn_drop,
            )
        if "Hij" in targets:
            self.heads["Hij"] = HessianEdgeHead(
                num_in_channels=b.num_channels,
                num_hidden_channels=b.attn_hidden_channels,
                num_heads=b.num_heads, attn_alpha_channels=b.attn_alpha_channels,
                attn_value_channels=b.attn_value_channels, num_out_channels=1,
                lmax=b.lmax, mmax=b.mmax, so3_rotation=b.so3_rotation,
                grid_resolution_list=b.attn_grid_resolution_list,
                max_num_elements=b.max_num_elements,
                edge_channels_list=b.edge_channels_list,
                use_atom_edge_embedding=b.use_atom_edge_embedding,
                activation="sep_s2", use_attn_renorm=b.use_attn_renorm,
                use_add_merge=b.use_add_merge,
                use_rad_l_parametrization=b.use_rad_l_parametrization,
                softcap=b.softcap, eps=b.attn_eps,
            )
        self.response_layouts = {}
        for name, formula in (("Hi", "ij=ji"), ("Hij", "ij"),
                              ("dedipole", "ij"), ("depolar", "ijk=ikj")):
            if name in ("dedipole", "depolar") and name not in targets:
                continue
            tensor = CartesianTensor(formula)
            if name in ("dedipole", "depolar"):
                # CartesianTensor constructs/codegens reduced tensor products.
                # Retain only plain metadata, never construct it in forward.
                self.response_layouts[name] = tuple((mul, ir.l) for mul, ir in tensor)
            basis = tensor.reduced_tensor_products().change_of_basis
            self.register_buffer(f"basis_{name}", basis)

    def _response_to_cartesian(self, name, spherical):
        pieces = [
            spherical[:, degree**2:(degree+1)**2, :multiplicity]
            .transpose(1, 2).flatten(1)
            for multiplicity, degree in self.response_layouts[name]
        ]
        irreps = torch.cat(pieces, dim=1)
        basis = getattr(self, f"basis_{name}")
        return (irreps @ basis.flatten(1)).reshape(-1, *basis.shape[1:])

    def forward(self, data):
        b = self.backbone
        b.batch_size = data.num_graphs
        b.dtype, b.device = data.pos.dtype, data.pos.device
        edges = data.edge_index
        src, dst = edges
        # Use precisely the stored graph: labels are aligned to this edge order.
        vectors = data.pos[src] - data.pos[dst]
        distances = vectors.norm(dim=-1)
        distances, envelope = b._forward_edge(distances, vectors)
        z = data.atomic_numbers.long()
        x = b._forward_embedding(z, distances, edges, envelope)
        _, x = b._forward_blocks(
            x, z[src], z[dst], distances, edges, envelope, data.batch,
        )
        result = {}
        for name, head in self.heads.items():
            if name in ("dedipole", "depolar"):
                result[name] = self._response_to_cartesian(name, head(x))
                continue
            if name == "Hi":
                irreps = head(x)[:, :9, 0]
                irreps = torch.cat((irreps[:, :1], irreps[:, 4:9]), dim=1)
            else:
                irreps = head(x, z[src], z[dst], distances, edges)[:, :9, 0]
            result[name] = torch.einsum(
                "ni,ijk->njk", irreps, getattr(self, f"basis_{name}"),
            )
        return result
