"""Task-to-model mapping and colocated upstream dependency metadata."""

import importlib.util
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Sequence

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
BENCHMARK_ROOT = REPOSITORY_ROOT / "benchmarks"
MODEL_ROOT = BENCHMARK_ROOT / "models"

TASK_FORMAT = {
    "structure2property": "equiformer_v3",
    "structure2spectrum": "equiformer_v3",
    "structure2observables": "equiformer_v3",
    "spectrum2structure": "vib2mol",
    "spectrum2conformer": "vib2conf",
    "spectrum2property": "vib2conf",
}
TASKS = tuple(TASK_FORMAT)
EXPORT_FORMATS = ("vib2mol", "vib2conf", "equiformer_v3")

UPSTREAM_PINS = {
    "equiformer_v3": {
        "url": "https://github.com/atomicarchitects/equiformer_v3.git",
        "commit": "a7300c5",
    },
    "vib2mol": {
        "url": "https://github.com/X1nyuLu/vib2mol.git",
        "commit": "207a86e",
    },
    "vib2conf": {
        "url": "https://github.com/X1nyuLu/vib2conf.git",
        "commit": "7038837",
    },
}

PYTHON_DEPENDENCIES = (
    "numpy",
    "pandas",
    "lmdb",
    "rdkit",
    "torch",
    "torch_geometric",
)


def _git_head(path: Path) -> str:
    if not (path / ".git").exists():
        return ""
    result = subprocess.run(
        ["git", "-C", str(path), "rev-parse", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def dependency_report() -> Dict[str, Any]:
    """Report dependency availability without importing heavyweight models."""

    python = {
        name: {"available": importlib.util.find_spec(name) is not None}
        for name in PYTHON_DEPENDENCIES
    }
    repositories: Dict[str, Dict[str, Any]] = {}
    for name, pin in UPSTREAM_PINS.items():
        path = MODEL_ROOT / name / "upstream"
        head = _git_head(path)
        repositories[name] = {
            "path": str(path),
            "available": path.is_dir(),
            "expected_commit": pin["commit"],
            "actual_commit": head or None,
            "pin_matches": bool(head and head.startswith(pin["commit"])),
        }
    return {
        "python": python,
        "upstream_models": repositories,
        "ready_for_preparation": all(item["available"] for item in python.values()),
        "ready_for_all_training": (
            all(item["available"] for item in python.values())
            and all(item["available"] for item in repositories.values())
        ),
        "upstream_pins_verified": all(
            item["pin_matches"] for item in repositories.values()
        ),
    }


def formats_for_tasks(tasks: Sequence[str]) -> List[str]:
    """Map tasks to the smallest ordered set of required export formats."""

    requested = {TASK_FORMAT[task] for task in tasks}
    return [name for name in EXPORT_FORMATS if name in requested]
