"""Run the pinned Vib2Mol implementation through a stable OpenMolSpec CLI.

The upstream project uses different argument names, a fixed relative dataset
location and timestamped checkpoint directories.  This adapter owns those
integration details while leaving ``benchmarks/models/vib2mol/upstream`` pristine.
"""

from __future__ import annotations

import argparse
import json
import pickle
import shlex
import shutil
import subprocess
import sys
import time
import uuid
import tempfile
import os
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

import lmdb
import numpy as np

VIB2MOL_ROOT = Path(__file__).resolve().parent / "upstream"
DATASET_NAME = "openspec"
MODALITIES = ("ir", "raman", "ir-raman", "ir-raman-hnmr", "ir-raman-nmr")
NMR_MODALITIES = {
    "ir-raman-hnmr": ("h",),
    "ir-raman-nmr": ("c", "h"),
}
TRAIN_ACTIONS = ("matching", "generation-train", "pipeline")
EVAL_ACTIONS = ("retrieval-eval", "generation-eval")


def task_name(modality: str, use_formula: bool = False) -> str:
    """Return the task syntax expected by the pinned Vib2Mol revision."""

    if modality not in MODALITIES:
        raise ValueError(f"Unknown modality: {modality}")
    suffix = "-formula" if use_formula else ""
    if modality in NMR_MODALITIES:
        modality = 'ir-raman'  # NMR uses the maintained ragged-token adapter.
    return f"{modality}-kekule_smiles{suffix}"


def vib2mol_data_dir(data_dir: str | Path) -> Path:
    """Resolve either a benchmark root or its direct ``vib2mol`` directory."""

    path = Path(data_dir).expanduser().resolve()
    if path.name == "vib2mol":
        return path
    return path / "vib2mol"


def inspect_data(data_dir: str | Path, *, require_formula: bool = False, require_nmr: bool = False) -> Dict[str, Any]:
    """Validate all three LMDB splits and inspect their first records."""

    root = vib2mol_data_dir(data_dir)
    if require_nmr:
        report = json.loads((root.parent/'summary.json').read_text())
        if report.get('state') != 'completed':
            raise ValueError('Vib2Mol H/C build is incomplete')
        from benchmarks.engines.nmr_normalization import read_nmr_arrays
    result: Dict[str, Any] = {"path": str(root), "splits": {}}
    required_fields = {"ir", "raman", "kekule_smiles"}
    for mode in ("train", "eval", "test"):
        path = root / f"openspec_{mode}.lmdb"
        if not path.is_file():
            raise FileNotFoundError(f"Missing Vib2Mol split: {path}")
        environment = lmdb.open(
            str(path), subdir=False, readonly=True, lock=False,
            readahead=False, meminit=False,
        )
        try:
            with environment.begin() as transaction:
                count = transaction.stat()["entries"]
                cursor = transaction.cursor()
                first = pickle.loads(cursor.value()) if cursor.first() else {}
                if count < 2:
                    raise ValueError(f'{path}: at least two records required for matching negatives')
                checked = 0
                for _, blob in transaction.cursor():
                    record = pickle.loads(blob)
                    if require_nmr:
                        read_nmr_arrays(record)
                    if not isinstance(record.get('kekule_smiles'), str) or not record['kekule_smiles'].strip():
                        raise ValueError(f'{path}: empty SMILES')
                    for name in ('ir', 'raman'):
                        spectrum = np.asarray(record.get(name))
                        if spectrum.shape != (1024,) or not np.isfinite(spectrum).all():
                            raise ValueError(f'{path}: invalid {name} spectrum')
                    if require_formula and not record.get('formula'):
                        raise ValueError(f'{path}: missing/empty formula; re-export Vib2Mol data')
                    checked += 1
                    if checked == 32:
                        break
        finally:
            environment.close()
        missing = sorted(required_fields - set(first))
        if missing:
            raise ValueError(f"{path} first record is missing: {', '.join(missing)}")
        if require_formula and "formula" not in first:
            raise ValueError(
                f"{path} has no formula field. Re-export the Vib2Mol LMDBs with "
                "the current benchmarks.data.prepare before formula/generation evaluation."
            )
        result["splits"][mode] = {
            "records": int(count),
            "checked_records": checked,
            "fields": sorted(first),
            "formula_available": "formula" in first,
        }
    return result


def link_data(data_dir: str | Path) -> Path:
    """Link OpenMolSpec LMDBs into Vib2Mol's fixed dataset location."""

    source = vib2mol_data_dir(data_dir)
    destination = VIB2MOL_ROOT / "datasets" / "vibench" / DATASET_NAME
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink():
        if destination.resolve() == source:
            return destination
        destination.unlink()
    elif destination.exists():
        raise FileExistsError(
            f"Cannot replace non-symlink Vib2Mol data path: {destination}"
        )
    destination.symlink_to(source, target_is_directory=True)
    return destination


def _absolute_existing_file(path: str | Path, label: str) -> Path:
    candidate = Path(path).expanduser().resolve()
    if not candidate.is_file():
        raise FileNotFoundError(f"{label} does not exist: {candidate}")
    return candidate


def _launcher(gpus: int) -> List[str]:
    if gpus < 1:
        raise ValueError("--gpus must be at least 1")
    if gpus == 1:
        return [sys.executable]
    torchrun = shutil.which("torchrun")
    if not torchrun:
        raise FileNotFoundError("torchrun is required when --gpus is greater than 1")
    return [torchrun, "--standalone", "--nproc_per_node", str(gpus)]


def training_command(
    stage: str,
    *,
    modality: str,
    epochs: int,
    batch_size: int,
    learning_rate: float,
    device: str,
    gpus: int = 1,
    seed: int = 624,
    base_checkpoint: Optional[str | Path] = None,
    use_formula: bool = False,
    frozen_encoder: bool = False,
    smiles_augment: bool = False,
    spectra_augment: bool = False,
    check_checkpoint: bool = True,
    max_steps: Optional[int] = None,
    eval_every_steps: int = 2500,
    debug: bool = False,
) -> List[str]:
    """Build one exact upstream training command."""

    if stage not in ("matching", "spt"):
        raise ValueError(f"Unknown Vib2Mol training stage: {stage}")
    if epochs < 1 or batch_size < 1:
        raise ValueError("epochs and batch size must be positive")
    if max_steps is not None and (max_steps < 1 or eval_every_steps < 1):
        raise ValueError('step budgets and evaluation interval must be positive')
    command = [
        *_launcher(gpus),
        "main.py",
        "-train",
        "--launch", stage,
        "--model", "vib2mol",
        "--ds", DATASET_NAME,
        "--task", task_name(modality, use_formula),
        "--device", device,
        "--seed", str(seed),
        "--spectroscopy-modality", modality,
        *( ['--max-steps', str(max_steps), '--eval-every-steps', str(eval_every_steps)]
           if max_steps is not None else ['--epoch', str(epochs)] ),
        "--batch_size", str(batch_size),
        "--lr", str(learning_rate),
    ]
    if debug and max_steps is not None:
        command.append('--debug-step-budget')
    if modality == 'ir-raman-nmr':
        command.append('--hc-nmr')
    if base_checkpoint is not None:
        checkpoint_value = (
            str(_absolute_existing_file(base_checkpoint, "Base checkpoint"))
            if check_checkpoint
            else str(base_checkpoint)
        )
        command.extend([
            "--base_model_path",
            checkpoint_value,
        ])
    if frozen_encoder:
        command.append("--frozen_encoder")
    if smiles_augment:
        command.append("--smiles_augment")
    if spectra_augment:
        command.append("--spectra_augment")
    if gpus > 1:
        command.append("--ddp")
    return command


def evaluation_command(
    action: str,
    *,
    modality: str,
    checkpoint: str | Path,
    device: str,
    beam_size: int = 10,
    use_formula: bool = False,
    rerank: bool = False,
    topk: int = 10,
    rank_checkpoint: Optional[str | Path] = None,
    batch_size: int = 32,
    max_length: int = 300,
    rerank_batch_size: int = 32,
) -> List[str]:
    """Build one exact upstream retrieval or generation command."""

    if action not in EVAL_ACTIONS:
        raise ValueError(f"Unknown Vib2Mol evaluation action: {action}")
    # Use the maintained evaluator for every modality.  The pinned upstream
    # generation script tokenizes ``formula`` unconditionally, even when
    # --use_formula is false, and only prints metrics to stdout.  This adapter
    # makes formula genuinely optional and persists one test_metrics.json.
    command = [sys.executable, str(Path(__file__).with_name('evaluate_multimodal.py')),
               '--action', action, '--modality', modality, '--test_model_path',
               str(_absolute_existing_file(checkpoint, 'Checkpoint')), '--device', device,
               '--beam_size', str(beam_size), '--batch-size', str(batch_size),
               '--max-length', str(max_length), '--rerank-batch-size', str(rerank_batch_size)]
    if use_formula:
        command.append('--use_formula')
    if rerank:
        if rank_checkpoint is None:
            raise ValueError('--rank-checkpoint is required with --rerank')
        command.extend(['--rerank', '--topk', str(topk), '--rank_model_path',
                        str(_absolute_existing_file(rank_checkpoint, 'Rank checkpoint'))])
    return command


def _checkpoint_files(task: str, work_dir: Optional[Path] = None) -> Iterable[Path]:
    root = (work_dir or VIB2MOL_ROOT) / "checkpoints" / DATASET_NAME / task / "vib2mol"
    return (path for path in root.glob('*/*.pth')
            if path.name.startswith(('epoch', 'best_'))) if root.is_dir() else ()


def newest_checkpoint(
    task: str,
    *,
    newer_than: float = 0.0,
    exclude: Iterable[Path] = (),
    work_dir: Optional[Path] = None,
    metric: Optional[str] = None,
) -> Path:
    """Resolve one checkpoint deterministically; shell wildcards are never used."""

    excluded = {path.resolve() for path in exclude}
    candidates = [
        path for path in (_checkpoint_files(task, work_dir) if work_dir else _checkpoint_files(task))
        if path.stat().st_mtime >= newer_than and path.resolve() not in excluded
        and (metric is None or f'_{metric}' in path.name)
    ]
    if not candidates:
        raise RuntimeError(
            f"Vib2Mol produced no checkpoint for {task}. Inspect its log under "
            f"{VIB2MOL_ROOT / 'logs' / DATASET_NAME / task / 'vib2mol'}."
        )
    return max(candidates, key=lambda path: (path.stat().st_mtime_ns, str(path))).resolve()


def _run(command: Sequence[str], *, dry_run: bool = False, work_dir: Optional[Path] = None) -> None:
    print(f"[OpenMolSpec] Vib2Mol command: {shlex.join(command)}", flush=True)
    if not dry_run:
        environment = os.environ.copy()
        environment['PYTHONDONTWRITEBYTECODE'] = '1'
        subprocess.run(command, cwd=work_dir or VIB2MOL_ROOT, env=environment, check=True)


def prepare_workspace(root: Path, data_dir: str, limits=None) -> Path:
    """Isolate mutable upstream outputs and optional tiny LMDBs per run."""
    root.mkdir(parents=True, exist_ok=False)
    for name in ('models', 'utils', 'trainers', 'config.yaml', 'infer_retrieval.py', 'infer_generation.py'):
        (root / name).symlink_to(VIB2MOL_ROOT / name)
    # This maintained launcher propagates exceptions instead of swallowing them.
    (root / 'main.py').symlink_to(Path(__file__).with_name('train_entry.py'))
    destination = root / 'datasets' / 'vibench' / DATASET_NAME
    destination.parent.mkdir(parents=True)
    source = vib2mol_data_dir(data_dir)
    if limits is None:
        destination.symlink_to(source, target_is_directory=True)
    else:
        destination.mkdir()
        from benchmarks.data.prepare import _write_lmdb
        for mode, limit in zip(('train', 'eval', 'test'), limits):
            env = lmdb.open(str(source / f'openspec_{mode}.lmdb'), subdir=False, readonly=True, lock=False)
            try:
                def records():
                    with env.begin() as txn:
                        for i, (key, value) in enumerate(txn.cursor()):
                            if i >= limit:
                                break
                            yield key.decode(), pickle.loads(value)
                _write_lmdb(destination / f'openspec_{mode}.lmdb', records())
            finally:
                env.close()
    return destination


def run(args: argparse.Namespace) -> Dict[str, Any]:
    """Execute a parsed Vib2Mol action and return a machine-readable summary."""

    if not VIB2MOL_ROOT.is_dir():
        raise FileNotFoundError(
            f"Pinned Vib2Mol source is absent: {VIB2MOL_ROOT}. Run "
            "benchmarks/scripts/setup_models.sh first."
        )
    # Formula is an optional conditioning modality, not an implementation
    # requirement of spectrum-only generation.
    require_formula = bool(args.use_formula)
    data_report = inspect_data(args.data_dir, require_formula=require_formula,
                               **({'require_nmr': True}
                                  if args.modality in NMR_MODALITIES else {}))
    work_dir = Path(args.output).expanduser().resolve() if args.output else (
        Path('runs/vib2mol') / f'{time.strftime("%Y-%m-%d-%H-%M")}-{uuid.uuid4().hex[:6]}'
    ).resolve()
    data_link = work_dir / 'datasets' / 'vibench' / DATASET_NAME
    summary: Dict[str, Any] = {
        "action": args.action,
        "modality": args.modality,
        "data": data_report,
        "data_link": str(data_link),
        "dry_run": bool(args.dry_run),
    }
    if args.action == "check-data":
        return summary
    if not args.dry_run:
        limits = (args.debug_train_samples, args.debug_eval_samples, args.debug_test_samples) if args.debug else None
        data_link = prepare_workspace(work_dir, args.data_dir, limits)
        if args.modality in NMR_MODALITIES:
            from benchmarks.engines.nmr_normalization import fit_or_load_nmr_normalizer
            source = data_link if args.debug else vib2mol_data_dir(args.data_dir)
            if args.action in EVAL_ACTIONS:
                import torch
                state = torch.load(_absolute_existing_file(args.checkpoint, 'Checkpoint'),
                                   map_location='cpu', weights_only=True)
                state = {k.removeprefix('module.'):v for k,v in state.items()}
                ref = json.loads((vib2mol_data_dir(args.data_dir).parent/'nmr_reference.json').read_text())
                if state.get('_extra_state', {}).get('nmr_reference_id') != ref['id']:
                    raise ValueError('Checkpoint and evaluation NMR reference differ')
                normalizer = dict(reference_id=ref['id'], statistics={
                    x:dict(median=float(state['spectral_encoding.center'][i]),
                           scale=float(state['spectral_encoding.scale'][i]))
                    for i,x in enumerate(('c','h'))})
            else:
                normalizer = fit_or_load_nmr_normalizer(source/'openspec_train.lmdb',
                                                       cache_enabled=not args.debug, progress='tqdm')
            (work_dir/'nmr_normalizer.json').write_text(json.dumps(normalizer,indent=2)+'\n')
        if limits is not None:
            summary['debug_records'] = {mode: min(limit, data_report['splits'][mode]['records'])
                                      for mode, limit in zip(('train', 'eval', 'test'), limits)}
    if args.debug:
        args.epochs = args.generation_epochs = 1

    if args.action in EVAL_ACTIONS:
        command = evaluation_command(
            args.action,
            modality=args.modality,
            checkpoint=args.checkpoint,
            device=args.device,
            beam_size=args.beam_size,
            use_formula=args.use_formula,
            rerank=args.rerank,
            topk=args.topk,
            rank_checkpoint=args.rank_checkpoint,
            batch_size=args.batch_size,
            max_length=getattr(args, 'max_length', 300),
            rerank_batch_size=getattr(args, 'rerank_batch_size', 32),
        )
        _run(command, dry_run=args.dry_run, work_dir=work_dir)
        summary["command"] = command
        summary["checkpoint"] = str(Path(args.checkpoint).expanduser().resolve())
        if not args.dry_run:
            metrics_path = work_dir / 'test_metrics.json'
            if metrics_path.is_file():
                summary['metrics'] = json.loads(metrics_path.read_text())
            (work_dir / 'workflow_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
        return summary

    matching_checkpoint: Optional[Path] = None
    if args.action in ("matching", "pipeline"):
        matching_task = task_name(args.modality, args.use_formula)
        existing_checkpoints = set(_checkpoint_files(matching_task, work_dir))
        command = training_command(
            "matching", modality=args.modality, epochs=args.epochs,
            batch_size=args.batch_size, learning_rate=args.lr,
            device=args.device, gpus=args.gpus, seed=args.seed,
            use_formula=args.use_formula,
            spectra_augment=args.spectra_augment,
            max_steps=args.max_steps, eval_every_steps=args.eval_every_steps,
            debug=args.debug,
        )
        _run(command, dry_run=args.dry_run, work_dir=work_dir)
        summary["matching_command"] = command
        if not args.dry_run:
            matching_checkpoint = newest_checkpoint(
                matching_task, exclude=existing_checkpoints, work_dir=work_dir, metric='recall'
            )
            summary["matching_checkpoint"] = str(matching_checkpoint)

    if args.action in ("generation-train", "pipeline"):
        base_checkpoint: str | Path = (
            matching_checkpoint
            or args.base_checkpoint
            or "<matching-checkpoint-generated-by-stage-1>"
        )
        generation_task = task_name(args.modality, args.use_formula)
        existing_checkpoints = set(_checkpoint_files(generation_task, work_dir))
        command = training_command(
            "spt", modality=args.modality,
            epochs=args.generation_epochs or args.epochs,
            batch_size=args.generation_batch_size or args.batch_size,
            learning_rate=args.generation_lr or args.lr,
            device=args.device, gpus=args.gpus, seed=args.seed,
            base_checkpoint=base_checkpoint,
            use_formula=args.use_formula,
            frozen_encoder=args.frozen_encoder,
            smiles_augment=args.smiles_augment,
            spectra_augment=args.spectra_augment,
            check_checkpoint=not (args.action == "pipeline" and args.dry_run),
            max_steps=args.generation_max_steps or args.max_steps,
            eval_every_steps=args.eval_every_steps, debug=args.debug,
        )
        _run(command, dry_run=args.dry_run, work_dir=work_dir)
        summary["generation_command"] = command
        if not args.dry_run:
            checkpoint = newest_checkpoint(
                generation_task, exclude=existing_checkpoints, work_dir=work_dir, metric='acc'
            )
            summary["generation_checkpoint"] = str(checkpoint)
    if not args.dry_run:
        (work_dir / 'workflow_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary


def configure_parser(parser: argparse.ArgumentParser) -> None:
    """Attach Vib2Mol actions to the unified benchmark parser."""

    parser.add_argument(
        "action",
        choices=("check-data", *TRAIN_ACTIONS, *EVAL_ACTIONS),
        help="Two-stage training or test-set evaluation action",
    )
    parser.add_argument("--data-dir", default="benchmark_data/demo_10k")
    parser.add_argument("--modality", choices=MODALITIES, default="ir-raman")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--gpus", type=int, default=1)
    parser.add_argument("--epochs", type=int)
    parser.add_argument("--max-steps", type=int)
    parser.add_argument("--generation-max-steps", type=int)
    parser.add_argument("--eval-every-steps", type=int, default=2500)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=624)
    parser.add_argument("--base-checkpoint")
    parser.add_argument("--checkpoint")
    parser.add_argument("--generation-epochs", type=int)
    parser.add_argument("--generation-batch-size", type=int)
    parser.add_argument("--generation-lr", type=float)
    parser.add_argument("--frozen-encoder", action="store_true")
    parser.add_argument("--smiles-augment", action="store_true")
    parser.add_argument("--spectra-augment", action="store_true")
    parser.add_argument("--use-formula", action="store_true")
    parser.add_argument("--beam-size", type=int, default=10)
    parser.add_argument('--max-length', type=int, default=300)
    parser.add_argument('--rerank-batch-size', type=int, default=32)
    parser.add_argument("--rerank", action="store_true")
    parser.add_argument("--topk", type=int, default=10)
    parser.add_argument("--rank-checkpoint")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--output")
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--debug-train-samples", type=int, default=512)
    parser.add_argument("--debug-eval-samples", type=int, default=128)
    parser.add_argument("--debug-test-samples", type=int, default=128)


def validate_args(parser: argparse.ArgumentParser, args: argparse.Namespace) -> None:
    if args.max_steps is not None and (args.epochs is not None or args.generation_epochs is not None):
        parser.error('Use steps or epochs, not both')
    if args.generation_max_steps is not None and args.max_steps is None:
        parser.error('generation-max-steps requires max-steps')
    if args.epochs is None:
        args.epochs = 2  # Upstream construction only; step mode ignores epochs.
    for name in ('epochs', 'batch_size', 'gpus', 'beam_size', 'topk',
                 'generation_epochs', 'generation_batch_size', 'max_steps',
                 'generation_max_steps', 'eval_every_steps', 'max_length', 'rerank_batch_size'):
        value = getattr(args, name)
        if value is not None and value < 1:
            parser.error(f'{name} must be positive')
    for value in (args.lr, args.generation_lr):
        if value is not None and (not np.isfinite(value) or value <= 0):
            parser.error('learning rates must be finite and positive')
    if min(args.debug_train_samples, args.debug_eval_samples, args.debug_test_samples) < 2:
        parser.error('debug subsets must contain at least two records')
    if args.action == "generation-train" and not args.base_checkpoint:
        parser.error("generation-train requires --base-checkpoint from matching")
    if args.action in EVAL_ACTIONS and not args.checkpoint:
        parser.error(f"{args.action} requires --checkpoint")
    if args.rerank and not args.rank_checkpoint:
        parser.error("--rerank requires --rank-checkpoint")


def main(argv: Optional[Sequence[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="OpenMolSpec Vib2Mol workflow")
    configure_parser(parser)
    args = parser.parse_args(argv)
    validate_args(parser, args)
    if args.debug:
        with tempfile.TemporaryDirectory(prefix='vib2mol-debug-') as directory:
            args.output = str(Path(directory) / 'work')
            print(json.dumps(run(args), indent=2, default=str))
    else:
        print(json.dumps(run(args), indent=2, default=str))


if __name__ == "__main__":
    main()
