"""Controlled adapter for the pinned Vib2Mol spectrum-to-SMILES baseline."""
