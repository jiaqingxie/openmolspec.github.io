"""LMDB dataset used by the Vib2Conf property benchmark."""

from __future__ import annotations

import os
import pickle
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import lmdb
import numpy as np
import torch
from benchmarks.data.scalar_properties import POLAR_TARGETS, PROPERTY_UNITS
from torch.utils.data import Dataset
from benchmarks.engines.nmr_normalization import read_nmr_arrays

PROPERTY_FIELDS = ("energy", "gap", "homo", "lumo", "dipole_total", "zpve") + POLAR_TARGETS


class LmdbPropsDataset(Dataset):
    """Read spectra and scalar properties from a prepared LMDB."""

    def __init__(self, lmdb_path: str, targets=None, *, include_nmr=False, reference_id=None) -> None:
        self.targets = tuple(targets or PROPERTY_FIELDS)
        self.include_nmr = include_nmr
        self.reference_id = reference_id
        self.lmdb_path = str(lmdb_path)
        summary_path = Path(lmdb_path).parent.parent / "summary.json"
        if summary_path.is_file():
            summary = json.loads(summary_path.read_text())
            if summary.get("version") == "hc-nmr-v1" and summary.get("state") != "completed":
                raise ValueError("Multimodal dataset build is incomplete; do not train on partial LMDBs")
        env = lmdb.open(
            self.lmdb_path,
            subdir=False,
            readonly=True,
            lock=False,
            readahead=False,
            meminit=False,
            max_readers=256,
        )
        with env.begin() as transaction:
            self._keys = list(transaction.cursor().iternext(values=False))
        env.close()
        self._env: Optional[lmdb.Environment] = None
        self._env_pid: Optional[int] = None

    def _worker_env(self) -> lmdb.Environment:
        pid = os.getpid()
        if self._env is None or self._env_pid != pid:
            if self._env is not None:
                self._env.close()
            self._env = lmdb.open(
                self.lmdb_path,
                subdir=False,
                readonly=True,
                lock=False,
                readahead=False,
                meminit=False,
                max_readers=256,
            )
            self._env_pid = pid
        return self._env

    def __len__(self) -> int:
        return len(self._keys)

    def __getitem__(self, index: int) -> Dict[str, Any]:
        with self._worker_env().begin() as transaction:
            data = pickle.loads(transaction.get(self._keys[index]))
        for name in self.targets:
            if name in PROPERTY_UNITS and data.get("units", {}).get(name) != PROPERTY_UNITS[name]:
                raise ValueError(f"{self._keys[index]!r}: missing/incompatible units for {name}; rebuild spectral property LMDB")
        ir = torch.as_tensor(
            np.asarray(data.get("ir", np.full(1024, np.nan)), dtype=np.float32)
        )
        raman = torch.as_tensor(
            np.asarray(data.get("raman", np.full(1024, np.nan)), dtype=np.float32)
        )
        props = {name: float(data.get(name, float("nan"))) for name in self.targets}
        if not all(np.isfinite(value) for value in props.values()):
            raise ValueError(f"{self._keys[index]!r}: missing/nonfinite target; rebuild LMDB or audit labels")
        if ir.shape != (1024,) or raman.shape != (1024,) or not (torch.isfinite(ir).all() and torch.isfinite(raman).all()):
            raise ValueError(f"{self._keys[index]!r}: invalid spectrum")
        result = {"ir": ir, "raman": raman, "props": props}
        if self.include_nmr:
            values = read_nmr_arrays(data)
            if self.reference_id is not None and data["nmr_reference_id"] != self.reference_id:
                raise ValueError("Train/eval/test NMR reference mismatch")
            for label, value in values.items():
                result[f"nmr_{label}_shifts_ppm"] = torch.as_tensor(value)
        return result

    def __getstate__(self):
        state = self.__dict__.copy()
        state["_env"] = None
        state["_env_pid"] = None
        return state

    def __del__(self) -> None:
        env = getattr(self, "_env", None)
        if env is not None:
            env.close()


def collate_properties(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    result = {
        "ir": torch.stack([item["ir"] for item in batch]),
        "raman": torch.stack([item["raman"] for item in batch]),
        "props": {
            name: torch.tensor(
                [item["props"][name] for item in batch], dtype=torch.float32
            )
            for name in batch[0]["props"]
        },
    }
    for label in ("c", "h"):
        field = f"nmr_{label}_shifts_ppm"
        if field not in batch[0]:
            if any(field in item for item in batch):
                raise ValueError("Mixed NMR/non-NMR records in batch")
            continue
        lengths = torch.tensor([len(item[field]) for item in batch])
        values = torch.nn.utils.rnn.pad_sequence([item[field] for item in batch], batch_first=True)
        result[field] = values
        result[f"nmr_{label}_mask"] = torch.arange(values.shape[1])[None, :] < lengths[:, None]
    return result
