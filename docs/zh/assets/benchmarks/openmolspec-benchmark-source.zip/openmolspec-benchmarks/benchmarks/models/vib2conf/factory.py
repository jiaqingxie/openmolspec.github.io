"""Explicit factories for the ordered spectrum-to-property ablation.

The three public factories deliberately share the same model class and
hyperparameters.  Only the enabled input modalities differ, which makes the
IR -> IR+Raman -> IR+Raman+H/C NMR comparison controlled and reproducible.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Mapping

from benchmarks.models.vib2conf.model import SpectralPropsModel


PropertyModelFactory = Callable[..., SpectralPropsModel]


def _build_property_model(
    modality: str,
    *,
    nmr_statistics: Mapping[str, Mapping[str, float]] | None = None,
    **kwargs: Any,
) -> SpectralPropsModel:
    if modality == "ir-raman-nmr" and nmr_statistics is None:
        raise ValueError(
            "IR+Raman+H/C NMR requires train-split NMR normalization statistics"
        )
    if modality != "ir-raman-nmr" and nmr_statistics is not None:
        raise ValueError(f"{modality} must not receive NMR normalization statistics")
    return SpectralPropsModel(
        modality=modality,
        nmr_statistics=nmr_statistics,
        **kwargs,
    )


def build_ir_property_model(**kwargs: Any) -> SpectralPropsModel:
    """Build the IR-only spectrum-to-property model."""

    return _build_property_model("ir", **kwargs)


def build_raman_property_model(**kwargs: Any) -> SpectralPropsModel:
    """Build the Raman-only compatibility model.

    Raman-only remains available for existing experiments, but it is not part
    of the ordered three-point ablation requested for the release benchmark.
    """

    return _build_property_model("raman", **kwargs)


def build_ir_raman_property_model(**kwargs: Any) -> SpectralPropsModel:
    """Build the co-axis IR+Raman spectrum-to-property model."""

    return _build_property_model("ir-raman", **kwargs)


def build_ir_raman_nmr_property_model(**kwargs: Any) -> SpectralPropsModel:
    """Build the IR+Raman+H/C NMR spectrum-to-property model."""

    return _build_property_model("ir-raman-nmr", **kwargs)


PROPERTY_MODEL_FACTORIES: Dict[str, PropertyModelFactory] = {
    "ir": build_ir_property_model,
    "raman": build_raman_property_model,
    "ir-raman": build_ir_raman_property_model,
    "ir-raman-nmr": build_ir_raman_nmr_property_model,
}


def build_spectrum_property_model(
    modality: str,
    **kwargs: Any,
) -> SpectralPropsModel:
    """Dispatch to one explicit modality factory."""

    try:
        factory = PROPERTY_MODEL_FACTORIES[modality]
    except KeyError as error:
        choices = ", ".join(PROPERTY_MODEL_FACTORIES)
        raise ValueError(
            f"Unsupported spectroscopy modality {modality!r}; choose {choices}"
        ) from error
    return factory(**kwargs)
