"""Modality-specific embeddings + one fully shared spectroscopy Transformer.

The adapter path retains its name, not the old Vib2Conf architecture.
Old Vib2Conf checkpoints are intentionally incompatible.
"""
from typing import Dict, Sequence

import torch
import torch.nn as nn

from benchmarks.models.vib2conf.dataset import PROPERTY_FIELDS


class AttentionalPoolingLayer(nn.Module):
    """Upstream-style cross attention, query self attention, then FFN."""

    def __init__(self, d_model, nheads, dropout):
        super().__init__()
        self.cross_attn = nn.MultiheadAttention(d_model, nheads, dropout=dropout, batch_first=True)
        self.self_attn = nn.MultiheadAttention(d_model, nheads, dropout=dropout, batch_first=True)
        self.norms = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(3)])
        self.dropout = nn.Dropout(dropout)
        self.ffn = nn.Sequential(nn.Linear(d_model, 4*d_model), nn.GELU(),
                                 nn.Dropout(dropout), nn.Linear(4*d_model, d_model))

    def forward(self, queries, memory, padding):
        q = self.norms[0](queries)
        queries = queries + self.dropout(self.cross_attn(
            q, memory, memory, key_padding_mask=padding, need_weights=False)[0])
        q = self.norms[1](queries)
        queries = queries + self.dropout(self.self_attn(q, q, q, need_weights=False)[0])
        return queries + self.dropout(self.ffn(self.norms[2](queries)))


class SpectralPropsModel(nn.Module):
    """Co-axis vibration patches and unassigned H/C shift sets share all attention."""

    def __init__(self, *, property_targets: Sequence[str] = PROPERTY_FIELDS,
                 d_model=512, nheads=8, nlayers=6, patch_size=8,
                 encoder_layers=2, pooling_layers=4, pooling_queries=128,
                 fusion_channels=16, hidden_channels=256, dropout=0.1,
                 concat_spectrum=True, modality="ir-raman-nmr", nmr_statistics=None):
        super().__init__()
        if modality not in ("ir", "raman", "ir-raman", "ir-raman-nmr"):
            raise ValueError("Unsupported spectroscopy modality")
        if patch_size < 1 or 1024 % patch_size or d_model < 1 or nheads < 1 or d_model % nheads:
            raise ValueError("patch_size must divide 1024; d_model must divide into heads")
        if nlayers < 1 or fusion_channels < 1 or hidden_channels < 1 or not 0 <= dropout < 1:
            raise ValueError("Invalid Transformer dimensions/dropout")
        if encoder_layers < 1 or pooling_layers < 1 or pooling_queries < 1:
            raise ValueError("Encoder/pooling layers and pooling queries must be positive")
        if encoder_layers + pooling_layers != nlayers:
            raise ValueError("encoder_layers + pooling_layers must equal nlayers")
        self.property_targets = tuple(property_targets)
        self.model_parameters = {
            "d_model": d_model, "nheads": nheads, "nlayers": nlayers,
            "patch_size": patch_size, "fusion_channels": fusion_channels,
            "hidden_channels": hidden_channels, "dropout": dropout,
            "encoder_layers": encoder_layers, "pooling_layers": pooling_layers,
            "pooling_queries": pooling_queries,
        }
        self.modality = modality
        self.use_nmr = modality == "ir-raman-nmr"
        self.patch_size = patch_size
        self.channel_fusion = nn.Sequential(nn.Conv1d(2, fusion_channels, 1), nn.GELU())
        self.patch_embedding = nn.Conv1d(fusion_channels, d_model, patch_size, stride=patch_size)
        centers = torch.linspace(400., 4000., 1024).reshape(-1, patch_size).mean(dim=1)
        self.register_buffer("wavenumber_centers_cm1", centers)
        self.register_buffer("position_frequencies", torch.arange(1, 33, dtype=torch.float32))
        self.wavenumber_embedding = nn.Linear(64, d_model)
        self.type_embedding = nn.Parameter(torch.empty(3, d_model))  # Vib, C, H
        # First query is CLS; other learned queries have no physical position.
        self.pool_queries = nn.Parameter(torch.empty(1, pooling_queries + 1, d_model))
        self.no_c = nn.Parameter(torch.empty(1, 1, d_model))
        self.no_h = nn.Parameter(torch.empty(1, 1, d_model))
        self.carbon_embedding = nn.Sequential(nn.Linear(1, d_model), nn.SiLU(), nn.Linear(d_model, d_model))
        self.hydrogen_embedding = nn.Sequential(nn.Linear(1, d_model), nn.SiLU(), nn.Linear(d_model, d_model))
        self.register_buffer("nmr_center", torch.zeros(2))  # C, H; included in checkpoints
        self.register_buffer("nmr_scale", torch.ones(2))
        self.register_buffer("nmr_fitted", torch.tensor(False))
        layer = nn.TransformerEncoderLayer(d_model, nheads, dim_feedforward=4*d_model,
                    dropout=dropout, activation="gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, encoder_layers, norm=nn.LayerNorm(d_model),
                                             enable_nested_tensor=False)
        self.pooling = nn.ModuleList([
            AttentionalPoolingLayer(d_model, nheads, dropout) for _ in range(pooling_layers)
        ])
        self.pool_norm = nn.LayerNorm(d_model)
        # TransformerEncoder clones its prototype: initialize layers independently.
        for block in self.encoder.layers:
            nn.init.xavier_uniform_(block.self_attn.in_proj_weight)
            nn.init.zeros_(block.self_attn.in_proj_bias)
            for linear in (block.self_attn.out_proj, block.linear1, block.linear2):
                nn.init.xavier_uniform_(linear.weight)
                nn.init.zeros_(linear.bias)
        for token in (self.type_embedding, self.pool_queries, self.no_c, self.no_h):
            nn.init.normal_(token, std=0.02)
        self.heads = nn.ModuleDict({name: nn.Sequential(nn.LayerNorm(d_model),
            nn.Linear(d_model, hidden_channels), nn.SiLU(), nn.Dropout(dropout),
            nn.Linear(hidden_channels, 1)) for name in self.property_targets})
        if nmr_statistics is not None:
            self.set_nmr_statistics(nmr_statistics)

    def set_nmr_statistics(self, statistics):
        center = torch.tensor([statistics[x]["median"] for x in ("c", "h")], device=self.nmr_center.device)
        scale = torch.tensor([statistics[x]["scale"] for x in ("c", "h")], device=self.nmr_scale.device)
        if not torch.isfinite(center).all() or not torch.isfinite(scale).all() or (scale <= 0).any():
            raise ValueError("Invalid NMR median/IQR statistics")
        self.nmr_center.copy_(center)
        self.nmr_scale.copy_(scale)
        self.nmr_fitted.fill_(True)

    def _nmr_tokens(self, inputs, label, index, embedding, missing):
        field = f"nmr_{label}_shifts_ppm"
        mask_field = f"nmr_{label}_mask"
        if field not in inputs and mask_field not in inputs:
            shifts = inputs['ir'].new_empty((inputs['ir'].shape[0], 0))
            valid = torch.empty_like(shifts, dtype=torch.bool)
        else:
            shifts = inputs[field]
            valid = inputs[mask_field]
        if shifts.ndim != 2 or valid.shape != shifts.shape or valid.dtype != torch.bool:
            raise ValueError("NMR shifts/mask must be matching [batch, peaks] tensors")
        # Sanitize arbitrary padding BEFORE normalization and embedding.
        values = torch.where(valid, shifts, self.nmr_center[index])
        values = (values - self.nmr_center[index]) / self.nmr_scale[index]
        tokens = embedding(values.unsqueeze(-1)) + self.type_embedding[index + 1]
        present = valid.any(dim=1)
        missing_token = missing.expand(shifts.shape[0], -1, -1) + self.type_embedding[index + 1]
        tokens = torch.cat((tokens, missing_token), dim=1)
        padding = torch.cat((~valid, present[:, None]), dim=1)
        return tokens, padding

    def embed_tokens(self, inputs):
        ir, raman = inputs["ir"], inputs["raman"]
        if ir.ndim != 2 or ir.shape[1] != 1024 or raman.shape != ir.shape:
            raise ValueError("IR/Raman must share a [batch,1024] wavenumber axis")
        if self.modality == "ir":
            raman = torch.zeros_like(ir)
        elif self.modality == "raman":
            ir = torch.zeros_like(raman)
        vib = self.patch_embedding(self.channel_fusion(torch.stack((ir, raman), dim=1))).transpose(1, 2)
        coordinate = (self.wavenumber_centers_cm1 - 400.) / 3600.
        phase = 2 * torch.pi * coordinate[:, None] * self.position_frequencies[None, :]
        position = self.wavenumber_embedding(torch.cat((phase.sin(), phase.cos()), dim=-1))
        vib = vib + position + self.type_embedding[0]
        batch_size = ir.shape[0]
        tokens = [vib]
        padding = [torch.zeros((batch_size, vib.shape[1]), device=ir.device, dtype=torch.bool)]
        if self.use_nmr:
            if not self.nmr_fitted:
                raise RuntimeError("Fit NMR statistics on train data or load a fitted checkpoint first")
            for args in (("c", 0, self.carbon_embedding, self.no_c),
                         ("h", 1, self.hydrogen_embedding, self.no_h)):
                t, m = self._nmr_tokens(inputs, *args)
                tokens.append(t)
                padding.append(m)
        return torch.cat(tokens, dim=1), torch.cat(padding, dim=1)

    def encode_queries(self, inputs):
        tokens, padding = self.embed_tokens(inputs)
        memory = self.encoder(tokens, src_key_padding_mask=padding)
        queries = self.pool_queries.expand(tokens.shape[0], -1, -1)
        for layer in self.pooling:
            queries = layer(queries, memory, padding)
        return self.pool_norm(queries)

    def encode(self, inputs):
        return self.encode_queries(inputs)[:, 0]

    def forward(self, inputs: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        pooled = self.encode(inputs)
        return {name: head(pooled).squeeze(-1) for name, head in self.heads.items()}
