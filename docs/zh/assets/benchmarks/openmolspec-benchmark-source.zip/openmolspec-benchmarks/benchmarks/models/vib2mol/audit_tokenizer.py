"""Audit the pinned tokenizer without changing vocabulary or checkpoint IDs."""
import argparse
import json
import pickle
from pathlib import Path

import lmdb
from transformers import AutoTokenizer
from tqdm import tqdm


TOKENIZER = Path(__file__).parent / 'upstream/models/MolTokenizer'
EXAMPLES = ['C13', 'C13CCCCC1CCC3', 'C%13CCCCC%13', '[13CH4]',
            '[13C@@H](O)(C)N', 'ClCBr', '[NH4+]', 'C/C=C\\C']


def inspect_strings(tokenizer, strings):
    encoded = tokenizer(strings, truncation=False, add_special_tokens=True)['input_ids']
    decoded = tokenizer.batch_decode(encoded, skip_special_tokens=True,
                                     clean_up_tokenization_spaces=False)
    return [dict(smiles=s, decoded=d.replace(' ', ''),
                 tokens=tokenizer.convert_ids_to_tokens(ids),
                 unknown=tokenizer.unk_token_id in ids,
                 length=len(ids), roundtrip=s == d.replace(' ', ''),
                 exceeds_limit=len(ids) > tokenizer.model_max_length)
            for s, ids, d in zip(strings, encoded, decoded)]


def audit(path, tokenizer, limit=None):
    counts = dict(records=0, unknown=0, roundtrip_mismatch=0, exceeds_limit=0,
                  stereo_records=0, max_tokens=0)
    examples = []
    env = lmdb.open(str(path), subdir=False, readonly=True, lock=False, readahead=False)
    try:
        with env.begin() as txn:
            strings = []
            def consume():
                for row in inspect_strings(tokenizer, strings):
                    counts['records'] += 1
                    counts['unknown'] += row['unknown']
                    counts['roundtrip_mismatch'] += not row['roundtrip']
                    counts['exceeds_limit'] += row['exceeds_limit']
                    counts['stereo_records'] += any(c in row['smiles'] for c in '@/\\')
                    counts['max_tokens'] = max(counts['max_tokens'], row['length'])
                    if len(examples) < 10 and (not row['roundtrip'] or row['unknown'] or row['exceeds_limit']):
                        examples.append(row)
            for key, value in tqdm(txn.cursor(), total=env.stat()['entries'], desc=path.stem):
                if key.startswith(b'__'):
                    continue
                strings.append(pickle.loads(value)['kekule_smiles'])
                if len(strings) == 256 or (limit and counts['records']+len(strings) >= limit):
                    consume()
                    strings.clear()
                if limit and counts['records'] >= limit:
                    break
            if strings:
                consume()
    finally:
        env.close()
    return dict(**counts, examples=examples, limit=limit)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    if args.limit is not None and args.limit < 1:
        parser.error('--limit must be positive')
    tokenizer = AutoTokenizer.from_pretrained(TOKENIZER, local_files_only=True)
    root = args.data_dir / 'vib2mol' if (args.data_dir / 'vib2mol').is_dir() else args.data_dir
    report = dict(vocab_size=len(tokenizer), max_length=tokenizer.model_max_length,
                  examples=inspect_strings(tokenizer, EXAMPLES),
                  splits={mode: audit(root/f'openspec_{mode}.lmdb', tokenizer, args.limit)
                          for mode in ('train', 'eval', 'test')})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: {x: y for x, y in v.items() if x != 'examples'}
                      for k, v in report['splits'].items()}, indent=2))


if __name__ == '__main__':
    main()
