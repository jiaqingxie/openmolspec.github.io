"""Explicit model factories for the Vib2Mol modality ablation."""

from __future__ import annotations

from typing import Any, Callable, Mapping, MutableMapping


ModelFactory = Callable[..., Any]


def _checked_channels(
    kwargs: Mapping[str, Any],
    expected: int,
    label: str,
) -> dict[str, Any]:
    parameters = dict(kwargs)
    actual = int(parameters.get("spectral_channel", expected))
    if actual != expected:
        raise ValueError(
            f"{label} requires spectral_channel={expected}, received {actual}"
        )
    parameters["spectral_channel"] = expected
    return parameters


def build_ir_vib2mol(upstream_factory: ModelFactory, **kwargs: Any) -> Any:
    """Build Vib2Mol with one IR input channel."""

    return upstream_factory(**_checked_channels(kwargs, 1, "IR"))


def build_raman_vib2mol(upstream_factory: ModelFactory, **kwargs: Any) -> Any:
    """Build the retained Raman-only compatibility variant."""

    return upstream_factory(**_checked_channels(kwargs, 1, "Raman"))


def build_ir_raman_vib2mol(upstream_factory: ModelFactory, **kwargs: Any) -> Any:
    """Build Vib2Mol with co-axis IR and Raman input channels."""

    return upstream_factory(**_checked_channels(kwargs, 2, "IR+Raman"))


def build_ir_raman_nmr_vib2mol(
    multimodal_model_class: type,
    *,
    nmr_normalizer: Mapping[str, Any],
    **kwargs: Any,
) -> Any:
    """Build Vib2Mol with IR, Raman and ragged H/C chemical-shift tokens."""

    if not nmr_normalizer:
        raise ValueError("IR+Raman+H/C NMR requires an NMR normalizer")
    for field in ("statistics", "reference_id"):
        if field not in nmr_normalizer:
            raise ValueError(f"NMR normalizer is missing {field!r}")
    parameters = _checked_channels(kwargs, 2, "IR+Raman+H/C NMR")
    return multimodal_model_class(
        nmr_statistics=nmr_normalizer["statistics"],
        nmr_reference_id=nmr_normalizer["reference_id"],
        nuclei=("c", "h"),
        **parameters,
    )


def build_ir_raman_hnmr_vib2mol(
    multimodal_model_class: type,
    *,
    nmr_normalizer: Mapping[str, Any],
    **kwargs: Any,
) -> Any:
    """Build Vib2Mol with IR, Raman and only ragged 1H shift tokens."""

    if not nmr_normalizer:
        raise ValueError("IR+Raman+1H NMR requires an NMR normalizer")
    for field in ("statistics", "reference_id"):
        if field not in nmr_normalizer:
            raise ValueError(f"NMR normalizer is missing {field!r}")
    if "h" not in nmr_normalizer["statistics"]:
        raise ValueError("NMR normalizer is missing 1H statistics")
    parameters = _checked_channels(kwargs, 2, "IR+Raman+1H NMR")
    return multimodal_model_class(
        nmr_statistics=nmr_normalizer["statistics"],
        nmr_reference_id=nmr_normalizer["reference_id"],
        nuclei=("h",),
        **parameters,
    )


def make_vib2mol_factory(
    modality: str,
    *,
    upstream_factory: ModelFactory,
    multimodal_model_class: type | None = None,
    nmr_normalizer: Mapping[str, Any] | None = None,
) -> ModelFactory:
    """Return the exact registry factory for one spectroscopy input set."""

    if modality == "ir":
        return lambda **kwargs: build_ir_vib2mol(upstream_factory, **kwargs)
    if modality == "raman":
        return lambda **kwargs: build_raman_vib2mol(upstream_factory, **kwargs)
    if modality == "ir-raman":
        return lambda **kwargs: build_ir_raman_vib2mol(upstream_factory, **kwargs)
    if modality == "ir-raman-hnmr":
        if multimodal_model_class is None or nmr_normalizer is None:
            raise ValueError(
                "IR+Raman+1H NMR requires its multimodal class and NMR normalizer"
            )
        return lambda **kwargs: build_ir_raman_hnmr_vib2mol(
            multimodal_model_class,
            nmr_normalizer=nmr_normalizer,
            **kwargs,
        )
    if modality == "ir-raman-nmr":
        if multimodal_model_class is None or nmr_normalizer is None:
            raise ValueError(
                "IR+Raman+H/C NMR requires its multimodal class and NMR normalizer"
            )
        return lambda **kwargs: build_ir_raman_nmr_vib2mol(
            multimodal_model_class,
            nmr_normalizer=nmr_normalizer,
            **kwargs,
        )
    raise ValueError(f"Unsupported Vib2Mol spectroscopy modality: {modality}")


def install_vib2mol_factory(
    registry: MutableMapping[str, ModelFactory],
    modality: str,
    *,
    upstream_factory: ModelFactory,
    multimodal_model_class: type | None = None,
    nmr_normalizer: Mapping[str, Any] | None = None,
) -> ModelFactory:
    """Install and return one explicit factory in the upstream registry."""

    factory = make_vib2mol_factory(
        modality,
        upstream_factory=upstream_factory,
        multimodal_model_class=multimodal_model_class,
        nmr_normalizer=nmr_normalizer,
    )
    registry["vib2mol"] = factory
    return factory
