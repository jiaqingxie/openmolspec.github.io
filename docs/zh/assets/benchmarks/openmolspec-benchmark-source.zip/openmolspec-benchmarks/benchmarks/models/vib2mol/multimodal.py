"""H/C-aware Vib2Mol; preserves the upstream six-layer encoder and SMILES modules.

Inference routines adapted from pinned upstream models/vib2mol.py (X1nyuLu/vib2mol).
Only spectral encoding/masks and the molecular mask keyword are changed.
"""
import torch
import torch.nn.functional as F
from models.vib2mol import Vib2Mol as UpstreamVib2Mol
from models.modules import make_std_mask, subsequent_mask
from benchmarks.models.vib2mol.nmr_embedding import MultimodalEmbedding
from benchmarks.models.vib2mol.matching import matching_forward


class MultimodalVib2Mol(UpstreamVib2Mol):
    def __init__(self, *, nmr_statistics, nmr_reference_id=None,
                 nuclei=('c', 'h'), **kwargs):
        super().__init__(**kwargs)
        self.nmr_reference_id = nmr_reference_id
        self.nmr_nuclei = tuple(nuclei)
        d_model = kwargs.get('d_model', 768)
        self.spectral_encoding = MultimodalEmbedding(
            d_model, nmr_statistics, nuclei=self.nmr_nuclei)

    @property
    def architecture_id(self):
        return 'vib2mol-hc-v1' if self.nmr_nuclei == ('c', 'h') else 'vib2mol-h-v1'

    def get_extra_state(self):
        return {'architecture': self.architecture_id,
                'nmr_reference_id': self.nmr_reference_id}

    def set_extra_state(self, state):
        if (state.get('architecture') != self.architecture_id or
                state.get('nmr_reference_id') != self.nmr_reference_id):
            raise ValueError('Checkpoint architecture/NMR reference mismatch')

    def load_state_dict(self, state_dict, strict=True, **kwargs):
        # Upstream loads strict=False; never silently accept a pre-NMR checkpoint.
        return super().load_state_dict(state_dict, strict=True, **kwargs)

    def encode_spectra(self, inputs):
        tokens, mask = self.spectral_encoding(inputs)
        hidden = tokens
        for layer in self.spectral_encoder.layers:
            hidden = layer(hidden, mask=mask)
        hidden = self.spectral_encoder.norm(hidden)
        return dict(hidden_states=hidden, mask=mask,
                    proj_output=self.spectral_encoder.proj(hidden[:, 0]))

    def matching(self, inputs):
        spectra = self.encode_spectra(inputs)
        ids = inputs['smiles']['input_ids']
        mask = inputs['smiles']['attention_mask']
        mask = torch.cat((mask.new_ones((len(mask), 1)), mask), 1)
        output = self.molecular_encoder(self.molecular_encoding(ids, use_cls_token=True),
            memory=spectra['hidden_states'], src_mask=spectra['mask'],
            tgt_mask=mask, multimodal=True)
        return output['proj_output']

    def forward(self, inputs, return_loss=True, return_proj_output=False):
        if self.phase == 1:
            return matching_forward(self, inputs, return_loss, return_proj_output)
        spectra = self.encode_spectra(inputs)
        memory, src_mask = spectra['hidden_states'], spectra['mask']
        if 'formula' in inputs:
            formula = inputs['formula']
            memory = torch.cat((memory, self.formula_encoding(formula['input_ids'])), 1)
            src_mask = torch.cat((src_mask, formula['attention_mask']), 1)
            memory = self.multimodal_encoder(memory, src_mask)['hidden_states']
        ids, mask = inputs['smiles']['input_ids'], inputs['smiles']['attention_mask']
        masked, mlm_mask = self.generate_mlmmask(ids, mask_prob=self.mask_prob)
        embedded = self.molecular_encoding(masked, use_cls_token=False)
        encoded = self.molecular_encoder(embedded, mask=mask)['hidden_states']
        mlm = self.molecular_decoder(encoded, memory, src_mask=src_mask, tgt_mask=mask)['proj_output']
        causal_ids = ids[:, :-1]
        causal = self.molecular_decoder(self.molecular_encoding(causal_ids), memory,
            src_mask=src_mask, tgt_mask=make_std_mask(causal_ids, pad=1).type_as(mask))['proj_output']
        result = {}
        if return_loss:
            mlm_loss = self.compute_mlm_loss(mlm[mlm_mask], ids[mlm_mask]) if mlm_mask.any() else mlm.sum()*0
            lm_loss = self.compute_lm_loss(causal, ids[:, 1:])
            result.update(mlm_loss=mlm_loss, lm_loss=lm_loss, loss=mlm_loss + lm_loss)
        if return_proj_output:
            full_mask = torch.cat((mask.new_ones((len(mask), 1)), mask), 1)
            molecular = self.molecular_encoder(self.molecular_encoding(ids, use_cls_token=True), mask=full_mask)
            result.update(molecular_proj_output=molecular['proj_output'],
                          spectral_proj_output=spectra['proj_output'])
        return result

    @torch.no_grad()
    def infer_mlm(self, input):
        # Mask Language Infer
        spectral_input = self.load_spectra(input)
        spectral_output = self.encode_spectra(input)

        src_embeds = spectral_output['hidden_states']
        src_mask = spectral_output['mask']

        if 'formula' in input:
            formula_input_ids = input['formula']['input_ids']
            formula_attention_mask = input['formula']['attention_mask']
            formula_embeds = self.formula_encoding(formula_input_ids)

            src_embeds = torch.cat([spectral_output['hidden_states'], formula_embeds], dim=1)
            src_mask = torch.cat([spectral_output['mask'],
                                    formula_attention_mask], dim=1)

            src_embeds = self.multimodal_encoder(src_embeds, src_mask)
            src_embeds = src_embeds['hidden_states']


        molecular_input_ids = input['smiles']['input_ids']
        molecular_attention_mask = input['smiles']['attention_mask']

        masked_molecular_embeds = self.molecular_encoding(molecular_input_ids, use_cls_token=False)
        masked_molecular_output = self.molecular_encoder(masked_molecular_embeds, mask=molecular_attention_mask)
        mlm_tokens = self.molecular_decoder(masked_molecular_output['hidden_states'],
                                            src_embeds,
                                            src_mask=src_mask,
                                            tgt_mask=molecular_attention_mask
                                            )

        return mlm_tokens['proj_output']

    @torch.no_grad()
    def _infer_lm_uncached(self,
              input,
              max_len=256,
              return_metrics=False,
              target_ids=None,
              ):
        spectral_input = self.load_spectra(input)
        spectral_output = self.encode_spectra(input)

        src_embeds = spectral_output['hidden_states']
        src_mask = spectral_output['mask']

        pred_ids = torch.zeros(spectral_input.size(0), 1, dtype=torch.long, device=spectral_input.device)

        if 'formula' in input:
            formula_input_ids = input['formula']['input_ids']
            formula_attention_mask = input['formula']['attention_mask']
            formula_embeds = self.formula_encoding(formula_input_ids)

            src_embeds = torch.cat([spectral_output['hidden_states'], formula_embeds], dim=1)
            src_mask = torch.cat([spectral_output['mask'],
                                    formula_attention_mask], dim=1)

            src_embeds = self.multimodal_encoder(src_embeds, src_mask)
            src_embeds = src_embeds['hidden_states']

        for i in range(max_len-1):
            pred_emebds = self.molecular_encoding(pred_ids)
            casual_mask = subsequent_mask(pred_ids.size(1)).type_as(pred_ids.data)

            pred_output = self.molecular_decoder(pred_emebds, src_embeds,
                                                 src_mask=src_mask, # spectrum-structure
                                                 tgt_mask=casual_mask # structure-structure
                                                 )
            prob = pred_output['proj_output'][:, -1]
            _, next_word = torch.max(prob, dim=1)
            pred_ids = torch.cat([pred_ids, (next_word).reshape(-1, 1)], dim=1)

        result_dict = {'pred_ids':pred_ids}

        if return_metrics:
            ntokens = (target_ids != 1).sum() # ignore all <pad> tokens
            target_ids = target_ids.contiguous().view(-1)
            pred_ids = pred_ids.contiguous().view(-1)
            accuracy = sum(pred_ids[target_ids != 1] == target_ids[target_ids != 1]) / ntokens
            result_dict['metrics'] = accuracy
        return result_dict



    @torch.no_grad()
    def _beam_infer_lm_uncached(self,
                      input,
                      max_len=256,
                      beam_size=3,
                      temperature=1.0, # Adjusted to 1.0 as typical for log_softmax without explicit temperature scaling for sampling
                      ):
        # --- Initial Encoding (equivalent to the 'encode' part in the reference) ---
        spectral_input = self.load_spectra(input)
        batch_size = spectral_input.size(0)

        # Encode spectral input
        spectral_output = self.encode_spectra(input)

        # Mocking the output format of spectral_encoder to match reference's memory
        src_embeds_initial = spectral_output['hidden_states'] # First call to model.encode
        src_mask_initial = spectral_output['mask']


        # Handle formula input if present
        if isinstance(input, dict) and 'formula' in input:
            formula_input_ids = input['formula']['input_ids']
            formula_attention_mask = input['formula']['attention_mask']
            formula_embeds = self.formula_encoding(formula_input_ids)

            # Combine spectral and formula embeddings for multimodal encoding
            # This logic is now implicitly handled within self.model.encode if formula is passed
            src_embeds = torch.cat([src_embeds_initial, formula_embeds], dim=1)
            src_mask = torch.cat([src_mask_initial, formula_attention_mask], dim=1)

            # This step conceptually becomes part of the model.encode logic
            memory = self.multimodal_encoder(src_embeds, src_mask)['hidden_states']
        else:
            memory = src_embeds_initial
            src_mask = src_mask_initial # Only spectral mask


        # --- Beam Search Initialization (similar to reference's first step) ---
        # Initialize target sequence with BOS token
        ys = torch.zeros(batch_size, 1, dtype=torch.long, device=spectral_input.device)
        ys_embeds = self.molecular_encoding(ys)
        # Perform initial decoding step to get first probabilities
        # Repeat memory and src_mask for all beams for the first step (beam_size=1 effectively)
        # No repeat_interleave here yet because we are getting the *initial* topk for beam_size paths
        out = self.molecular_decoder(
            ys_embeds,
            memory,
            src_mask=src_mask,
            tgt_mask=subsequent_mask(ys.size(1)).type_as(spectral_input.data),
        )

        prob = out['proj_output'][:, -1] # Get logits for the last token
        log_prob = F.log_softmax(prob / temperature, dim=-1) # Apply log_softmax and temperature

        # Select top-k initial tokens to form the first set of beams
        # For initialization, we assume prob is for a single sequence per batch item
        topk_scores, topk_indices = log_prob.topk(k=beam_size, dim=-1) # (batch_size, beam_size)

        # Initialize beams: (current_sequence, current_score)
        # Expand ys for each beam in the batch
        pred_seqs = ys.unsqueeze(1).repeat(1, beam_size, 1) # (batch_size, beam_size, 1)
        pred_seqs = torch.cat([pred_seqs, topk_indices.unsqueeze(-1)], dim=-1) # (batch_size, beam_size, 2)
        beam_scores = topk_scores # (batch_size, beam_size)

        final_outputs = [[] for _ in range(batch_size)] # Store (score, sequence) for each batch item

        # --- Beam Search Loop ---
        for i in range(max_len - 2): # BOS and the first generated token already exist.
            flat_pred_seqs = pred_seqs.reshape(batch_size * beam_size, -1) # (batch*beam, seq_len)
            flat_pred_embeds = self.molecular_encoding(flat_pred_seqs)
            # Prepare memory and src_mask for repeated beams
            # memory and src_mask need to be repeated beam_size times for decoding each beam
            expanded_memory = memory.repeat_interleave(beam_size, dim=0)
            expanded_src_mask = src_mask.repeat_interleave(beam_size, dim=0)

            casual_mask = subsequent_mask(flat_pred_seqs.size(1)).type_as(flat_pred_seqs.data)

            # Molecular decoder step (now handled by self.model.decode)
            pred_output = self.molecular_decoder(
                flat_pred_embeds,
                expanded_memory,
                tgt_mask=casual_mask,
                src_mask=expanded_src_mask
            )

            # Get current log probabilities for the next token
            prob = pred_output['proj_output'][:, -1]
            log_prob = F.log_softmax(prob / temperature, dim=-1)
            vocab_size = log_prob.size(-1)

            # Reshape log_prob to (batch_size, beam_size, vocab_size)
            log_prob = log_prob.view(batch_size, beam_size, vocab_size)

            # Add current beam scores to the new log probabilities
            expanded_scores = beam_scores.unsqueeze(-1) + log_prob

            # Select top-k candidates across all beams for the next step
            # Flatten to (batch_size, beam_size * vocab_size) to find overall top-k
            topk_scores, topk_indices = expanded_scores.view(batch_size, -1).topk(beam_size, dim=-1)

            # Determine which beam and which word each top-k candidate came from
            beam_indices = topk_indices // vocab_size
            word_indices = topk_indices % vocab_size

            # Update sequences and scores for the next iteration
            # Use gather to select the correct parent sequences
            pred_seqs_temp = pred_seqs.gather(1, beam_indices.unsqueeze(-1).expand(-1, -1, pred_seqs.size(-1)))
            pred_seqs = torch.cat([pred_seqs_temp, word_indices.unsqueeze(-1)], dim=-1)
            beam_scores = topk_scores

            # Detect </s> token (EOS_idx) for early termination and collect finished sequences
            for b in range(batch_size):
                for j in range(beam_size):
                    if pred_seqs[b, j, -1].item() == 2:
                        # Append the finished sequence and its score
                        final_outputs[b].append((beam_scores[b, j].item(), pred_seqs[b, j].clone()))
                        # Invalidate this beam so it's not chosen again
                        beam_scores[b, j] = -1e9 # A very small number to effectively remove it from topk consideration

            # Check if all beams for all batches have terminated
            # This loop condition is simplified from the original reference
            # The reference just runs for max_len-2 steps.
            # If you want early stopping based on all beams finishing, uncomment/adapt below:
            if all(len(outputs) >= beam_size for outputs in final_outputs):
                break

        # Collect any remaining unfinished sequences if the loop completes without all terminating
        for b in range(batch_size):
            # Add any beams that haven't reached EOS but are still in the top-k
            for j in range(beam_size):
                if pred_seqs[b, j, -1].item() != 2 and beam_scores[b, j].item() != -1e9:
                    final_outputs[b].append((beam_scores[b, j].item(), pred_seqs[b, j].clone()))

            # Sort and select the top 'beam_size' (or 'n_best' if you introduce that parameter)
            final_outputs[b] = sorted(final_outputs[b], key=lambda x: x[0], reverse=True)[:beam_size]

        # Prepare the result dictionary
        result_dict = {
            'pred_ids': [[output[1] for output in outputs] for outputs in final_outputs],
            'score': [[output[0] for output in outputs] for outputs in final_outputs],
        }

        return result_dict

    def _generation_memory(self, inputs):
        spectra = self.encode_spectra(inputs)
        memory, src_mask = spectra['hidden_states'], spectra['mask']
        if 'formula' in inputs:
            formula = inputs['formula']
            memory = torch.cat(
                (memory, self.formula_encoding(formula['input_ids'])), 1)
            src_mask = torch.cat((src_mask, formula['attention_mask']), 1)
            memory = self.multimodal_encoder(memory, src_mask)['hidden_states']
        return memory, src_mask

    @torch.no_grad()
    def infer_lm(self, inputs, max_len=256, return_metrics=False,
                 target_ids=None):
        from benchmarks.models.vib2mol.kv_cache import greedy_decode
        memory, src_mask = self._generation_memory(inputs)
        return greedy_decode(
            self, memory, src_mask, memory.size(0), max_len,
            return_metrics=return_metrics, target_ids=target_ids)

    @torch.no_grad()
    def beam_infer_lm(self, inputs, max_len=256, beam_size=3,
                      temperature=1.0):
        from benchmarks.models.vib2mol.kv_cache import beam_decode
        if max_len < 2 or beam_size < 1 or temperature <= 0:
            raise ValueError('max_len >= 2, beam_size >= 1 and temperature > 0 required')
        memory, src_mask = self._generation_memory(inputs)
        return beam_decode(
            self, memory, src_mask, memory.size(0), max_len, beam_size,
            temperature)
