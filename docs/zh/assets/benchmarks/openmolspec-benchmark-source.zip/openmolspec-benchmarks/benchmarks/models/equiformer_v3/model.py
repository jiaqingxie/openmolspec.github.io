"""EquiformerV3 wrapper for the OpenMolSpec structure tasks.

The wrapper reuses the pinned upstream ``EquiformerV3_OC`` backbone
(``benchmarks/models/equiformer_v3/upstream``) and adds task heads on top of the pooled
per-atom scalar embedding:

* structure->property: one scalar regression head per quantum property;
* structure->spectrum: one 1024-dim regression head per spectrum channel.

The upstream forward path is replicated locally (rather than editing the
vendored file) so the backbone internals stay pristine and pinned.
"""

import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import torch
import torch.nn as nn
from torch_geometric.utils import scatter

_UPSTREAM = Path(__file__).resolve().parent / "upstream"
for _path in (
    str(_UPSTREAM),
    str(_UPSTREAM / "src"),
    str(_UPSTREAM / "experimental"),
):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from experimental.models.equiformer_v3.equiformer_v3 import EquiformerV3_OC  # noqa: E402


class OpenSpecEquiformerV3(nn.Module):
    """EquiformerV3 backbone with OpenMolSpec task heads."""

    def __init__(
        self,
        *,
        property_targets: Sequence[str] = ("energy", "gap", "homo", "lumo", "dipole_total", "zpve"),
        spectrum_targets: Sequence[str] = ("ir_spectrum", "raman_spectrum"),
        hidden_channels: int = 128,
        dropout: float = 0.1,
        backbone: Optional[Dict[str, object]] = None,
    ) -> None:
        super().__init__()
        backbone_config = {
            "use_pbc": False,
            "regress_forces": False,
            "regress_stress": False,
            "direct_prediction": True,
            "num_layers": 6,
            "num_channels": 128,
            "attn_hidden_channels": 64,
            "num_heads": 8,
            "attn_alpha_channels": 32,
            "attn_value_channels": 16,
            "ffn_hidden_channels": 128,
            "edge_channels": 128,
            "lmax": 4,
            "mmax": 2,
            "max_neighbors": 20,
            "max_radius": 5.0,
            "num_radial_basis": 600,
            "max_num_elements": 118,
            "attn_grid_resolution_list": [20, 8],
            "ffn_grid_resolution_list": [20, 20],
            "use_head_reg": True,
        }
        if backbone:
            backbone_config.update(backbone)
        self.backbone = EquiformerV3_OC(**backbone_config)
        self.backbone.batch_size = 1  # set per forward call
        self.backbone.dtype = torch.float32
        self.backbone.device = "cpu"

        self.property_targets = tuple(property_targets)
        self.spectrum_targets = tuple(spectrum_targets)
        channels = backbone_config["num_channels"]

        def _head(out_dim: int) -> nn.Module:
            return nn.Sequential(
                nn.LayerNorm(channels),
                nn.Linear(channels, hidden_channels),
                nn.SiLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden_channels, out_dim),
            )

        self.property_heads = nn.ModuleDict(
            {name: _head(1) for name in self.property_targets}
        )
        self.spectrum_heads = nn.ModuleDict(
            {name: _head(1024) for name in self.spectrum_targets}
        )

    def _pooled_embedding(self, data) -> torch.Tensor:
        """Return the mean-pooled per-atom scalar embedding of each graph."""

        backbone = self.backbone
        backbone.batch_size = int(data.batch.max()) + 1
        backbone.dtype = data.pos.dtype
        backbone.device = data.pos.device

        (
            edge_index,
            edge_distance,
            edge_distance_vec,
            cell_offsets,
            _,
            neighbors,
        ) = backbone.generate_graph(data)

        atomic_numbers = data.atomic_numbers.long()
        source_atomic_numbers = atomic_numbers[edge_index[0]]
        target_atomic_numbers = atomic_numbers[edge_index[1]]

        edge_distance, edge_envelope_weight = backbone._forward_edge(
            edge_distance, edge_distance_vec
        )
        x = backbone._forward_embedding(
            atomic_numbers, edge_distance, edge_index, edge_envelope_weight
        )
        x_scalar, _ = backbone._forward_blocks(
            x,
            source_atomic_numbers,
            target_atomic_numbers,
            edge_distance,
            edge_index,
            edge_envelope_weight,
            data.batch,
        )
        return scatter(x_scalar, data.batch, dim=0, reduce="mean")

    def forward(self, data) -> Dict[str, torch.Tensor]:
        pooled = self._pooled_embedding(data)
        outputs: Dict[str, torch.Tensor] = {}
        for name, head in self.property_heads.items():
            outputs[name] = head(pooled).squeeze(-1)
        for name, head in self.spectrum_heads.items():
            outputs[name] = head(pooled)
        return outputs
