"""Fixed optimizer-update lifecycle for both Vib2Mol stages.

The legacy epoch scheduler is never stepped here. Validation checkpointing is
independent of epoch boundaries and early stopping does not shorten the budget.
"""
import json
import math
from pathlib import Path

import torch
import torch.distributed as dist
from tqdm import tqdm

from benchmarks.models.vib2mol.lifecycle import distributed, primary


@torch.no_grad()
def evaluate_generation(engine, step):
    """Measure generation accuracy at EVERY requested validation step."""
    engine.model.eval()
    sums = dict(loss=0.0, mlm_loss=0.0, lm_loss=0.0, metrics=0.0)
    count = 0
    model = engine.model.module if distributed() else engine.model
    for batch in tqdm(engine.eval_loader, desc=f'Step {step} [Valid generation]',
                      disable=not primary(), dynamic_ncols=True):
        data = engine._put_on_device(batch['data'])
        output = engine.model(data, return_proj_output=False)
        result = model.infer_lm(
            data, max_len=data['smiles']['input_ids'].size(-1),
            return_metrics=True, target_ids=data['smiles']['input_ids'])
        weight = batch['batch_size']
        for key in ('loss', 'mlm_loss', 'lm_loss'):
            sums[key] += float(output[key].detach()) * weight
        sums['metrics'] += float(result['metrics'].detach()) * weight
        count += weight
    if not count:
        raise ValueError('Empty generation validation loader')
    # Upstream validation is replicated on every rank, not sharded.
    return {key: value / count for key, value in sums.items()}


def validate_and_save(trainer, output, step, generation, best_score, best_step):
    message = [None]
    if primary():
        try:
            values = {key: float(value) for key, value in output.items()}
            if not all(math.isfinite(value) for value in values.values()):
                raise ValueError(f'Non-finite validation: {values}')
            key, suffix = ('metrics', 'acc') if generation else ('recall', 'recall')
            score = values[key]
            if score > best_score:
                best_score, best_step = score, step
                # Keep the upstream state_dict format for generation/inference.
                torch.save(trainer.model.state_dict(),
                           Path(trainer.model_save_path) / f'best_{suffix}.pth')
            message[0] = dict(best_score=best_score, best_step=best_step)
        except Exception as exc:
            message[0] = dict(error=f'{type(exc).__name__}: {exc}')
    if distributed():
        dist.broadcast_object_list(message, src=0)
    if 'error' in message[0]:
        raise RuntimeError(message[0]['error'])
    return message[0]['best_score'], message[0]['best_step']


def train_steps(trainer, generation=False):
    engine = trainer.engine
    loader = engine.train_loader
    if not len(loader):
        raise ValueError('Step training requires a nonempty train loader')
    budget = trainer.config['max_steps']
    interval = trainer.config['eval_every_steps']
    if trainer.config.get('debug_step_budget'):
        budget = min(budget, len(loader))
        interval = min(interval, budget)
    if budget < 1 or interval < 1:
        raise ValueError('Step budgets must be positive')
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        engine.optimizer, T_max=budget, eta_min=0.0)
    best_score, best_step = -float('inf'), 0
    iterator, epoch = None, 0
    total, count = 0.0, 0
    stage = 'generation' if generation else 'matching'
    if primary():
        Path(trainer.model_save_path).mkdir(parents=True, exist_ok=True)
        print(f'[Vib2Mol] {stage}: max_steps={budget}, eval_every_steps={interval}, '
              'cosine per update, early stopping disabled', flush=True)
    try:
        with tqdm(range(1, budget + 1), desc=f'{stage} steps',
                  disable=not primary(), dynamic_ncols=True) as bar:
            for step in bar:
                if iterator is None:
                    if trainer.ddp:
                        trainer.train_sampler.set_epoch(epoch)
                    iterator = iter(loader)
                try:
                    batch = next(iterator)
                except StopIteration:
                    epoch += 1
                    if trainer.ddp:
                        trainer.train_sampler.set_epoch(epoch)
                    iterator = iter(loader)
                    batch = next(iterator)
                engine.model.train()
                lr = engine.optimizer.param_groups[0]['lr']
                engine.optimizer.zero_grad(set_to_none=True)
                loss = engine.model(engine._put_on_device(batch['data']))['loss']
                loss.backward()
                engine.optimizer.step()
                scheduler.step()
                total += float(loss.detach()) * batch['batch_size']
                count += batch['batch_size']
                bar.set_description(f'{stage} step {step}/{budget} loss:{total/count:.6f}')
                if primary() and (step == 1 or step % 100 == 0 or step == budget):
                    trainer.writer.add_scalar('train/learning_rate', lr, step)
                if step % interval and step != budget:
                    continue
                totals = torch.tensor([total, count], dtype=torch.float64, device=engine.device)
                if distributed():
                    dist.all_reduce(totals)
                mean_loss = float(totals[0] / totals[1])
                output = (evaluate_generation(engine, step) if generation
                          else engine.eval_epoch(step))
                best_score, best_step = validate_and_save(
                    trainer, output, step, generation, best_score, best_step)
                if primary():
                    trainer.writer.add_scalar('train/loss', mean_loss, step)
                    for key, value in output.items():
                        trainer.writer.add_scalar(f'validation/{key}', float(value), step)
                    trainer.writer.flush()
                    bar.write(f'[Vib2Mol] {stage} step {step}/{budget} | '
                              f'train_loss={mean_loss:.6g} | validation={output}')
                total, count = 0.0, 0
        if primary():
            result = dict(stage=stage, max_steps=budget, global_step=step,
                          best_step=best_step, best_score=best_score,
                          selection_metric='token_accuracy' if generation else 'recall',
                          scheduler_unit='step', eval_every_steps=interval,
                          early_stopping=False, final_lr=scheduler.get_last_lr(),
                          completed_traversals=step // len(loader))
            (Path(trainer.model_save_path) / 'training_summary.json').write_text(
                json.dumps(result, indent=2) + '\n')
            print(f'[Vib2Mol] {stage} completed: {result}', flush=True)
    finally:
        if primary():
            trainer.writer.close()
