"""CLI entry point for EquiformerV3 OpenMolSpec benchmarks.

Training behavior lives in :mod:`benchmarks.trainers.equiformer`; batch-level
losses and metrics live in :mod:`benchmarks.engines.equiformer`.
"""

from __future__ import annotations

import argparse
import json
import os

from benchmarks.engines.base import PROGRESS_MODES, resolve_progress_mode
from benchmarks.trainers.equiformer import (
    MODE_TARGETS,
    PROPERTY_TARGETS,
    SPECTRUM_TARGETS,
    EquiformerTrainer,
    resolve_targets,
    run,
)

__all__ = [
    "EquiformerTrainer",
    "MODE_TARGETS",
    "PROPERTY_TARGETS",
    "SPECTRUM_TARGETS",
    "resolve_progress_mode",
    "resolve_targets",
    "run",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Train EquiformerV3 OpenMolSpec baselines"
    )
    parser.add_argument(
        "--task", choices=[*MODE_TARGETS, "structure2hessian", "structure2response", "structure2nmr"], default="structure2property"
    )
    parser.add_argument(
        "--targets",
        nargs="+",
        choices=list(PROPERTY_TARGETS + SPECTRUM_TARGETS) + ["Hi", "Hij", "dedipole", "depolar", "H", "C"],
        help="Explicit target heads; defaults to every target defined by --task",
    )
    parser.add_argument("--data-dir", default="benchmark_data/equiformer_v3")
    parser.add_argument("--output", default="reports/benchmark")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument('--max-steps', type=int)
    parser.add_argument('--eval-every-steps', type=int, default=2500)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=624)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(
        "--progress",
        choices=PROGRESS_MODES,
        default="auto",
        help="auto uses tqdm on a TTY and interval logs when output is piped",
    )
    parser.add_argument(
        "--progress-interval-seconds",
        type=float,
        default=30.0,
        help="Seconds between stable batch-progress messages in log mode",
    )
    parser.add_argument(
        "--backbone-override",
        default=None,
        help="JSON string overriding backbone kwargs",
    )
    parser.add_argument(
        "--evaluate-only",
        action="store_true",
        help="Evaluate the checkpoint already present in --output",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Run one epoch on deterministic subsets without saving a checkpoint",
    )
    parser.add_argument("--debug-train-samples", type=int, default=512)
    parser.add_argument("--debug-eval-samples", type=int, default=128)
    parser.add_argument("--debug-test-samples", type=int, default=128)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    runner = run
    if args.task in ("structure2hessian", "structure2response", "structure2nmr"):
        from benchmarks.trainers.hessian import run as runner
    step_args = {}
    if args.task in ('structure2hessian', 'structure2response', 'structure2nmr'):
        step_args = dict(max_steps=args.max_steps, eval_every_steps=args.eval_every_steps)
    elif args.max_steps is not None:
        raise ValueError('Step training currently supports Hessian/response tasks')
    summary = runner(
        **step_args,
        task=args.task,
        data_dir=args.data_dir,
        output=args.output,
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        weight_decay=args.weight_decay,
        seed=args.seed,
        device=args.device,
        workers=args.workers,
        backbone_override=args.backbone_override,
        evaluate_only=args.evaluate_only,
        targets=args.targets,
        progress=args.progress,
        progress_interval_seconds=args.progress_interval_seconds,
        debug=args.debug,
        debug_train_samples=args.debug_train_samples,
        debug_eval_samples=args.debug_eval_samples,
        debug_test_samples=args.debug_test_samples,
    )
    if int(os.environ.get("RANK", "0")) == 0:
        print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
