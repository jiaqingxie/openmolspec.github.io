"""Run pinned Vib2Mol training with isolated outputs and visible failures.

Executed as the run workspace's main.py; upstream files remain unchanged.
"""
import importlib.util
import argparse
import os
from pathlib import Path
import sys
import time
import uuid
import json


NMR_NUCLEI = {
    'ir-raman-hnmr': ('h',),
    'ir-raman-nmr': ('c', 'h'),
}


def install_adapters(modality=None, nmr_normalizer=None):
    # The registry's lowercase `vib2mol` entry is a factory, not an nn.Module
    # class. Patch the class instantiated by that factory before DDP wraps it.
    from models.vib2mol import Vib2Mol
    from benchmarks.models.vib2mol.contrastive import contrastive_loss
    from benchmarks.models.vib2mol.lifecycle import install
    from benchmarks.models.vib2mol.kv_cache import install as install_kv_cache
    from benchmarks.models.vib2mol.matching import install as install_matching
    from benchmarks.models.vib2mol.factory import install_vib2mol_factory
    install()
    install_kv_cache(Vib2Mol)
    Vib2Mol.compute_cl_loss = contrastive_loss
    install_matching(Vib2Mol)
    if modality is not None:
        import models
        base_factory = getattr(models, '_openmolspec_base_vib2mol_factory', None)
        if base_factory is None:
            base_factory = models.get_model_class('vib2mol')
            models._openmolspec_base_vib2mol_factory = base_factory
        multimodal_class = None
        if modality in NMR_NUCLEI:
            if nmr_normalizer is None:
                raise ValueError(f'{modality} requires nmr_normalizer.json')
            from benchmarks.models.vib2mol.multimodal import MultimodalVib2Mol
            multimodal_class = MultimodalVib2Mol
            MultimodalVib2Mol.compute_cl_loss = contrastive_loss
        install_vib2mol_factory(
            models.model_registry,
            modality,
            upstream_factory=base_factory,
            multimodal_model_class=multimodal_class,
            nmr_normalizer=nmr_normalizer,
        )
    if modality in NMR_NUCLEI:
        from benchmarks.models.vib2mol.nmr_data import install as install_data
        install_data(nmr_normalizer['reference_id'], nuclei=NMR_NUCLEI[modality])


def run():
    adapter = argparse.ArgumentParser(add_help=False)
    adapter.add_argument('--max-steps', type=int)
    adapter.add_argument('--eval-every-steps', type=int, default=2500)
    adapter.add_argument('--debug-step-budget', action='store_true')
    adapter.add_argument('--hc-nmr', action='store_true')
    adapter.add_argument('--spectroscopy-modality',
                         choices=('ir', 'raman', 'ir-raman',
                                  'ir-raman-hnmr', 'ir-raman-nmr'))
    step_args, remaining = adapter.parse_known_args()
    if step_args.max_steps is not None:
        if step_args.max_steps < 1 or step_args.eval_every_steps < 1:
            adapter.error('Step budgets must be positive')
        if '--epoch' in remaining:
            adapter.error('Use steps or epochs, not both')
        remaining.extend(['--epoch', '1'])  # Legacy scheduler is replaced below.
    sys.argv = [sys.argv[0], *remaining]
    upstream = Path(__file__).resolve().parent / 'upstream'
    sys.path.insert(0, str(upstream))
    spec = importlib.util.spec_from_file_location('vib2mol_upstream_main', upstream / 'main.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Import the maintained adapter without relying on the subprocess cwd.
    repository = Path(__file__).resolve().parents[3]
    sys.path.insert(0, str(repository))
    modality = step_args.spectroscopy_modality
    if step_args.hc_nmr:
        if modality not in (None, 'ir-raman-nmr'):
            adapter.error('--hc-nmr conflicts with --spectroscopy-modality')
        modality = 'ir-raman-nmr'
    normalizer = (json.loads(Path('nmr_normalizer.json').read_text())
                  if modality in NMR_NUCLEI else None)
    install_adapters(modality, normalizer)
    args = module.get_args_parser()
    module.args = args
    module.device = module.init_device()
    rank = int(os.environ.get('LOCAL_RANK', 0)) if args.ddp else 0
    module.seed_everything(int(args.seed))
    module.ts = time.strftime('%Y-%m-%d-%H-%M')
    module.random_id = uuid.uuid4().hex[:6]
    model, params, phase = module.init_model(rank)
    if step_args.max_steps is not None:
        params.update(max_steps=step_args.max_steps,
                      eval_every_steps=step_args.eval_every_steps,
                      debug_step_budget=step_args.debug_step_budget)
    import torch.distributed as dist
    if dist.is_initialized():
        identity = [module.ts, module.random_id]
        dist.broadcast_object_list(identity, src=0)
        module.ts, module.random_id = identity
    module.init_logs(rank)
    # One-epoch smoke runs must not spend the entire run below the warmup LR.
    params['warmup_epochs'] = min(params['warmup_epochs'], max(params['epoch'] - 1, 0))
    save_path = f'checkpoints/{args.ds}/{args.task}/{args.model}/{module.ts}-{module.random_id}'
    module.trainers.launch_training(
        args.launch, model=model, lmdb_path=args.ds, task=args.task,
        tokenizer_path='./models/MolTokenizer', data_dir='./datasets/vibench',
        model_save_path=save_path, device=module.device, ddp=args.ddp,
        rank=rank, config=params, phase=phase, smiles_augment=args.smiles_augment,
        spectra_augment=args.spectra_augment, use_yield=args.use_yield,
        use_residue=args.use_residue,
    )


def main():
    import torch.distributed as dist
    try:
        run()
    finally:
        # No barrier here: another rank may already have failed.
        if dist.is_initialized():
            dist.destroy_process_group()


if __name__ == '__main__':
    main()
