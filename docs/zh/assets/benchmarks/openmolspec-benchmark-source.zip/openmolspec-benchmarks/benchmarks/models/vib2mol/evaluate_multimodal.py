"""Checkpoint-based H/C-aware retrieval and beam-generation test evaluation."""
import argparse
import json
from pathlib import Path
import sys

import torch
import torch.nn.functional as F
from tqdm import tqdm


NMR_MODALITIES = {'ir-raman-hnmr', 'ir-raman-nmr'}


def spectral_fields(modality):
    """Return the vibrational channels physically present in one modality."""
    if modality == 'ir':
        return ['ir']
    if modality == 'raman':
        return ['raman']
    return ['ir', 'raman']


def encode_spectra(model, inputs):
    """Normalize upstream and H/C-aware spectral encoder interfaces."""
    if hasattr(model, 'encode_spectra'):
        return model.encode_spectra(inputs)
    spectra = model.load_spectra(inputs)
    output = model.spectral_encoder(model.spectral_encoding(spectra))
    mask = output.get('mask')
    if mask is None:
        mask = torch.ones(output['hidden_states'].shape[:2], dtype=torch.bool,
                          device=output['hidden_states'].device)
    return dict(hidden_states=output['hidden_states'], mask=mask,
                proj_output=output['proj_output'])


def canonical(smiles):
    from rdkit import Chem, rdBase
    with rdBase.BlockLogs():
        mol = Chem.MolFromSmiles(smiles)
    # Matching was trained with Kekule strings, not aromatic lowercase strings.
    return (Chem.MolToSmiles(mol, isomericSmiles=True, kekuleSmiles=True)
            if mol is not None and mol.GetNumAtoms() and
            all(atom.GetAtomicNum() > 0 for atom in mol.GetAtoms()) else None)


def unique_candidates(smiles):
    """Canonicalize and remove duplicate valid molecules, preserving beam order."""
    return list(dict.fromkeys(value for value in map(canonical, smiles) if value is not None))


@torch.no_grad()
def rerank_candidates(model, tokenizer, spectral_input, candidates, batch_size=32):
    """One spectrum versus candidate strings; reuse H/C-aware spectral memory.

    ITM label 1 is positive in training. Rank by its probability, not the raw
    positive logit. No contrastive loss or random negative sampling is involved.
    """
    if not candidates:
        return [], []
    spectra = encode_spectra(model, spectral_input)
    device = spectra['hidden_states'].device
    scores = []
    for start in range(0, len(candidates), batch_size):
        strings = candidates[start:start+batch_size]
        tokens = tokenizer(strings, padding=True, truncation=False, return_tensors='pt')
        if tokens['input_ids'].shape[1] > tokenizer.model_max_length:
            raise ValueError('Rerank candidate exceeds tokenizer limit; refusing silent truncation')
        if (tokens['input_ids'] == tokenizer.unk_token_id).any():
            raise ValueError('Unknown token in rerank candidate')
        ids = tokens['input_ids'].to(device)
        mask = tokens['attention_mask'].to(device)
        mask = torch.cat((mask.new_ones((len(ids), 1)), mask), 1)
        logits = model.molecular_encoder(
            model.molecular_encoding(ids, use_cls_token=True),
            memory=spectra['hidden_states'].expand(len(ids), -1, -1),
            src_mask=spectra['mask'].expand(len(ids), -1),
            tgt_mask=mask, multimodal=True)['proj_output']
        scores.extend(logits.softmax(-1)[:, 1].cpu().tolist())
    order = sorted(range(len(candidates)), key=lambda i: -scores[i])
    return order, [scores[i] for i in order]


def spectrum_row(data, index):
    return {key: value[index:index+1] for key, value in data.items()
            if key in ('ir', 'raman') or key.startswith('nmr_')}


@torch.no_grad()
def run(args):
    sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
    sys.path.insert(0, str(Path(__file__).resolve().parent/'upstream'))
    from benchmarks.models.vib2mol.train_entry import install_adapters
    from utils.dataloader import Dataloader
    from utils.collators import BaseCollator
    from models import build_model
    normalizer = (json.loads(Path('nmr_normalizer.json').read_text())
                  if args.modality in NMR_MODALITIES else None)
    install_adapters(args.modality, normalizer)
    phase = 1 if args.action == 'retrieval-eval' else 2
    model = build_model('vib2mol', phase=phase)
    state = torch.load(args.test_model_path, map_location='cpu', weights_only=True)
    state = {k.removeprefix('module.'):v for k,v in state.items()}
    model.load_state_dict(state)
    model.to(args.device).eval()
    spectra_keys = spectral_fields(args.modality)
    keys = spectra_keys + ['kekule_smiles'] + (['formula'] if args.use_formula else [])
    collator = BaseCollator(tokenizer_path='models/MolTokenizer',
                            spectral_types=spectra_keys)
    source = Dataloader('openspec',data_dir='datasets/vibench',target_keys=keys,collate_fn=collator)
    loader = source.generate_dataloader(mode='test',batch_size=args.batch_size)
    # Ground truth must come from LMDB, not lossy/truncated tokenizer decoding.
    targets = [source.dataset[i]['smiles'] for i in range(len(source.dataset))]
    if not targets or any(canonical(s) is None for s in targets):
        raise ValueError('Empty test split or invalid target SMILES')
    rank_model = None
    if args.rerank:
        rank_model = build_model('vib2mol', phase=1)
        rank_state = torch.load(args.rank_model_path, map_location='cpu', weights_only=True)
        rank_state = {k.removeprefix('module.'): v for k, v in rank_state.items()}
        if args.modality in NMR_MODALITIES:
            # Both models must use exactly the same H/C reference and normalization.
            if rank_state.get('_extra_state') != state.get('_extra_state'):
                raise ValueError('Rerank checkpoint architecture/NMR reference differs')
            for key in ('spectral_encoding.center', 'spectral_encoding.scale'):
                if not torch.equal(rank_state[key], state[key]):
                    raise ValueError('Rerank checkpoint NMR normalization differs')
        rank_model.load_state_dict(rank_state)
        rank_model.to(args.device).eval()
    def move(batch):
        for key, value in batch.items():
            if torch.is_tensor(value):
                batch[key] = value.to(args.device)
            elif key in ('smiles','formula'):
                batch[key] = {k:v.to(args.device) for k,v in value.items()}
        return batch
    if phase == 1:
        molecules, spectra = [], []
        for batch in tqdm(loader,desc='Encode test retrieval'):
            data = move(batch['data'])
            mask = data['smiles']['attention_mask']
            mask = torch.cat((mask.new_ones((len(mask),1)),mask),1)
            molecule = model.molecular_encoder(model.molecular_encoding(
                data['smiles']['input_ids'],use_cls_token=True),mask=mask)['proj_output']
            molecules.append(F.normalize(molecule,dim=-1).cpu())
            spectra.append(F.normalize(encode_spectra(model, data)['proj_output'],dim=-1).cpu())
        molecules, spectra = torch.cat(molecules), torch.cat(spectra)
        result = dict(records=len(spectra),candidate_pool='entire test split',metrics={})
        for name, query, candidates in [('spectrum2molecule',spectra,molecules),('molecule2spectrum',molecules,spectra)]:
            hits = {k:0 for k in (1,3,5,10)}
            indices = []
            for start in range(0,len(query),256):
                scores = query[start:start+256] @ candidates.T
                top = scores.topk(min(max(10,args.topk),len(candidates)),dim=1).indices
                indices.append(top)
                correct = torch.arange(start,start+len(top))[:,None]
                for k in hits:
                    hits[k] += int((top[:,:k] == correct).any(1).sum())
            result['metrics'][name] = {f'recall@{k}':v/len(query) for k,v in hits.items()}
            if name == 'spectrum2molecule':
                retrieval_indices = torch.cat(indices)
        if rank_model is not None:
            hits = {k: 0 for k in (1, 3, 5, 10)}
            offset = 0
            with Path('rerank_predictions.jsonl').open('w') as handle:
                for batch in tqdm(loader, desc='Rerank spectrum-to-molecule'):
                    data = move(batch['data'])
                    for i in range(batch['batch_size']):
                        row = offset + i
                        candidate_ids = retrieval_indices[row, :args.topk].tolist()
                        order, scores = rerank_candidates(rank_model, collator.tokenizer,
                            spectrum_row(data, i), [targets[j] for j in candidate_ids],
                            args.rerank_batch_size)
                        ranked = ([candidate_ids[j] for j in order] +
                                  retrieval_indices[row, args.topk:].tolist())
                        for k in hits:
                            hits[k] += row in ranked[:k]
                        handle.write(json.dumps(dict(index=row, target=targets[row],
                            candidate_indices=candidate_ids, ranked_indices=ranked,
                            positive_probabilities=scores))+'\n')
                    offset += batch['batch_size']
            result['metrics']['spectrum2molecule_reranked'] = {
                f'recall@{k}': value/len(targets) for k, value in hits.items()}
            result['rerank_candidate_count'] = min(args.topk, len(targets))
    else:
        hits = {k:0 for k in sorted({1, args.beam_size, *[k for k in (3,5,10) if k <= args.beam_size]})}
        rank_hits = dict.fromkeys(hits, 0)
        valid, candidates, count = 0,0,0
        duplicates = 0
        with Path('generation_predictions.jsonl').open('w') as handle:
            for batch in tqdm(loader,desc='Generate test SMILES'):
                data = move(batch['data'])
                beams = model.beam_infer_lm(data,beam_size=args.beam_size,max_len=args.max_length)['pred_ids']
                if len(beams) != batch['batch_size']:
                    raise ValueError('Beam batch count mismatch')
                for i, sequences in enumerate(beams):
                    target = canonical(targets[count])
                    raw = [collator.tokenizer.decode(x,skip_special_tokens=True).replace(' ','') for x in sequences]
                    valid_count = sum(canonical(x) is not None for x in raw)
                    predicted = unique_candidates(raw)
                    duplicates += valid_count - len(predicted)
                    valid += valid_count
                    candidates += len(raw)
                    ranked, scores = [], []
                    if rank_model is not None:
                        order, scores = rerank_candidates(rank_model, collator.tokenizer,
                            spectrum_row(data, i), predicted[:args.topk], args.rerank_batch_size)
                        ranked = [predicted[j] for j in order] + predicted[args.topk:]
                    for k in hits:
                        hits[k] += target in predicted[:k]
                        rank_hits[k] += target in ranked[:k]
                    handle.write(json.dumps(dict(index=count, target=targets[count],
                        raw_beams=raw, unique_candidates=predicted, reranked=ranked,
                        positive_probabilities=scores))+'\n')
                    count += 1
        result = dict(records=count,beam_size=args.beam_size,
                      valid_smiles_fraction=valid/max(candidates,1),
                      duplicate_valid_beams=duplicates,
                      **{f'exact_canonical_top{k}':v/count for k,v in hits.items()})
        if rank_model is not None:
            result['reranked'] = {f'exact_canonical_top{k}':v/count for k,v in rank_hits.items()}
    if args.rerank:
        result['rank_checkpoint'] = str(Path(args.rank_model_path).resolve())
        result['rerank_score'] = 'ITM softmax positive-class probability'
    result.update(action=args.action,checkpoint=str(Path(args.test_model_path).resolve()),
                  modality=args.modality, target_field='kekule_smiles',
                  identity_policy='canonical isomeric SMILES; stereo absent in source cannot be evaluated',
                  max_length=args.max_length)
    Path('test_metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--action',choices=['retrieval-eval','generation-eval'],required=True)
    p.add_argument('--modality', choices=['ir', 'raman', 'ir-raman',
                                          'ir-raman-hnmr', 'ir-raman-nmr'],
                   default='ir-raman-nmr')
    p.add_argument('--test_model_path',required=True)
    p.add_argument('--device',default='cuda:0')
    p.add_argument('--beam_size',type=int,default=10)
    p.add_argument('--use_formula',action='store_true')
    p.add_argument('--rerank',action='store_true')
    p.add_argument('--rank_model_path')
    p.add_argument('--topk',type=int,default=10)
    p.add_argument('--batch-size',type=int,default=32)
    p.add_argument('--rerank-batch-size',type=int,default=32)
    p.add_argument('--max-length',type=int,default=300)
    a=p.parse_args()
    if min(a.beam_size,a.topk,a.batch_size,a.rerank_batch_size) < 1 or a.max_length < 2:
        p.error('Sizes must be positive and max-length >= 2')
    if a.rerank and not a.rank_model_path:
        p.error('--rerank requires --rank_model_path')
    print(json.dumps(run(a),indent=2))


if __name__ == '__main__':
    main()
