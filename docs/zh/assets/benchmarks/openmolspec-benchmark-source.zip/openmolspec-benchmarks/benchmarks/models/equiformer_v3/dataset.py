"""PyG dataset over the prepared EquiformerV3 LMDB files."""

import os
import pickle
from pathlib import Path
from typing import List, Optional

import lmdb
import torch
from torch.utils.data import Dataset
from torch_geometric.data import Batch, Data


class OpenSpecLmdbDataset(Dataset):
    """Reads PyG ``Data`` objects stored in an LMDB keyed by sample_id."""

    def __init__(self, lmdb_path: str) -> None:
        self.lmdb_path = str(lmdb_path)
        env = lmdb.open(
            self.lmdb_path, subdir=False, readonly=True, lock=False,
            readahead=False, meminit=False, max_readers=256,
        )
        with env.begin() as transaction:
            self._keys = list(transaction.cursor().iternext(values=False))
        env.close()
        self._env: Optional[lmdb.Environment] = None
        self._env_pid: Optional[int] = None

    def _worker_env(self) -> lmdb.Environment:
        """Return an LMDB environment owned by the current process."""

        pid = os.getpid()
        if self._env is None or self._env_pid != pid:
            if self._env is not None:
                self._env.close()
            self._env = lmdb.open(
                self.lmdb_path, subdir=False, readonly=True, lock=False,
                readahead=False, meminit=False, max_readers=256,
            )
            self._env_pid = pid
        return self._env

    def __len__(self) -> int:
        return len(self._keys)

    def __getitem__(self, index: int) -> Data:
        with self._worker_env().begin() as transaction:
            payload = transaction.get(self._keys[index])
        data = pickle.loads(payload)
        return data

    def __getstate__(self):
        state = self.__dict__.copy()
        state["_env"] = None
        state["_env_pid"] = None
        return state

    def __del__(self) -> None:
        env = getattr(self, "_env", None)
        if env is not None:
            env.close()

    def collate(self, batch: List[Data]) -> Batch:
        return Batch.from_data_list(batch)
