"""CLI adapter for shared-Transformer spectrum-to-property regression.

The model, engine and trainer are deliberately separate so this module only
translates command-line arguments into one reproducible training run.
"""

from __future__ import annotations

import argparse
import json

from benchmarks.engines.base import PROGRESS_MODES
from benchmarks.models.vib2conf.dataset import PROPERTY_FIELDS
from benchmarks.models.vib2conf.model import SpectralPropsModel
from benchmarks.trainers.vib2conf import Vib2ConfPropertyTrainer, run

__all__ = [
    "PROPERTY_FIELDS",
    "SpectralPropsModel",
    "Vib2ConfPropertyTrainer",
    "run",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Train the shared spectroscopy Transformer property baseline"
    )
    parser.add_argument("--data-dir", default="benchmark_data/vib2conf")
    parser.add_argument("--output", default="reports/benchmark")
    parser.add_argument(
        "--targets",
        nargs="+",
        choices=list(PROPERTY_FIELDS),
        help="Explicit property heads; defaults to all available properties",
    )
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--loss-beta", type=float, default=1.0)
    parser.add_argument("--max-steps", type=int)
    parser.add_argument("--eval-every-steps", type=int, default=2500)
    parser.add_argument("--modality", choices=("ir", "raman", "ir-raman", "ir-raman-nmr"), default="ir-raman-nmr")
    parser.add_argument("--model-config", type=json.loads, default={})
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--lr", type=float, default=5e-5)
    parser.add_argument("--weight-decay", type=float, default=1e-2)
    parser.add_argument("--seed", type=int, default=624)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--progress", choices=PROGRESS_MODES, default="auto")
    parser.add_argument("--progress-interval-seconds", type=float, default=30.0)
    parser.add_argument(
        "--no-concat-spectrum",
        action="store_true",
        help="Use a single spectral modality input",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Run one epoch on deterministic subsets without saving a checkpoint",
    )
    parser.add_argument("--debug-train-samples", type=int, default=512)
    parser.add_argument("--debug-eval-samples", type=int, default=128)
    parser.add_argument("--debug-test-samples", type=int, default=128)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    summary = run(
        data_dir=args.data_dir,
        output=args.output,
        epochs=args.epochs,
        loss_beta=args.loss_beta,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        weight_decay=args.weight_decay,
        seed=args.seed,
        device=args.device,
        workers=args.workers,
        concat_spectrum=not args.no_concat_spectrum and args.modality in ("ir-raman", "ir-raman-nmr"),
        modality=args.modality,
        max_steps=args.max_steps,
        eval_every_steps=args.eval_every_steps,
        targets=args.targets,
        model_parameters=args.model_config,
        progress=args.progress,
        progress_interval_seconds=args.progress_interval_seconds,
        debug=args.debug,
        debug_train_samples=args.debug_train_samples,
        debug_eval_samples=args.debug_eval_samples,
        debug_test_samples=args.debug_test_samples,
    )
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
