"""Edge attention output adapted from pinned EquiformerV3 and Harmony.

Uses Harmony return_edge_message semantics: project the rotated-back edge
message without the destination-node sum. See docs/plans/hessian_training.md.
"""

import torch
from experimental.models.equiformer_v3.transformer_block import EquivariantGraphAttention
from experimental.models.equiformer_v3.activation import (
    has_scalars, prepare_activation_forward_param,
)


class HessianEdgeHead(EquivariantGraphAttention):
    def forward(
        self,
        x,
        source_atomic_numbers,
        target_atomic_numbers,
        edge_distance,
        edge_index,
        edge_envelope_weight=None
    ):
        num_nodes = x.shape[0]

        # Compute edge scalar features (invariant to rotations)
        # Uses atomic numbers and edge distance as inputs
        if self.use_atom_edge_embedding:
            #source_element = atomic_numbers[edge_index[0]]  # Source atom atomic number
            #target_element = atomic_numbers[edge_index[1]]  # Target atom atomic number
            source_embedding = self.source_embedding(source_atomic_numbers)
            target_embedding = self.target_embedding(target_atomic_numbers)
            x_edge = torch.cat((edge_distance, source_embedding, target_embedding), dim=1)
        else:
            x_edge = edge_distance

        # Radial function
        x_edge_weight = self.rad_func(x_edge)

        # Merge source/target node features
        x = x.to(x_edge_weight.dtype)
        x_source = torch.index_select(x, index=edge_index[0], dim=0)
        x_target = torch.index_select(x, index=edge_index[1], dim=0)
        if not self.use_add_merge:
            # Concat
            x_message = torch.cat((x_source, x_target), dim=2)
            if self.use_rad_l_parametrization:
                x_message = x_message * x_edge_weight
                x_message = self.so3_rotation.rotate(x_message)
            else:
                x_message = self.so3_rotation.rotate(x_message)
                x_message = x_message * x_edge_weight
        elif self.use_add_merge:
            # Add
            x_edge_weight_source = x_edge_weight.narrow(2, 0, self.num_in_channels)
            x_edge_weight_target = x_edge_weight.narrow(2, self.num_in_channels, self.num_in_channels)
            x_source = x_source * x_edge_weight_source
            x_target = x_target * x_edge_weight_target
            x_message = x_source + x_target
            x_message = self.so3_rotation.rotate(x_message)

        x_message, x_m0_extra = self.so2_linear_1(x_message)

        # S2/gate activation
        if has_scalars(self.activation):
            x_alpha  = x_m0_extra.narrow(1, 0, self.split_m0_channels_list[0])
            x_scalar = x_m0_extra.narrow(1, self.split_m0_channels_list[0], self.split_m0_channels_list[1])
        else:
            x_alpha  = x_m0_extra
            x_scalar = None
        act_input_dict = prepare_activation_forward_param(
            act_name=self.activation,
            inputs=x_message,
            scalars=x_scalar
        )
        x_message = self.act(**act_input_dict)

        x_message = self.so2_linear_2(x_message)

        # Graph attention
        x_alpha = x_alpha.view(-1, self.num_heads, self.attn_alpha_channels)
        x_alpha = self.alpha_norm(x_alpha)
        x_alpha = self.alpha_act(x_alpha)
        x_alpha = self.alpha_dropout(x_alpha)
        alpha = torch.einsum('bik, ik -> bi', x_alpha, self.alpha_dot)
        #alpha = torch_geometric.utils.softmax(alpha, edge_index[1], num_nodes=num_nodes)
        alpha = self.attn_softmax(alpha, edge_index[1], num_nodes=num_nodes, exp_rescale=edge_envelope_weight)
        if edge_envelope_weight is not None:
            alpha = alpha * edge_envelope_weight
        alpha = alpha.view(alpha.shape[0], 1, self.num_heads, 1)
        alpha = self.attn_weights_dropout(alpha)
        if torch.is_autocast_enabled():
            alpha = alpha.to(torch.float16)

        # Attention weights * non-linear messages
        attn = x_message
        attn = attn.view(attn.shape[0], attn.shape[1], self.num_heads, self.attn_value_channels)
        attn = attn * alpha
        attn = attn.view(attn.shape[0], attn.shape[1], self.num_heads * self.attn_value_channels)
        x_message = attn

        # Rotate back the irreps
        x_message = self.so3_rotation.rotate_inv(x_message)

        # Harmony Hij: project edges before destination aggregation.
        outputs = self.proj(x_message)

        return outputs
