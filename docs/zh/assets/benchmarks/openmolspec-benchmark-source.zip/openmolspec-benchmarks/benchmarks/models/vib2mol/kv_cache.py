"""Incremental Vib2Mol decoding adapted from the maintained vib2mol-v1 path.

This module deliberately lives outside the pinned upstream tree.  It adds no
parameters or buffers, so existing training checkpoints remain byte-compatible.
"""
from __future__ import annotations

import math

import torch
import torch.nn.functional as F


def _attention(attention, query, key, value, cache=None, mask=None,
               static_kv=False):
    """Project one query token and retain projected self/cross-attention K/V."""
    if mask is not None:
        mask = mask.unsqueeze(1)
    batch = query.size(0)
    query = attention.linears[0](query).view(
        batch, -1, attention.h, attention.d_k).transpose(1, 2)
    if static_kv and cache is not None:
        key, value = cache['key'], cache['value']
    else:
        key = attention.linears[1](key).view(
            batch, -1, attention.h, attention.d_k).transpose(1, 2)
        value = attention.linears[2](value).view(
            batch, -1, attention.h, attention.d_k).transpose(1, 2)
        if cache is not None and not static_kv:
            key = torch.cat((cache['key'], key), dim=2)
            value = torch.cat((cache['value'], value), dim=2)
    scores = query @ key.transpose(-2, -1) / math.sqrt(attention.d_k)
    if mask is not None:
        if mask.dim() == scores.dim() - 1:
            mask = mask.unsqueeze(1)
        scores = scores.masked_fill(mask == 0, -1e9)
    probabilities = F.softmax(scores, dim=-1)
    probabilities = attention.dropout(probabilities)
    attention.attn = probabilities
    output = probabilities @ value
    output = output.transpose(1, 2).contiguous().view(
        batch, -1, attention.h * attention.d_k)
    return attention.linears[-1](output), {'key': key, 'value': value}


def decoder_step(decoder, input_embedding, memory, src_mask, cache=None):
    """Run one autoregressive token through all decoder layers."""
    cache = cache or [None] * len(decoder.layers)
    output, new_cache = input_embedding, []
    for layer, layer_cache in zip(decoder.layers, cache):
        layer_cache = layer_cache or {}
        normalized = layer.sublayer[0].norm(output)
        attended, self_cache = _attention(
            layer.self_attn, normalized, normalized, normalized,
            layer_cache.get('self'), static_kv=False)
        output = output + layer.sublayer[0].dropout(attended)
        normalized = layer.sublayer[1].norm(output)
        attended, source_cache = _attention(
            layer.src_attn, normalized, memory, memory,
            layer_cache.get('src'), mask=src_mask, static_kv=True)
        output = output + layer.sublayer[1].dropout(attended)
        output = layer.sublayer[2](output, layer.feed_forward)
        new_cache.append({'self': self_cache, 'src': source_cache})
    return decoder.proj(decoder.norm(output)), new_cache


def embed_token(model, token, position):
    """Embed a single token at its absolute position without changing upstream."""
    encoding = model.molecular_encoding
    output = encoding.molecular_embedding(token)
    mask = (token == 4).unsqueeze(-1)
    output = torch.where(mask, encoding.mask_token, output)
    positional = encoding.positional_encoding
    output = output + positional.pe[:, position:position + output.size(1)]
    return positional.dropout(output)


def expand_cache(cache, beam_size):
    return [
        {kind: {name: tensor.repeat_interleave(beam_size, dim=0)
                for name, tensor in values.items()}
         for kind, values in layer.items()}
        for layer in cache
    ]


def reorder_cache(cache, indices):
    return [
        {kind: {name: tensor.index_select(0, indices)
                for name, tensor in values.items()}
         for kind, values in layer.items()}
        for layer in cache
    ]


def generation_memory(model, inputs):
    """Build encoder memory for the upstream IR/Raman-only model."""
    spectra = model.load_spectra(inputs)
    embedded = model.spectral_encoding(spectra)
    encoded = model.spectral_encoder(embedded)
    memory = encoded['hidden_states']
    src_mask = torch.ones(memory.shape[:2], dtype=torch.bool, device=memory.device)
    if 'formula' in inputs:
        formula = inputs['formula']
        memory = torch.cat(
            (memory, model.formula_encoding(formula['input_ids'])), 1)
        src_mask = torch.cat((src_mask, formula['attention_mask'].bool()), 1)
        memory = model.multimodal_encoder(memory, src_mask)['hidden_states']
    return memory, src_mask


def greedy_decode(model, memory, src_mask, batch_size, max_len,
                  return_metrics=False, target_ids=None):
    pred_ids = torch.zeros(batch_size, 1, dtype=torch.long, device=memory.device)
    cache = None
    for position in range(max_len - 1):
        embedding = embed_token(model, pred_ids[:, -1:], position)
        logits, cache = decoder_step(
            model.molecular_decoder, embedding, memory, src_mask, cache)
        pred_ids = torch.cat((pred_ids, logits[:, -1].argmax(-1, keepdim=True)), 1)
    result = {'pred_ids': pred_ids}
    if return_metrics:
        if target_ids is None or target_ids.shape != pred_ids.shape:
            raise ValueError('target_ids must match generated shape')
        valid = target_ids != 1
        result['metrics'] = (pred_ids[valid] == target_ids[valid]).sum() / valid.sum()
    return result


def beam_decode(model, memory, src_mask, batch_size, max_len, beam_size,
                temperature):
    device = memory.device
    sequences = torch.zeros(batch_size, 1, dtype=torch.long, device=device)
    logits, cache = decoder_step(
        model.molecular_decoder, embed_token(model, sequences, 0),
        memory, src_mask, cache=None)
    log_probs = F.log_softmax(logits[:, -1] / temperature, dim=-1)
    beam_scores, next_tokens = log_probs.topk(beam_size, dim=-1)
    sequences = sequences.unsqueeze(1).repeat(1, beam_size, 1)
    sequences = torch.cat((sequences, next_tokens.unsqueeze(-1)), -1)

    memory = memory.repeat_interleave(beam_size, 0)
    src_mask = src_mask.repeat_interleave(beam_size, 0)
    cache = expand_cache(cache, beam_size)
    finished = [[] for _ in range(batch_size)]
    for _ in range(max_len - 2):
        latest = sequences[:, :, -1].reshape(batch_size * beam_size, 1)
        embedding = embed_token(model, latest, sequences.size(-1) - 1)
        logits, next_cache = decoder_step(
            model.molecular_decoder, embedding, memory, src_mask, cache)
        log_probs = F.log_softmax(logits[:, -1] / temperature, dim=-1)
        vocabulary = log_probs.size(-1)
        scores = beam_scores.unsqueeze(-1) + log_probs.view(
            batch_size, beam_size, vocabulary)
        beam_scores, indices = scores.view(batch_size, -1).topk(beam_size, -1)
        parents, tokens = indices // vocabulary, indices % vocabulary
        sequences = sequences.gather(
            1, parents.unsqueeze(-1).expand(-1, -1, sequences.size(-1)))
        sequences = torch.cat((sequences, tokens.unsqueeze(-1)), -1)
        offsets = torch.arange(batch_size, device=device).unsqueeze(1) * beam_size
        flat_parents = (parents + offsets).reshape(-1)
        cache = reorder_cache(next_cache, flat_parents)
        memory = memory.index_select(0, flat_parents)
        src_mask = src_mask.index_select(0, flat_parents)
        for batch_index in range(batch_size):
            for beam_index in range(beam_size):
                if sequences[batch_index, beam_index, -1].item() == 2:
                    finished[batch_index].append((
                        beam_scores[batch_index, beam_index].item(),
                        sequences[batch_index, beam_index].clone()))
                    beam_scores[batch_index, beam_index] = -1e9
        if all(len(outputs) >= beam_size for outputs in finished):
            break
    for batch_index in range(batch_size):
        for beam_index in range(beam_size):
            if (sequences[batch_index, beam_index, -1].item() != 2 and
                    beam_scores[batch_index, beam_index].item() != -1e9):
                finished[batch_index].append((
                    beam_scores[batch_index, beam_index].item(),
                    sequences[batch_index, beam_index].clone()))
        finished[batch_index] = sorted(
            finished[batch_index], key=lambda item: item[0], reverse=True
        )[:beam_size]
    return {
        'pred_ids': [[item[1] for item in outputs] for outputs in finished],
        'score': [[item[0] for item in outputs] for outputs in finished],
    }


def install(model_class):
    """Install cached generation on the pinned upstream Vib2Mol class."""
    if model_class.__dict__.get('_openmolspec_kv_cache_installed', False):
        return
    model_class._infer_lm_uncached = model_class.infer_lm
    model_class._beam_infer_lm_uncached = model_class.beam_infer_lm

    @torch.no_grad()
    def infer_lm(self, inputs, max_len=256, return_metrics=False,
                 target_ids=None):
        memory, src_mask = generation_memory(self, inputs)
        return greedy_decode(
            self, memory, src_mask, memory.size(0), max_len,
            return_metrics=return_metrics, target_ids=target_ids)

    @torch.no_grad()
    def beam_infer_lm(self, inputs, max_len=256, beam_size=3,
                      temperature=1.0):
        if max_len < 2 or beam_size < 1 or temperature <= 0:
            raise ValueError(
                'max_len >= 2, beam_size >= 1 and temperature > 0 required')
        memory, src_mask = generation_memory(self, inputs)
        return beam_decode(
            self, memory, src_mask, memory.size(0), max_len, beam_size,
            temperature)

    model_class.infer_lm = infer_lm
    model_class.beam_infer_lm = beam_infer_lm
    model_class._openmolspec_kv_cache_installed = True
