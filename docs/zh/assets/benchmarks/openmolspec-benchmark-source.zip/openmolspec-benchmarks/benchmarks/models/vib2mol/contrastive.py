"""Autograd-aware global negatives for the pinned Vib2Mol matching model."""
import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch.distributed.nn.functional import all_gather


def contrastive_loss(self, molecular_output, spectral_output, return_sim=False,
                     global_negatives=False):
    """Local anchors against global keys, optionally returning global ITM logits.

    Collectives are training-only: upstream validation iterates the complete
    validation set on each rank. Gathering there would duplicate positives.
    """
    molecule = F.normalize(molecular_output, dim=1)
    spectrum = F.normalize(spectral_output, dim=1)
    if molecule.shape != spectrum.shape or not len(molecule):
        raise ValueError('Paired nonempty molecular/spectral embeddings required')
    scale = self.logit_scale.exp()
    local_logits = molecule @ spectrum.T * scale
    distributed = self.training and dist.is_initialized() and dist.get_world_size() > 1
    if distributed:
        size = torch.tensor([len(molecule)], device=molecule.device, dtype=torch.long)
        sizes = [torch.empty_like(size) for _ in range(dist.get_world_size())]
        dist.all_gather(sizes, size)
        counts = [int(value.item()) for value in sizes]
        maximum = max(counts)

        def gather_embeddings(value):
            padded = F.pad(value, (0, 0, 0, maximum - len(value)))
            return torch.cat([part[:n] for part, n in zip(all_gather(padded), counts)])

        all_molecule = gather_embeddings(molecule)
        all_spectrum = gather_embeddings(spectrum)
        offset = sum(counts[:dist.get_rank()])
        labels = torch.arange(len(molecule), device=molecule.device) + offset
        logits_m2s = molecule @ all_spectrum.T * scale
        logits_s2m = spectrum @ all_molecule.T * scale
        loss = (F.cross_entropy(logits_m2s, labels)
                + F.cross_entropy(logits_s2m, labels)) / 2
        # DDP averages parameter gradients; weight local means by sample count.
        loss = loss * (dist.get_world_size() * len(molecule) / sum(counts))
    else:
        labels = torch.arange(len(molecule), device=molecule.device)
        loss = (F.cross_entropy(local_logits, labels)
                + F.cross_entropy(local_logits.T, labels)) / 2
    if return_sim:
        if distributed and global_negatives:
            return loss, logits_m2s, logits_s2m
        # Compatibility for callers that still index local token sequences.
        return loss, local_logits, local_logits.T
    return loss
