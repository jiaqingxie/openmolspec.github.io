"""EquiformerV3 baselines for structure->property and structure->spectrum."""

from .model import OpenSpecEquiformerV3

__all__ = ["OpenSpecEquiformerV3"]
