"""Atom-level invariant H/C shifts, without molecular pooling."""
import torch
from .model import OpenSpecEquiformerV3


class AtomNMRModel(OpenSpecEquiformerV3):
    def __init__(self, targets=('H', 'C'), backbone=None):
        super().__init__(property_targets=(), spectrum_targets=(), backbone=backbone)
        self.heads = torch.nn.ModuleDict({t: torch.nn.Sequential(
            torch.nn.LayerNorm(self.backbone.num_channels),
            torch.nn.Linear(self.backbone.num_channels, 128), torch.nn.SiLU(),
            torch.nn.Linear(128, 1)) for t in targets})

    def forward(self, data):
        b = self.backbone
        b.batch_size = data.num_graphs
        b.dtype, b.device = data.pos.dtype, data.pos.device
        edges = data.edge_index
        z = data.atomic_numbers.long()
        positions = data.pos
        batch = data.batch
        num_atoms = z.numel()
        if edges.shape[1] == 0:
            # Upstream SO(3) rotations require a nonempty edge tensor. Append
            # a disconnected auxiliary graph, never an artificial physical
            # edge on a real atom. Node-local norms and message passing cannot
            # send its information to the real graph; discard its outputs.
            positions = torch.cat((positions, positions.new_tensor([[0., 0., 0.], [1., 0., 0.]])))
            z = torch.cat((z, z.new_tensor([1, 1])))
            batch = torch.cat((batch, batch.new_full((2,), data.num_graphs)))
            edges = edges.new_tensor([[num_atoms, num_atoms + 1], [num_atoms + 1, num_atoms]])
            b.batch_size += 1
        src, dst = edges
        vectors = positions[src] - positions[dst]
        distances, envelope = b._forward_edge(vectors.norm(dim=-1), vectors)
        x = b._forward_embedding(z, distances, edges, envelope)
        scalar, _ = b._forward_blocks(x, z[src], z[dst], distances,
                                      edges, envelope, batch)
        return {t: head(scalar[:num_atoms]) for t, head in self.heads.items()}
