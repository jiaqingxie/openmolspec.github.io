"""Global hard-negative ITM, with differentiable token-feature exchange."""
import torch
import torch.distributed as dist
import torch.nn.functional as F
from torch.distributed.nn.functional import all_gather


def gather_tokens(molecule, mask, spectrum, enabled, spectrum_mask=None):
    """Pad variable SMILES lengths/batches; exchange both features together.

    Packing features into one collective also gives backward a single,
    deterministic collective order. Both token lengths can differ across ranks;
    when supplied, spectrum masks are padded and exchanged alongside features.
    """
    if not enabled:
        result = (molecule, mask, spectrum, [len(molecule)], 0)
        return (*result, spectrum_mask) if spectrum_mask is not None else result
    shape = torch.tensor([len(molecule), molecule.shape[1], spectrum.shape[1]], device=molecule.device)
    shapes = [torch.empty_like(shape) for _ in range(dist.get_world_size())]
    dist.all_gather(shapes, shape)
    counts = [int(s[0]) for s in shapes]
    batch, length = max(counts), max(int(s[1]) for s in shapes)
    spectral_length = max(int(s[2]) for s in shapes)
    spectrum = F.pad(spectrum, (0, 0, 0, spectral_length - spectrum.shape[1]))
    molecule = F.pad(molecule, (0, 0, 0, length - molecule.shape[1]))
    mask = F.pad(mask, (0, length - mask.shape[1], 0, batch - len(mask)))
    packed = F.pad(torch.cat([molecule, spectrum], dim=1),
                   (0, 0, 0, 0, 0, batch - len(molecule)))
    features = torch.cat([part[:n] for part, n in zip(all_gather(packed), counts)])
    masks = [torch.empty_like(mask) for _ in counts]
    dist.all_gather(masks, mask.contiguous())
    masks = torch.cat([part[:n] for part, n in zip(masks, counts)])
    result = (features[:, :length], masks, features[:, length:], counts, sum(counts[:dist.get_rank()]))
    if spectrum_mask is not None:
        spectrum_mask = F.pad(spectrum_mask, (0, spectral_length-spectrum_mask.shape[1], 0, batch-len(spectrum_mask)))
        gathered = [torch.empty_like(spectrum_mask) for _ in counts]
        dist.all_gather(gathered, spectrum_mask.contiguous())
        return (*result, torch.cat([part[:n] for part, n in zip(gathered, counts)]))
    return result


@torch.no_grad()
def sample_negatives(logits, offset):
    if logits.shape[1] < 2:
        raise ValueError('Matching requires at least two candidate samples')
    scores = logits.detach().clone()
    scores[torch.arange(len(scores), device=scores.device),
           torch.arange(len(scores), device=scores.device) + offset] = -torch.inf
    # Mask before softmax, avoiding underflow when the positive dominates.
    return torch.multinomial(scores.softmax(dim=1), 1).squeeze(1)


def matching_forward(self, inputs, return_loss=True, return_proj_output=False):
    if hasattr(self, 'encode_spectra'):
        spectra = self.encode_spectra(inputs)
    else:
        spectra = self.spectral_encoder(self.spectral_encoding(self.load_spectra(inputs)))
    spectral_mask = spectra.get('mask')
    if spectral_mask is None:
        spectral_mask = torch.ones(spectra['hidden_states'].shape[:2], dtype=torch.bool,
                                  device=spectra['hidden_states'].device)
    molecule = self.molecular_encoding(inputs['smiles']['input_ids'], use_cls_token=True)
    mask = inputs['smiles']['attention_mask']
    mask = torch.cat([mask.new_ones((len(mask), 1)), mask], dim=1)
    molecular = self.molecular_encoder(molecule, mask=mask)
    cl_loss, m2s, s2m = self.compute_cl_loss(
        molecular['proj_output'], spectra['proj_output'], return_sim=True,
        global_negatives=True)
    enabled = self.training and dist.is_initialized() and dist.get_world_size() > 1
    all_molecule, all_mask, all_spectrum, counts, offset, all_spectral_mask = gather_tokens(
        molecule, mask, spectra['hidden_states'], enabled, spectral_mask)
    local_spectrum = F.pad(spectra['hidden_states'], (0, 0, 0, all_spectrum.shape[1]-spectra['hidden_states'].shape[1]))
    local_spectral_mask = F.pad(spectral_mask, (0, all_spectrum.shape[1]-spectral_mask.shape[1]))
    negative_m = sample_negatives(s2m, offset)
    negative_s = sample_negatives(m2s, offset)
    molecule = F.pad(molecule, (0, 0, 0, all_molecule.shape[1] - molecule.shape[1]))
    mask = F.pad(mask, (0, all_mask.shape[1] - mask.shape[1]))
    negative = self.molecular_encoder(
        torch.cat([molecule, all_molecule[negative_m]]),
        memory=torch.cat([all_spectrum[negative_s], local_spectrum]),
        src_mask=torch.cat([all_spectral_mask[negative_s], local_spectral_mask]),
        tgt_mask=torch.cat([mask, all_mask[negative_m]]), multimodal=True)
    positive = self.molecular_encoder(molecule, memory=spectra['hidden_states'],
                                      src_mask=spectral_mask, tgt_mask=mask, multimodal=True)
    logits = torch.cat([positive['proj_output'], negative['proj_output']])
    labels = torch.cat([torch.ones(len(molecule), device=logits.device, dtype=torch.long),
                        torch.zeros(2 * len(molecule), device=logits.device, dtype=torch.long)])
    matching_loss = F.cross_entropy(logits, labels)
    if enabled:
        matching_loss = matching_loss * (len(counts) * len(molecule) / sum(counts))
    result = dict(cl_loss=cl_loss, matching_loss=matching_loss,
                  matching_accuracy=(logits.argmax(dim=-1) == labels).float().mean())
    if return_loss:
        result['loss'] = cl_loss + matching_loss
    if return_proj_output:
        result.update(molecular_proj_output=molecular['proj_output'],
                      spectral_proj_output=spectra['proj_output'])
    return result


def install(model_class):
    if model_class.__dict__.get('_openmolspec_matching_installed', False):
        return
    original = model_class.forward

    def forward(self, inputs, return_loss=True, return_proj_output=False):
        if self.phase == 1:
            return matching_forward(self, inputs, return_loss, return_proj_output)
        return original(self, inputs, return_loss, return_proj_output)

    model_class.forward = forward
    model_class._openmolspec_matching_installed = True
