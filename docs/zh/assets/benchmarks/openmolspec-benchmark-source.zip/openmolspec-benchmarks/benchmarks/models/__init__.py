"""OpenMolSpec model adapters and their colocated pinned upstream sources."""
