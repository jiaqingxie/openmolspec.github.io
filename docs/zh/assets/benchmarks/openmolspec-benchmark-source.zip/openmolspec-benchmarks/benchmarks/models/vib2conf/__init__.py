"""Vib2Conf spectrum->conformer and spectrum->property baselines."""
