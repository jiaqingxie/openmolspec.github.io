"""Opt-in upstream dataset/collator adapter for unassigned H/C shifts."""
import pickle
import torch
from torch.nn.utils.rnn import pad_sequence
from benchmarks.engines.nmr_normalization import read_nmr_arrays


def add_nmr_batch(result, batch, nuclei=('c', 'h')):
    for x in nuclei:
        arrays = [row[f'nmr_{x}_shifts_ppm'] for row in batch]
        values = pad_sequence(arrays, batch_first=True)
        lengths = torch.tensor([len(v) for v in arrays])
        result[f'nmr_{x}_shifts_ppm'] = values
        result[f'nmr_{x}_mask'] = torch.arange(values.shape[1])[None, :] < lengths[:, None]
    return result


def install(reference_id, nuclei=('c', 'h')):
    from utils.dataloader import lmdbDataset
    from utils.collators import BaseCollator
    nuclei = tuple(nuclei)
    installed = getattr(lmdbDataset, '_openmolspec_nmr_nuclei', None)
    if installed == nuclei:
        return
    if installed is not None:
        raise RuntimeError(
            f'NMR data adapter already installed for {installed}, requested {nuclei}')
    original_get = lmdbDataset.__getitem__
    original_collate = BaseCollator.__call__

    def get(self, idx):
        output = dict(original_get(self, idx))
        with self.env.begin() as txn:
            record = pickle.loads(txn.get(self._keys[idx]))
        arrays = read_nmr_arrays(record)
        if record['nmr_reference_id'] != reference_id:
            raise ValueError('NMR reference mismatch')
        output.update({f'nmr_{x}_shifts_ppm': torch.from_numpy(arrays[x].copy())
                       for x in nuclei})
        return output

    def collate(self, batch):
        output = original_collate(self, batch)
        add_nmr_batch(output['data'], batch, nuclei=nuclei)
        return output

    lmdbDataset.__getitem__ = get
    BaseCollator.__call__ = collate
    lmdbDataset._openmolspec_nmr_nuclei = nuclei
