"""Physical spectral tokens for Vib2Mol; no pooling or extra encoder."""
import torch
from torch import nn


class MultimodalEmbedding(nn.Module):
    def __init__(self, d_model, statistics, nuclei=('c', 'h')):
        super().__init__()
        nuclei = tuple(nuclei)
        if not nuclei or any(x not in ('c', 'h') for x in nuclei) or len(set(nuclei)) != len(nuclei):
            raise ValueError("nuclei must be a non-empty subset of ('c', 'h')")
        self.nuclei = nuclei
        self.fusion = nn.Sequential(nn.Conv1d(2, 16, 1), nn.GELU())
        self.patch = nn.Conv1d(16, d_model, 8, stride=8)
        self.position = nn.Linear(64, d_model)
        self.register_buffer('wavenumbers', torch.linspace(400., 4000., 1024).reshape(128, 8).mean(1))
        self.register_buffer('frequencies', torch.arange(1, 33, dtype=torch.float32))
        self.types = nn.Parameter(torch.randn(3, d_model) * .02)
        self.cls = nn.Parameter(torch.randn(1, 1, d_model) * .02)
        self.missing = nn.Parameter(torch.randn(2, d_model) * .02)
        self.nmr = nn.ModuleDict({x: nn.Sequential(nn.Linear(1, d_model), nn.SiLU(),
                                                 nn.Linear(d_model, d_model)) for x in nuclei})
        self.register_buffer('center', torch.tensor([statistics[x]['median'] for x in ('c', 'h')], dtype=torch.float32))
        self.register_buffer('scale', torch.tensor([statistics[x]['scale'] for x in ('c', 'h')], dtype=torch.float32))
        if not torch.isfinite(self.center).all() or not torch.isfinite(self.scale).all() or (self.scale <= 0).any():
            raise ValueError('Invalid H/C normalization')

    def forward(self, inputs):
        ir, raman = inputs['ir'], inputs['raman']
        if ir.ndim == 3:
            ir, raman = ir.squeeze(1), raman.squeeze(1)
        if ir.ndim != 2 or ir.shape[1] != 1024 or raman.shape != ir.shape:
            raise ValueError('IR/Raman must have a shared 1024-point axis')
        vib = self.patch(self.fusion(torch.stack((ir, raman), 1))).transpose(1, 2)
        phase = 2 * torch.pi * ((self.wavenumbers - 400.) / 3600.)[:, None] * self.frequencies
        vib = vib + self.position(torch.cat((phase.sin(), phase.cos()), -1)) + self.types[0]
        tokens = [self.cls.expand(len(ir), -1, -1), vib]
        masks = [torch.ones((len(ir), 129), device=ir.device, dtype=torch.bool)]
        nucleus_index = {'c': 0, 'h': 1}
        for x in self.nuclei:
            i = nucleus_index[x]
            shifts, mask = inputs[f'nmr_{x}_shifts_ppm'], inputs[f'nmr_{x}_mask']
            if shifts.ndim != 2 or mask.shape != shifts.shape or mask.dtype != torch.bool:
                raise ValueError('Invalid NMR shifts/mask')
            shifts = (torch.where(mask, shifts, self.center[i]) - self.center[i]) / self.scale[i]
            tokens.append(self.nmr[x](shifts.unsqueeze(-1)) + self.types[i + 1])
            tokens.append((self.missing[i] + self.types[i + 1]).expand(len(ir), 1, -1))
            masks.extend((mask, ~mask.any(1, keepdim=True)))
        return torch.cat(tokens, 1), torch.cat(masks, 1)
