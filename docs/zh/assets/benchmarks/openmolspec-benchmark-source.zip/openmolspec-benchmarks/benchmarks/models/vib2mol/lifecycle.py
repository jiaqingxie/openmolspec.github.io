"""Maintained training lifecycle fixes for the pinned Vib2Mol upstream."""
import importlib
import logging
import math

import torch
import torch.distributed as dist
from tqdm import tqdm


def distributed():
    return dist.is_available() and dist.is_initialized()


def primary():
    return not distributed() or dist.get_rank() == 0


def train_epoch(self, epoch):
    self.model.train()
    if self.scheduler:
        self.scheduler.step(epoch)
    total, count = 0.0, 0
    bar = tqdm(self.train_loader, disable=not primary())
    for batch in bar:
        self.optimizer.zero_grad()
        loss = self.model(self._put_on_device(batch['data']))['loss']
        loss.backward()
        self.optimizer.step()
        total += loss.detach().item() * batch['batch_size']
        count += batch['batch_size']
        bar.set_description(f'Epoch {epoch:3d}, train loss:{total / count:.6f}')
    if distributed():
        totals = torch.tensor([total, count], dtype=torch.float64, device=self.device)
        dist.all_reduce(totals)
        total, count = totals.tolist()
    average = total / count if count else 0.0
    if primary():
        logging.info('Epoch %d, train loss:%.6f', epoch, average)
    return average


def update_stop(trainer, output, epoch, generation):
    """Rank zero owns checkpoints; every rank receives the same stopping state.

    Generation accuracy is only measured every five epochs upstream. Its dummy
    zero on other epochs must not consume the early-stopping patience.
    """
    message = [None]
    if primary():
        try:
            if not generation or epoch % 5 == 0:
                key, suffix = ('metrics', 'acc') if generation else ('recall', 'recall')
                score = float(output[key])
                if not math.isfinite(score):
                    raise ValueError(f'Non-finite validation {key}: {score}')
                trainer.es(score, trainer.model,
                           f'{trainer.model_save_path}/epoch{epoch}_{suffix}{score * 100:.0f}.pth')
            es = trainer.es
            message[0] = dict(best_score=float(es.best_score),
                              val_score=float(es.val_score), counter=int(es.counter),
                              early_stop=bool(es.early_stop))
        except Exception as exc:
            message[0] = {'error': f'{type(exc).__name__}: {exc}'}
    if distributed():
        dist.broadcast_object_list(message, src=0)
    state = message[0]
    if 'error' in state:
        raise RuntimeError(f'Validation/checkpoint failed: {state["error"]}')
    for key, value in state.items():
        setattr(trainer.es, key, value)


def train(self, generation=False):
    if self.config.get('max_steps') is not None:
        from benchmarks.models.vib2mol.steps import train_steps
        return train_steps(self, generation=generation)
    try:
        for epoch in range(self.config['epoch']):
            if self.ddp:
                self.train_sampler.set_epoch(epoch)
            loss = self.engine.train_epoch(epoch)
            output = self.engine.eval_epoch(epoch)
            update_stop(self, output, epoch, generation)
            if primary():
                self.writer.add_scalar('train_loss', loss, epoch)
                for key, value in output.items():
                    if generation and key == 'metrics' and epoch % 5 != 0:
                        continue
                    tag = {'metrics': 'accuracy', 'acc': 'match_accuracy'}.get(key, key)
                    self.writer.add_scalar(f'eval_{tag}', float(value), epoch)
            if self.es.early_stop:
                break
        if primary():
            print(f'[Vib2Mol] best validation {"accuracy" if generation else "recall"}: '
                  f'{self.es.val_score:.6f}')
            torch.save(self.model.state_dict(), f'{self.model_save_path}/epoch{epoch}.pth')
    finally:
        if primary():
            self.writer.close()


def train_generation(self):
    return train(self, generation=True)


def install():
    importlib.import_module('utils.base').BaseEngine.train_epoch = train_epoch
    importlib.import_module('trainers.matching').Trainer.train = train
    importlib.import_module('trainers.spt').Trainer.train = train_generation
