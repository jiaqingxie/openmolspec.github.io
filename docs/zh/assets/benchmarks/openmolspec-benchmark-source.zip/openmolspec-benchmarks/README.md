# OpenMolSpec benchmark training source

This source snapshot contains the benchmark launcher, model adapters, data
preparation and versioned YAML configurations used by the OpenMolSpec manual.

Run these commands from this directory:

```bash
python -m pip install numpy pandas pyarrow scipy pyyaml rdkit lmdb
python -m benchmarks --help
python -m benchmarks check
python -m benchmarks run --config benchmarks/configs/structure2property/equiformer_v3.yaml --dry-run
```

The dry run expands a configuration into its exact command. To train, install
PyTorch/PyG and the selected model's dependencies, prepare the dataset referenced
by `data.root`, then run the same command without `--dry-run`.

Retrieve the pinned model implementations beside their adapters with:

```bash
bash benchmarks/scripts/setup_models.sh
```

Model repositories:

- https://github.com/atomicarchitects/equiformer_v3
- https://github.com/X1nyuLu/vib2mol
- https://github.com/X1nyuLu/vib2conf

Their source revisions are recorded in `benchmarks/models/registry.py`.
The source archive contains the OpenMolSpec adapters; upstream repositories,
model weights and molecular datasets are obtained through their source projects.
`SOURCE_MANIFEST.json` records each bundled file's SHA-256.

Manual: https://jiaqingxie.github.io/openmolspec.github.io/
